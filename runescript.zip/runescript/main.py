"""
RuneScript — Main Entry Point
Launches the tkinter GUI and wires it to the Python backend.

Usage:
    python main.py                          # GUI mode (default)
    python main.py --headless woodcutting   # Run a script without GUI
    python main.py --list                   # List available scripts
"""

import sys
import os
import argparse
import logging
import json
import time
import threading

_HERE = os.path.dirname(os.path.abspath(__file__))
if _HERE not in sys.path:
    sys.path.insert(0, _HERE)

from core.runelite_tracker import RuneLiteTracker
from core.position_tracker import PositionTracker, get_tracker as get_position_tracker
from core.settings_store import get_store as get_settings

# ── Logging ───────────────────────────────────────────────────────────
os.makedirs(os.path.join(_HERE, 'logs'), exist_ok=True)
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)-8s] %(name)s: %(message)s',
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler(
            os.path.join(_HERE, 'logs', 'session.log'),
            mode='a', encoding='utf-8'
        ),
    ]
)
logger = logging.getLogger(__name__)

# ── Script registry ───────────────────────────────────────────────────
SCRIPT_REGISTRY = {
    'woodcutting': ('scripts.woodcutting.woodcutting_script', 'WoodcuttingScript'),
}

# ── Config ────────────────────────────────────────────────────────────
CONFIG_PATH = os.path.join(_HERE, 'config.json')

DEFAULT_CONFIG = {
    'game_window_title': 'RuneLite',
    'antiban_enabled':   True,
    'input_method':      'interception',
}


def load_config(path: str) -> dict:
    if os.path.exists(path):
        try:
            with open(path) as f:
                return {**DEFAULT_CONFIG, **json.load(f)}
        except Exception as e:
            logger.warning(f'Could not load config {path}: {e}')
    return DEFAULT_CONFIG.copy()


# ── Real bridge — wires gui.py callbacks to actual script execution ───

class ScriptBridge:
    """
    Passed to RuneScriptApp as the bridge object.
    Connects the GUI buttons to real script start/stop/pause,
    and pushes live log + stats back into the GUI via callbacks.
    """

    def __init__(self, script_registry: dict,
                 log_cb, stats_cb, status_cb,
                 runelite_tracker: RuneLiteTracker,
):
        self._registry        = script_registry
        self._log             = log_cb
        self._stats           = stats_cb
        self._status_cb       = status_cb
        self._active_script   = None
        self._active_name     = None
        self._push_running    = False
        self._highlight_colours: dict = {}
        self._session_start   = time.time()
        self.runelite_tracker = runelite_tracker
        # Start the always-on stats push loop immediately
        self._start_push_loop()

    def set_highlight_colour(self, script_name: str, colour: str):
        self._highlight_colours[script_name.lower()] = colour
        self._log('info', f'Highlight colour → {colour}')

    def start_script(self, name: str, config: dict) -> dict:
        if self._active_script and getattr(self._active_script, 'is_running', False):
            return {'ok': False, 'error': 'Already running'}

        key = name.lower()
        if key not in self._registry:
            return {'ok': False, 'error': f'Unknown script: {name}'}

        try:
            cfg = dict(config or {})
            if key in self._highlight_colours:
                cfg['highlight_colour'] = self._highlight_colours[key]

            mod_path, class_name = self._registry[key]
            import importlib
            mod = importlib.import_module(mod_path)
            cls = getattr(mod, class_name)
            self._active_script = cls(cfg)
            self._active_name   = key
            self._active_script.start()
            self._session_start = time.time()
            self._log('info', f'{class_name} started.')
            self._status_cb('running')
            return {'ok': True}
        except Exception as e:
            logger.exception(e)
            return {'ok': False, 'error': str(e)}

    def stop_script(self):
        if self._active_script:
            self._active_script.stop()
        self._log('warn', 'Script stopped.')
        self._status_cb('idle')

    def pause_script(self):
        if self._active_script:
            try:
                self._active_script.pause()
                self._log('info', 'Script paused.')
                self._status_cb('paused')
            except AttributeError:
                pass

    def push_log(self, level: str, msg: str):
        self._log(level, msg)

    def _start_push_loop(self):
        if self._push_running:
            return
        self._push_running = True
        threading.Thread(target=self._push_loop, daemon=True).start()

    def _push_loop(self):
        while self._push_running:
            try:
                s = self._active_script

                # Drain script log queue if a script is running
                if s is not None:
                    q = getattr(s, '_log_queue', None)
                    if q:
                        while not q.empty():
                            rec = q.get_nowait()
                            lvl = rec.levelname.lower()
                            if lvl == 'warning': lvl = 'warn'
                            self._log(lvl, rec.getMessage())

                # Build paint data — prefer script's own data when running,
                # otherwise push bare RuneLite snapshot so the GUI stays live
                if s is not None:
                    try:
                        paint = s.get_paint_data()
                        paint['session_elapsed'] = int(time.time() - self._session_start)
                    except Exception:
                        paint = {}
                else:
                    paint = {}

                # Always attach RuneLite live data
                pt = get_position_tracker()
                paint['runelite_connected'] = pt.plugin_available
                paint['runelite_error']     = None
                paint['skill_snapshot']     = pt.stats if pt.plugin_available else self.runelite_tracker.snapshot()

                self._stats(paint)

                # Mark idle when script finishes
                if s is not None and not getattr(s, 'is_running', False):
                    self._active_script = None
                    self._status_cb('idle')

            except Exception as e:
                logger.debug(f'[Push] {e}')
            time.sleep(1.0)


# ── GUI launch ────────────────────────────────────────────────────────

def launch_gui():
    gui_dir = os.path.join(_HERE, 'gui')
    if gui_dir not in sys.path:
        sys.path.insert(0, gui_dir)

    from gui import RuneScriptApp

    # Apply persisted settings before anything starts
    cfg = get_settings()
    logging.getLogger().setLevel(
        getattr(logging, cfg.get("log_level", "INFO"), logging.INFO))

    # RSEye skill tracker — push-based, no polling needed
    rl_tracker = RuneLiteTracker()
    rl_tracker.start()
    logger.info('[Main] RSEye skill tracker ready.')

    # Start position tracker (rseye-connector listener on :80)
    # Wire stat_update packets directly into the skill tracker
    pos_tracker = get_position_tracker()
    pos_tracker.on_stats = rl_tracker.on_stats_update
    pos_tracker.start()
    logger.info('[Main] PositionTracker started — listening on http://localhost:80/api/v1/')

    def make_bridge(log_cb, stats_cb, status_cb):
        bridge = ScriptBridge(
            script_registry=SCRIPT_REGISTRY,
            log_cb=log_cb,
            stats_cb=stats_cb,
            status_cb=status_cb,
            runelite_tracker=rl_tracker,
        )
        return bridge

    app = RuneScriptApp(bridge_factory=make_bridge)
    # Apply persisted appearance settings now that the window exists
    try:
        _opacity = cfg.get("opacity", 1.0)
        if _opacity < 1.0:
            app.root.attributes("-alpha", _opacity)
    except Exception:
        pass
    app.run()


# ── Headless ──────────────────────────────────────────────────────────

def launch_headless(script_name: str, script_config: dict):
    key = script_name.lower()
    if key not in SCRIPT_REGISTRY:
        logger.error(f"Unknown script '{script_name}'.")
        sys.exit(1)
    mod_path, class_name = SCRIPT_REGISTRY[key]
    import importlib
    mod = importlib.import_module(mod_path)
    cls = getattr(mod, class_name)
    logger.info(f'[Main] Headless: {class_name}')
    script = cls(script_config)
    try:
        script.run()
    except KeyboardInterrupt:
        script.stop()


# ── Entry ─────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(description='RuneScript')
    parser.add_argument('--headless', metavar='SCRIPT')
    parser.add_argument('--script-config', metavar='PATH')
    parser.add_argument('--list', action='store_true')
    parser.add_argument('--debug', action='store_true')
    args = parser.parse_args()

    if args.debug:
        logging.getLogger().setLevel(logging.DEBUG)

    if args.list:
        for name, (mod, cls) in sorted(SCRIPT_REGISTRY.items()):
            print(f'  {name:<18} {cls}')
        sys.exit(0)

    script_config = {}
    if args.script_config:
        try:
            with open(args.script_config) as f:
                script_config = json.load(f)
        except Exception as e:
            logger.warning(f'Could not load script config: {e}')

    if args.headless:
        launch_headless(args.headless, script_config)
    else:
        launch_gui()


if __name__ == '__main__':
    main()
