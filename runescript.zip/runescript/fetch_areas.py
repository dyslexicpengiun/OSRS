"""
fetch_areas.py
==============
Builds data/locations.json from the OSRS wiki.

Run once:  python fetch_areas.py
Writes:    data/locations.json
"""

from __future__ import annotations
import json, os, re, sys, time, urllib.parse, urllib.request

_HERE     = os.path.dirname(os.path.abspath(__file__))
_DATA_DIR = os.path.join(_HERE, "data")
_OUT_FILE = os.path.join(_DATA_DIR, "locations.json")
_WIKI_API = "https://oldschool.runescape.wiki/api.php"
_UA       = "runescript-location-fetcher/1.0"

DEFAULT_RADIUS = 30
_RADIUS_OVERRIDES = [
    ("kingdom",  200), ("region",   180), ("wilderness", 150),
    ("zeah",     150), ("kourend",  150), ("morytania",  120),
    ("kandarin", 120), ("asgarnia", 120), ("misthalin",  120),
    ("city",      60), ("town",      50), ("village",     40),
    ("dungeon",   40), ("cave",      35), ("guild",       25),
    ("mine",      25), ("bank",      15),
]
def _r(name):
    low = name.lower()
    for kw, r in _RADIUS_OVERRIDES:
        if kw in low: return r
    return DEFAULT_RADIUS

def _get(url):
    req = urllib.request.Request(url, headers={"User-Agent": _UA})
    with urllib.request.urlopen(req, timeout=20) as r:
        return r.read()

def _api(**kw):
    kw.setdefault("format", "json")
    return json.loads(_get(f"{_WIKI_API}?{urllib.parse.urlencode(kw)}"))

_XY_RE = re.compile(
    r'(?<!\w)x\s*=\s*(\d{3,5})\D{0,60}?y\s*=\s*(\d{3,5})'
    r'|(?<!\w)y\s*=\s*(\d{3,5})\D{0,60}?x\s*=\s*(\d{3,5})',
    re.IGNORECASE
)
_PLANE_RE = re.compile(r'\bplane\s*=\s*([0-3])', re.IGNORECASE)

def _coords_from_wikitext(text):
    for m in _XY_RE.finditer(text):
        if m.group(1) and m.group(2):
            x, y = int(m.group(1)), int(m.group(2))
        else:
            x, y = int(m.group(4)), int(m.group(3))
        if 1000 <= x <= 5000 and 1000 <= y <= 15000:
            pm = _PLANE_RE.search(text)
            return x, y, int(pm.group(1)) if pm else 0
    return None

def _coords_for_page(title):
    try:
        data = _api(action="parse", page=title, prop="wikitext", section="0")
        text = data.get("parse", {}).get("wikitext", {}).get("*", "")
        return _coords_from_wikitext(text)
    except Exception:
        return None

def _get_category_members(cat, ns=0, subcat=False):
    params = dict(action="query", list="categorymembers",
                  cmtitle=f"Category:{cat}", cmlimit="500",
                  cmnamespace=14 if subcat else ns)
    try:
        data = _api(**params)
        return data.get("query", {}).get("categorymembers", [])
    except Exception as e:
        print(f"    categorymembers({cat}) failed: {e}")
        return []

def fetch_pages(titles, locs, label=""):
    """Fetch coords for a list of page titles, skip already-known."""
    added = 0
    for title in titles:
        key = title.lower()
        if key in locs:
            continue
        coords = _coords_for_page(title)
        if coords:
            x, y, plane = coords
            r = _r(title)
            locs[key] = (x-r, x+r, y-r, y+r, plane, title)
            added += 1
        time.sleep(0.07)
    if label:
        print(f"  {label}: +{added} (total {len(locs)})")
    return added

def fetch_category(cat, locs):
    pages = _get_category_members(cat)
    titles = [p["title"] for p in pages]
    print(f"  Category:{cat} — {len(titles)} pages", end="", flush=True)
    added = fetch_pages(titles, locs)
    print(f" → +{added} (total {len(locs)})")

def fetch_settlements(locs):
    subcats = _get_category_members("Settlements", subcat=True)
    print(f"  Found {len(subcats)} settlement subcategories")
    titles = []
    for sc in subcats:
        name = sc["title"].replace("Category:", "").strip()
        name = re.sub(r'\s*\([^)]+\)$', '', name).strip()
        titles.append(name)
    fetch_pages(titles, locs, "Settlements")


# Explicit high-value sub-location pages to look up individually.
# These are specific named areas/banks/spots that won't appear as
# category articles but are worth having for precise location naming.
_EXTRA_PAGES = [
    # Banks
    "Varrock East Bank", "Varrock West Bank",
    "Edgeville Bank", "Draynor Village Bank",
    "Falador East Bank", "Falador West Bank",
    "Grand Exchange", "Al Kharid Bank",
    "Seers' Village Bank", "Ardougne North Bank", "Ardougne South Bank",
    "Catherby Bank", "Camelot Bank",
    "Pest Control", "Ferox Enclave",
    # Wildy
    "Wilderness", "Edgeville Dungeon",
    "Corporeal Beast", "King Black Dragon Lair",
    # Training spots
    "Crabs", "Sand Crabs", "Ammonite Crabs", "Swamp Crabs",
    "Rock Crabs", "Nightmare Zone",
    "Stronghold of Security", "Stronghold Slayer Cave",
    # Zeah
    "Arceuus", "Hosidius", "Lovakengj", "Shayzien", "Piscarilius",
    "Kourend Castle", "Woodcutting Guild", "Farming Guild",
    "Wintertodt", "Tempoross",
    # Underground / Dungeons
    "Catacombs of Kourend", "Slayer Tower",
    "Lumbridge Swamp Caves", "Dwarven Mine",
    "Taverley Dungeon", "Karamja Dungeon",
    "Waterbirth Island Dungeon", "Fremennik Slayer Dungeon",
    "Iorwerth Dungeon", "Smoke Dungeon",
    "Brimhaven Dungeon", "Moss Giant Island",
    # Bosses
    "Zulrah", "Vorkath", "Theatre of Blood",
    "Chambers of Xeric", "Tombs of Amascut",
    "Barrows", "God Wars Dungeon",
    # Skilling
    "Fishing Trawler", "Barbarian Fishing",
    "Blast Furnace", "Motherlode Mine",
    "Lava Flow Mine", "Mining Guild",
    "Barbarian Assault", "Gnome Stronghold Agility Course",
    "Seers' Village Rooftop Course", "Ardougne Rooftop Course",
    "Rellekka Rooftop Course", "Pollnivneach Rooftop Course",
    # Misc
    "Puro-Puro", "Pyramid Plunder",
    "Mort'ton", "Burgh de Rott",
    "Ape Atoll", "Mos Le'Harmless",
    "Fossil Island", "Lithkren Vault",
    "Kebos Lowlands", "Mount Quidamortem",
    "Ruins of Camdozaal", "Ancient Vault",
    "Wyvern Cave", "Kraken Cove",
]


def main():
    os.makedirs(_DATA_DIR, exist_ok=True)
    print("=== OSRS Location Fetcher ===\n")
    locs = {}

    print("Phase 1: Named settlements (subcategory list)...")
    fetch_settlements(locs)
    print(f"  Total: {len(locs)}\n")

    print("Phase 2: Location categories...")
    for cat in ["Dungeons", "Guilds", "Islands", "Minigames", "Mines", "Regions"]:
        fetch_category(cat, locs)
    print(f"  Total: {len(locs)}\n")

    print("Phase 3: Targeted sub-locations...")
    fetch_pages(_EXTRA_PAGES, locs, "Extra pages")
    print(f"  Total: {len(locs)}\n")

    if not locs:
        print("ERROR: No locations found.", file=sys.stderr)
        sys.exit(1)

    out = [list(e) for e in sorted(locs.values(), key=lambda e: (e[1]-e[0])*(e[3]-e[2]))]
    with open(_OUT_FILE, "w", encoding="utf-8") as f:
        json.dump(out, f, indent=2)

    print(f"✓ Wrote {len(out)} locations → {_OUT_FILE}")
    print("Restart the app to pick up the new location data.")

if __name__ == "__main__":
    main()
