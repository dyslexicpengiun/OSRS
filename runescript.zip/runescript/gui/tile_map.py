# ═══════════════════════════════════════════════════════════════════════════
#  TILE MAP ENGINE  — fetches tiles from maps.runescape.wiki
#
#  URL format:
#    https://maps.runescape.wiki/osrs/tiles/{mapId}_{cacheVer}/{z}/{plane}_{tx}_{url_ty}.png
#    where url_ty = -(ty + 1)  (Leaflet TMS: Y axis inverted vs game coords)
#
#  Coordinate systems:
#    Game:        X east, Y north (increases upward)
#    Abs pixel:   abs_x =  PX_PER_SQ * world_x
#                 abs_y = -PX_PER_SQ * (world_y + 1)
#                 (Y increases downward on screen, northward = smaller abs_y)
#    Tile index:  tx = world_x // SQ_PER_TILE
#                 ty = world_y // SQ_PER_TILE  (game tile row)
#
#  At internal zoom Z=3: 8px/sq, 32sq/tile (256px/tile)
#  No origin constants. No calibration. Coords ARE the address.
# ═══════════════════════════════════════════════════════════════════════════

import io
import logging
import math
import os
import queue
import threading
import time
import urllib.request
from typing import Dict, Optional, Tuple
from PIL import Image

log = logging.getLogger(__name__)

# ── Location overlay ─────────────────────────────────────────────────────────
# Loaded from map_locations.json (scraped from OSRS wiki).
# Falls back to empty list gracefully if file missing.

import json as _json

_DATA_DIR        = os.path.normpath(os.path.join(os.path.dirname(__file__), '..', 'data'))
_LOCATIONS_FILE  = os.path.join(_DATA_DIR, 'map_locations.json')
_ICONS_DIR       = os.path.join(_DATA_DIR, 'map_icons')
_ICON_MANIFEST   = os.path.join(_DATA_DIR, 'icon_manifest.json')
_ICON_META_FILE  = os.path.join(_DATA_DIR, 'icon_meta.json')

_locations_data: list = []
_locations_loaded = False
_icon_manifest: dict = {}   # sprite_stem → filename  e.g. "1453-0" → "1453-0.png"
_icon_meta: dict     = {}   # icon_key    → {"label":..., "iconUrl": "1453-0.png"}

_ICON_CACHE: dict = {}      # icon_key (str) → PIL.Image RGBA | None
_ICON_LOCK  = threading.Lock()

# Fallback colour map for categories when no icon file found
_CAT_COLOURS = {
    'bank':           '#FFD700',
    'dungeon':        '#FF6B6B',
    'agility_training':'#00CED1',
    'agility_short-cut':'#00CED1',
    'minigame':       '#7B68EE',
    'mining_site':    '#A0A0A0',
    'farming_patch':  '#90EE90',
    'transportation': '#FF00FF',
    'altar':          '#ADD8E6',
    'anvil':          '#808080',
    'furnace':        '#FF4500',
    'fishing_spot':   '#1E90FF',
    'quest_start':    '#FF69B4',
    'grand_exchange': '#FFD700',
    'general_store':  '#FFA500',
}


def _load_locations():
    """Load map_locations.json, icon_manifest.json, and icon_meta.json."""
    global _locations_data, _locations_loaded, _icon_manifest, _icon_meta
    try:
        path = os.path.normpath(_LOCATIONS_FILE)
        if os.path.exists(path):
            with open(path, encoding='utf-8') as f:
                _locations_data = _json.load(f)
            log.info(f'[Icons] Loaded {len(_locations_data)} locations from map_locations.json')
        else:
            log.warning(f'[Icons] map_locations.json not found at {path}')
    except Exception as e:
        log.warning(f'[Icons] Failed to load map_locations.json: {e}')

    try:
        if os.path.exists(_ICON_META_FILE):
            with open(_ICON_META_FILE, encoding='utf-8') as f:
                _icon_meta = _json.load(f)
            log.info(f'[Icons] icon_meta: {len(_icon_meta)} entries')
    except Exception as e:
        log.warning(f'[Icons] Failed to load icon_meta.json: {e}')

    try:
        if os.path.exists(_ICON_MANIFEST):
            with open(_ICON_MANIFEST, encoding='utf-8') as f:
                _icon_manifest = _json.load(f)
            log.info(f'[Icons] Manifest: {len(_icon_manifest)} icon entries')
        elif os.path.isdir(_ICONS_DIR):
            _icon_manifest = {
                os.path.splitext(fn)[0]: fn
                for fn in os.listdir(_ICONS_DIR)
                if fn.lower().endswith('.png')
            }
            log.info(f'[Icons] Built manifest from disk: {len(_icon_manifest)} icons')
    except Exception as e:
        log.warning(f'[Icons] Failed to load icon manifest: {e}')
    finally:
        _locations_loaded = True

threading.Thread(target=_load_locations, daemon=True).start()


def _fetch_icon(icon_key: str):
    """
    Load and cache an icon by its key (e.g. 'bank', 'dungeon').
    Resolves key → filename via icon_meta.json, then loads from map_icons/.
    Falls back to live wiki fetch if file missing.
    Returns a PIL RGBA Image or None.
    """
    icon_key = str(icon_key)
    with _ICON_LOCK:
        if icon_key in _ICON_CACHE:
            return _ICON_CACHE[icon_key]

    img = None

    # 1. Resolve filename via icon_meta (e.g. 'bank' → '1453-0.png')
    filename = None
    if _icon_meta and icon_key in _icon_meta:
        filename = _icon_meta[icon_key].get('iconUrl', '')

    # 2. Build candidate file paths
    candidates = []
    if filename:
        candidates.append(os.path.join(_ICONS_DIR, filename))
    # Stem lookup in manifest
    if _icon_manifest:
        stem = filename.rsplit('.', 1)[0] if filename else icon_key
        mf = _icon_manifest.get(stem) or _icon_manifest.get(f"{icon_key}-0")
        if mf:
            candidates.append(os.path.join(_ICONS_DIR, mf))
    # Direct guesses
    for suffix in (f"{icon_key}.png", f"{icon_key}-0.png"):
        candidates.append(os.path.join(_ICONS_DIR, suffix))

    for path in candidates:
        if os.path.exists(path):
            try:
                img = Image.open(path).convert('RGBA')
                break
            except Exception:
                pass

    # 3. Live fetch as last resort
    if img is None:
        base_url = 'https://maps.runescape.wiki/osrs/images/icons/'
        for url_name in ([filename] if filename else []) + [f"{icon_key}-0.png", f"{icon_key}.png"]:
            if not url_name:
                continue
            try:
                req = urllib.request.Request(base_url + url_name, headers={
                    'User-Agent': 'Mozilla/5.0',
                    'Referer':    'https://maps.runescape.wiki/',
                })
                with urllib.request.urlopen(req, timeout=5) as r:
                    img = Image.open(io.BytesIO(r.read())).convert('RGBA')
                    os.makedirs(_ICONS_DIR, exist_ok=True)
                    img.save(os.path.join(_ICONS_DIR, url_name))
                    log.debug(f'[Icons] Live-fetched {url_name}')
                break
            except Exception:
                pass

    with _ICON_LOCK:
        _ICON_CACHE[icon_key] = img
    return img


def get_icons_in_region(wx_min, wy_min, wx_max, wy_max, plane=0):
    """Return list of (wx, wy, icon_id, category, name) for locations in region."""
    results = []
    for loc in _locations_data:
        if loc.get('plane', 0) != plane:
            continue
        x, y = loc['x'], loc['y']
        if wx_min <= x <= wx_max and wy_min <= y <= wy_max:
            icon_id  = str(loc.get('icon', loc.get('type', 'unknown')))
            category = loc.get('category', loc.get('type', 'unknown'))
            name     = loc.get('name', '')
            results.append((x, y, icon_id, category, name))
    return results

# ── Tile server ─────────────────────────────────────────────────────────────
_TILE_HOST    = "https://maps.runescape.wiki/osrs/tiles"
_TILE_MAP_ID  = 0               # surface map
_CACHE_VER    = "2019-10-31_1"  # from dataloader.json
_TILE_SIZE_PX = 256

# Internal zoom level — Z=3 gives 8px/sq, 32sq/tile
_INTERNAL_ZOOM = 3
_PX_PER_SQ     = 2 ** _INTERNAL_ZOOM   # 8
_SQ_PER_TILE   = _TILE_SIZE_PX // _PX_PER_SQ  # 32

# GUI display zoom multipliers applied on top of internal resolution
_ZOOM_LEVELS  = [0.25, 0.5, 0.75, 1.0, 1.5, 2.0]
_ZOOM_DEF_IDX = 1  # default 0.5×

# Disk cache
_CACHE_ROOT: Optional[str] = None

def _cache_dir() -> str:
    global _CACHE_ROOT
    if _CACHE_ROOT is None:
        here = os.path.dirname(os.path.abspath(__file__))
        for _ in range(4):
            candidate = os.path.join(here, "data", "tile_cache")
            if os.path.exists(os.path.join(here, "data")):
                _CACHE_ROOT = candidate
                break
            here = os.path.dirname(here)
        if _CACHE_ROOT is None:
            _CACHE_ROOT = os.path.join(
                os.path.dirname(os.path.abspath(__file__)), "tile_cache")
    os.makedirs(_CACHE_ROOT, exist_ok=True)
    return _CACHE_ROOT


# ── Coordinate helpers ───────────────────────────────────────────────────────

def world_to_abs(wx: int, wy: int) -> Tuple[int, int]:
    """
    World tile → absolute pixel position.
      abs_x =  PX * wx          (east = right)
      abs_y = -PX * (wy + 1)    (north = up = smaller abs_y)
    """
    return _PX_PER_SQ * wx, -_PX_PER_SQ * (wy + 1)


def abs_to_world(abs_x: int, abs_y: int) -> Tuple[int, int]:
    """Inverse of world_to_abs."""
    wx = abs_x // _PX_PER_SQ
    wy = -(abs_y // _PX_PER_SQ) - 1
    return wx, wy


def canvas_to_world(
    cx: int, cy: int,
    center_wx: int, center_wy: int,
    canvas_w: int, canvas_h: int,
    zoom_mult: float,
) -> Tuple[int, int]:
    """Canvas pixel → world tile coords."""
    ctr_ax, ctr_ay = world_to_abs(center_wx, center_wy)
    abs_x = ctr_ax + int((cx - canvas_w  / 2) / zoom_mult)
    abs_y = ctr_ay + int((cy - canvas_h / 2) / zoom_mult)
    return abs_to_world(abs_x, abs_y)


# ── Tile cache ───────────────────────────────────────────────────────────────

class TileCache:
    """
    Fetches and caches OSRS wiki map tiles.
    Stored on disk and in memory (max 512 tiles).
    Uses a priority queue so centre tiles load first.
    Batches _on_ready callbacks so only one redraw fires per burst.
    """

    def __init__(self, internal_zoom: int = _INTERNAL_ZOOM):
        self._zoom   = internal_zoom
        self._mem:   Dict[Tuple, Optional[Image.Image]] = {}
        self._order: list = []
        self._pending: set = set()
        self._lock   = threading.Lock()
        self._q:     queue.PriorityQueue = queue.PriorityQueue()
        self._on_ready = None
        self._notify_serial  = 0
        self._notify_lock    = threading.Lock()

        for _ in range(8):
            threading.Thread(target=self._worker, daemon=True).start()

    def set_on_ready(self, cb):
        self._on_ready = cb

    def get_tile(self, plane: int, tx: int, ty: int,
                 priority: float = 0.0) -> Optional[Image.Image]:
        """Return cached tile or None (triggers async fetch)."""
        key = (plane, tx, ty)
        with self._lock:
            if key in self._mem:
                return self._mem[key]
            if key not in self._pending:
                self._pending.add(key)
                self._q.put((priority, key))
        return None

    def prefetch(self, plane: int, tx: int, ty: int, priority: float = 1.0):
        key = (plane, tx, ty)
        with self._lock:
            if key not in self._mem and key not in self._pending:
                self._pending.add(key)
                self._q.put((priority, key))

    def _worker(self):
        while True:
            _pri, key = self._q.get()
            img = self._fetch(key)
            with self._lock:
                self._mem[key] = img
                self._pending.discard(key)
                self._order.append(key)
                while len(self._order) > 512:
                    self._mem.pop(self._order.pop(0), None)
            if img is not None:
                self._schedule_notify()
            self._q.task_done()

    def _schedule_notify(self):
        """Debounce: fire _on_ready 150ms after the last tile arrives."""
        with self._notify_lock:
            self._notify_serial += 1
            my_serial = self._notify_serial
        def _wait_and_fire(serial):
            time.sleep(0.15)
            with self._notify_lock:
                if self._notify_serial != serial:
                    return  # superseded by a newer tile arrival
            if self._on_ready:
                try:
                    self._on_ready()
                except Exception:
                    pass
        threading.Thread(target=_wait_and_fire, args=(my_serial,), daemon=True).start()

    def _fetch(self, key: Tuple) -> Optional[Image.Image]:
        plane, tx, ty = key
        fname  = f"p{plane}_z{self._zoom}_{tx}_{ty}.png"
        fpath  = os.path.join(_cache_dir(), fname)

        if os.path.exists(fpath):
            try:
                return Image.open(fpath).convert("RGBA")
            except Exception:
                os.remove(fpath)

        url = (f"{_TILE_HOST}/{_TILE_MAP_ID}_{_CACHE_VER}"
               f"/{self._zoom}/{plane}_{tx}_{ty}.png")
        log.debug(f"[Tile] GET {url}")
        try:
            req = urllib.request.Request(url, headers={
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
                "Referer": "https://maps.runescape.wiki/",
            })
            with urllib.request.urlopen(req, timeout=8) as r:
                data = r.read()
            if len(data) < 100:
                return None   # empty/void tile
            with open(fpath, "wb") as f:
                f.write(data)
            return Image.open(io.BytesIO(data)).convert("RGBA")
        except Exception as e:
            log.debug(f"[Tile] FAIL {url}: {e}")
            return None


_tile_cache: Optional[TileCache] = None

def get_tile_cache() -> TileCache:
    global _tile_cache
    if _tile_cache is None:
        _tile_cache = TileCache(_INTERNAL_ZOOM)
    return _tile_cache


# ── Viewport stitcher ────────────────────────────────────────────────────────

def stitch_viewport(
    center_wx: int, center_wy: int, plane: int,
    canvas_w: int, canvas_h: int,
    zoom_mult: float,
    player_wx: Optional[int] = None,
    player_wy: Optional[int] = None,
    margin_px: int = 0,
) -> Tuple[Image.Image, int, int]:
    """
    Build a canvas_w × canvas_h PIL image centred on (center_wx, center_wy).
    player_wx/wy is where the dot is drawn (may differ from centre when panning).
    Returns (image, dot_canvas_x, dot_canvas_y).
    """
    cache = get_tile_cache()

    ctr_ax, ctr_ay = world_to_abs(center_wx, center_wy)

    # Viewport bounds in absolute pixel space — expanded by margin for smooth panning
    half_w = (canvas_w  / 2 + margin_px) / zoom_mult
    half_h = (canvas_h / 2 + margin_px) / zoom_mult
    vp_left = ctr_ax - half_w
    vp_top  = ctr_ay - half_h

    # Tile indices that overlap the viewport
    tx_min = int(math.floor(vp_left / _TILE_SIZE_PX))
    tx_max = int(math.ceil((vp_left + (canvas_w + 2*margin_px) / zoom_mult) / _TILE_SIZE_PX))

    # For abs_y: tile (tx,ty) occupies abs_y range [-(ty+1)*256, -ty*256)
    # vp_top is the minimum abs_y visible (northernmost = smallest abs_y)
    # tile ty covers abs_y from -(ty+1)*256 to -ty*256
    # we need tiles where -(ty+1)*256 < vp_bottom AND -ty*256 > vp_top
    vp_bottom = vp_top + (canvas_h + 2*margin_px) / zoom_mult
    ty_min = int(math.floor(-vp_bottom / _TILE_SIZE_PX))
    ty_max = int(math.ceil(-vp_top    / _TILE_SIZE_PX))

    # Stitch into a buffer
    buf_cols = tx_max - tx_min
    buf_rows = ty_max - ty_min
    buf_w    = buf_cols * _TILE_SIZE_PX
    buf_h    = buf_rows * _TILE_SIZE_PX
    buf      = Image.new("RGBA", (buf_w, buf_h), (13, 11, 8, 255))

    any_missing = False
    ctr_tx = (ctr_ax) / _TILE_SIZE_PX
    ctr_ty = (-ctr_ay) / _TILE_SIZE_PX
    for tx in range(tx_min, tx_max):
        for ty in range(ty_min, ty_max):
            # Priority = distance from centre — lower = fetched first
            pri = (tx - ctr_tx) ** 2 + (ty - ctr_ty) ** 2
            tile = cache.get_tile(plane, tx, ty, priority=pri)
            if tile is None:
                any_missing = True
                continue
            # Tile (tx,ty) in abs coords: x=[tx*256,(tx+1)*256), y=[-(ty+1)*256,-ty*256)
            # In buffer coords:
            bx = (tx - tx_min) * _TILE_SIZE_PX
            # ty_max-1 is the southernmost tile row (largest ty = most negative abs_y)
            by = (ty_max - 1 - ty) * _TILE_SIZE_PX
            buf.paste(tile, (bx, by))

    # Prefetch surrounding ring when all visible tiles are loaded
    if not any_missing:
        for tx in range(tx_min - 1, tx_max + 1):
            for ty in range(ty_min - 1, ty_max + 1):
                if not (tx_min <= tx < tx_max and ty_min <= ty < ty_max):
                    cache.prefetch(plane, tx, ty)

    # Buffer top-left in abs coords
    buf_abs_x = tx_min * _TILE_SIZE_PX
    buf_abs_y = -(ty_max) * _TILE_SIZE_PX   # top of buffer = most northern = smallest abs_y

    # Viewport in buffer coords
    vp_buf_x = vp_left - buf_abs_x
    vp_buf_y = vp_top  - buf_abs_y

    # Crop to viewport at native res
    x0 = max(0, int(vp_buf_x))
    y0 = max(0, int(vp_buf_y))
    x1 = min(buf_w, int(math.ceil(vp_buf_x + (canvas_w + 2*margin_px) / zoom_mult)))
    y1 = min(buf_h, int(math.ceil(vp_buf_y + (canvas_h + 2*margin_px) / zoom_mult)))
    cropped = buf.crop((x0, y0, x1, y1))

    # Scale to canvas — BILINEAR is 3× faster than LANCZOS, visually identical at map zoom
    out_w = int((x1 - x0) * zoom_mult)
    out_h = int((y1 - y0) * zoom_mult)
    if out_w > 0 and out_h > 0:
        resample = Image.NEAREST if zoom_mult >= 1.0 else Image.BILINEAR
        scaled = cropped.resize((out_w, out_h), resample)
    else:
        scaled = cropped

    # Paste onto full oversized canvas (canvas + 2*margin)
    full_w = canvas_w + 2 * margin_px
    full_h = canvas_h + 2 * margin_px
    canvas_img = Image.new("RGBA", (full_w, full_h), (13, 11, 8, 255))
    paste_x = int((x0 - vp_buf_x) * zoom_mult)
    paste_y = int((y0 - vp_buf_y) * zoom_mult)
    canvas_img.paste(scaled, (paste_x, paste_y))

    # Player dot in canvas coords (relative to the oversized image's top-left)
    if player_wx is not None and player_wy is not None:
        p_ax, p_ay = world_to_abs(player_wx, player_wy)
    else:
        p_ax, p_ay = ctr_ax, ctr_ay
    dot_cx = int((p_ax - vp_left) * zoom_mult)
    dot_cy = int((p_ay - vp_top)  * zoom_mult)

    # Visible world bounds for icon query (full oversized viewport)
    wx_min, wy_min = abs_to_world(int(vp_left), int(vp_top + (canvas_h + 2*margin_px) / zoom_mult))
    wx_max, wy_max = abs_to_world(int(vp_left + (canvas_w + 2*margin_px) / zoom_mult), int(vp_top))

    # Map locations → canvas positions
    icons = []
    for ix, iy, icon_id, cat, name in get_icons_in_region(wx_min, wy_min, wx_max, wy_max, plane):
        iax, iay = world_to_abs(ix, iy)
        icx = int((iax - vp_left) * zoom_mult)
        icy = int((iay - vp_top)  * zoom_mult)
        icons.append((icx, icy, icon_id, cat, name))

    return canvas_img, dot_cx, dot_cy, icons

