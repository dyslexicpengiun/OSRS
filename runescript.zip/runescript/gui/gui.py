"""
RuneScript — Control Panel GUI  (gui.py)
Pure tkinter. Mirrors the index.html layout.

Fixes applied vs previous version:
  • Font sizes reduced to match HTML compactness
  • Cinzel / IM Fell / Share Tech Mono loaded from Google Fonts at startup
    (cached to ~/.runescript_fonts/); Georgia / Courier used as fallback
  • Scrollbars hidden when not needed; styled to match stone palette
  • Skill icons in right panel rendered with their correct colour
  • XP bar stays gold — no colour change near 100%
  • Nav buttons centred in header with proper bordered box on active
  • Antiban toggles are neon-styled with proper visible thumb
  • Location tracker coords/label pulse-animate like HTML
  • Clock in header shows real wall-clock time (HH:MM:SS, updated every second)
  • Logo rune glows/pulses like HTML
"""

from __future__ import annotations

import math
import os
import queue
import random
import sys
import threading
import time
import ctypes
import ctypes.wintypes
import platform
import tkinter as tk

# Ensure the runescript package root is on sys.path so `core` is importable
# regardless of where gui.py is launched from.
_GUI_DIR  = os.path.dirname(os.path.abspath(__file__))   # .../runescript/gui/
_PKG_ROOT = os.path.dirname(_GUI_DIR)                     # .../runescript/
if _PKG_ROOT not in sys.path:
    sys.path.insert(0, _PKG_ROOT)
from PIL import Image, ImageTk
import tkinter.font as tkfont
from tkinter import colorchooser
from typing import Callable, Dict, List, Optional, Tuple

# ═══════════════════════════════════════════════════════════════════════════
#  FONT RESOLUTION
#  tkinter font families are only queryable after a Tk() window exists.
#  We defer the check to _resolve_fonts(), called once inside RuneScriptApp.__init__
#  after self.root is created.  Module-level names are set to safe fallbacks
#  initially, then replaced in-place so all widget constructors that run
#  after _resolve_fonts() pick up the real names.
# ═══════════════════════════════════════════════════════════════════════════

# These are set at module level so Font tuples built below reference them.
# _resolve_fonts() overwrites them after Tk() exists.
_CINZEL   = "Georgia"
_CINZEL_D = "Georgia"   # Cinzel Decorative — used for large headings
_FELL     = "Georgia"
_MONO_ALT = "Courier New"


def _resolve_fonts(root: tk.Tk) -> None:
    """
    Called once after the real Tk root exists.
    Checks which families are actually available and updates the three
    module-level font-name strings in place.
    All font tuples (F_*) are rebuilt immediately after so every widget
    constructed after this call uses the correct family.
    """
    global _CINZEL, _CINZEL_D, _FELL, _MONO_ALT
    global F_TITLE, F_CINZEL, F_CINZEL_S, F_CINZEL_T
    global F_FELL, F_FELL_S, F_MONO, F_MONO_S
    global F_SMALL, F_STAT, F_STAT_S, F_NAV, F_LOGO, F_LOGO_SUB

    families = set(tkfont.families(root))

    _CINZEL   = "Cinzel"             if "Cinzel"             in families else "Georgia"
    _CINZEL_D = "Cinzel Decorative"  if "Cinzel Decorative"  in families else _CINZEL
    _FELL     = "IM Fell English"    if "IM Fell English"    in families else "Georgia"
    _MONO_ALT = "Share Tech Mono"    if "Share Tech Mono"    in families else "Courier New"

    # Read persisted font scale (1.0 = default, set from Settings page)
    try:
        from core.settings_store import get_store as _gs
        _scale = float(_gs().get("font_scale", 1.0))
    except Exception:
        _scale = 1.0
    def _s(n): return max(6, round(n * _scale))

    # F_TITLE and F_LOGO use Cinzel Decorative — the large decorative heading face
    F_TITLE    = (_CINZEL_D, _s(18), "bold")
    F_CINZEL   = (_CINZEL,   _s(9),  "bold")
    F_CINZEL_S = (_CINZEL,   _s(8),  "bold")
    F_CINZEL_T = (_CINZEL,   _s(7))
    F_FELL     = (_FELL,     _s(11))
    F_FELL_S   = (_FELL,     _s(10))
    F_MONO     = (_MONO_ALT, _s(9))
    F_MONO_S   = (_MONO_ALT, _s(8))
    F_SMALL    = (_CINZEL,   _s(7))
    F_STAT     = (_MONO_ALT, _s(16), "bold")
    F_STAT_S   = (_MONO_ALT, _s(7))
    F_NAV      = (_CINZEL,   _s(8),  "bold")
    F_LOGO     = (_CINZEL_D, _s(14), "bold")
    F_LOGO_SUB = (_MONO_ALT, _s(7))



# ═══════════════════════════════════════════════════════════════════════════
#  PALETTE
# ═══════════════════════════════════════════════════════════════════════════
C = {
    "stone_darkest":  "#0d0b08",
    "stone_dark":     "#141109",
    "stone_mid":      "#1e1a12",
    "stone_light":    "#2a2418",
    "stone_border":   "#3d3422",
    "stone_hi":       "#4a3f28",

    "gold_deep":      "#7a5c1e",
    "gold_mid":       "#b8892a",
    "gold_bright":    "#d4a843",
    "gold_shine":     "#f0cc6a",
    "gold_pale":      "#f5dfa0",

    "amber":          "#c87d20",
    "rune_blue":      "#4a8fa8",
    "rune_cyan":      "#6fc0d0",
    "rune_green":     "#5a9e6a",

    "text":           "#e8d5a0",
    "text_sec":       "#a09060",
    "text_dim":       "#6a5c3a",
    "text_mono":      "#b8c8a0",

    "status_run":     "#5aad6a",
    "status_idle":    "#c8a040",
    "status_stop":    "#a04040",
    "status_pause":   "#6080b0",

    # Neon variants for antiban toggles
    "neon_green":     "#2d6e3e",
    "neon_green_dim": "#1a3d24",
}

# ── Fonts (reduced sizes to match HTML compactness) ────────────────────────
F_TITLE    = (_CINZEL_D, 18, "bold")
F_CINZEL   = (_CINZEL,   9, "bold")
F_CINZEL_S = (_CINZEL,   8, "bold")
F_CINZEL_T = (_CINZEL,   7)          # tiny — section labels, footer
F_FELL     = (_FELL,    11)
F_FELL_S   = (_FELL,    10)
F_MONO     = (_MONO_ALT, 9)
F_MONO_S   = (_MONO_ALT, 8)
F_SMALL    = (_CINZEL,   7)
F_STAT     = (_MONO_ALT,16, "bold")
F_STAT_S   = (_MONO_ALT, 7)
F_NAV      = (_CINZEL,   8, "bold")
F_LOGO     = (_CINZEL_D, 14, "bold")
F_LOGO_SUB = (_MONO_ALT, 7)


# ═══════════════════════════════════════════════════════════════════════════
#  SKILL / SIDEBAR DATA
# ═══════════════════════════════════════════════════════════════════════════

SIDEBAR_SECTIONS = [
    ("Gathering", [
        ("Woodcutting", "🪓", "#5a9e6a", "Oak · Draynor Village",  True,  True),
        ("Mining",      "⛏",  "#8a7a6a", "Iron · Al Kharid",       False, False),
        ("Fishing",     "🎣", "#4a8fa8", "Lobster · Catherby",     False, False),
        ("Farming",     "🌿", "#5a7a3a", "Herb runs",              False, False),
        ("Hunter",      "🦊", "#7a6040", "Chinchompas",            False, False),
    ]),
    ("Processing", [
        ("Firemaking",  "🔥", "#c87d20", "Maple logs · GE",        False, True),
        ("Cooking",     "🍖", "#a04040", "Sharks · Rogues Den",    False, False),
        ("Smithing",    "⚒",  "#8a7060", "Steel bars · Edgeville", False, False),
        ("Crafting",    "💎", "#b8892a", "Gem cutting",            False, False),
        ("Fletching",   "🏹", "#7a5c1e", "Bow stringing",          False, False),
        ("Herblore",    "🧪", "#5a8a4a", "Potions",                False, False),
    ]),
    ("Artisan", [
        ("Runecrafting","✦",  "#4a8fa8", "ZMI altar",              False, False),
        ("Construction","🏠", "#9a8060", "Oak larders",            False, False),
    ]),
    ("Support", [
        ("Agility",     "🏃", "#6080b0", "Seers rooftop",          False, False),
        ("Thieving",    "🃏", "#504060", "Master farmer",          False, False),
        ("Slayer",      "💀", "#8a4040", "Duradel tasks",          False, False),
        ("Prayer",      "✝",  "#d4a843", "Gilded altar",           False, False),
        ("Magic",       "🔮", "#6a5abf", "Alching",                False, False),
        ("Combat",      "⚔",  "#a04040", "NMZ / Sand crabs",      False, False),
    ]),
]

# Skill metadata — used by the dynamic skills panel
SKILL_META = {
    "Woodcutting": ("🪓", "#5a9e6a"),
    "Mining":      ("⛏",  "#8a7a6a"),
    "Fishing":     ("🎣", "#4a8fa8"),
    "Firemaking":  ("🔥", "#c87d20"),
    "Cooking":     ("🍖", "#a04040"),
    "Smithing":    ("⚒",  "#8a7060"),
    "Crafting":    ("💎", "#b8892a"),
    "Fletching":   ("🏹", "#7a5c1e"),
    "Herblore":    ("🧪", "#5a8a4a"),
    "Agility":     ("🏃", "#6080b0"),
    "Thieving":    ("🃏", "#504060"),
    "Slayer":      ("💀", "#8a4040"),
    "Farming":     ("🌿", "#5a7a3a"),
    "Runecrafting":("✦",  "#4a8fa8"),
    "Hunter":      ("🦊", "#7a6040"),
    "Construction":("🏠", "#9a8060"),
    "Prayer":      ("✝",  "#d4a843"),
    "Magic":       ("🔮", "#6a5abf"),
    "Attack":      ("⚔",  "#a04040"),
    "Strength":    ("💪", "#a04040"),
    "Defence":     ("🛡",  "#4a6080"),
    "Ranged":      ("🏹", "#4a7a4a"),
    "Hitpoints":   ("❤",  "#a04040"),
}

ANTIBAN_SETTINGS = [
    ("Random delays",    True),
    ("Camera rotation",  True),
    ("Tab hopping",      False),
    ("Mouse drift",      True),
    ("Break handler",    True),
]


# ═══════════════════════════════════════════════════════════════════════════
#  HELPERS
# ═══════════════════════════════════════════════════════════════════════════

def _sep(parent, color=None, padx=0, pady=(4, 4)):
    tk.Frame(parent, bg=color or C["stone_border"],
             height=1).pack(fill="x", padx=padx, pady=pady)


def _section_header(parent, title: str, bg: str = None):
    bg = bg or C["stone_darkest"]
    row = tk.Frame(parent, bg=bg)
    row.pack(fill="x", pady=(8, 5))
    tk.Label(row, text=title.upper(), font=F_CINZEL_S,
             fg=C["gold_mid"], bg=bg).pack(side="left", padx=(0, 8))
    tk.Frame(row, bg=C["stone_border"], height=1).pack(
        side="left", fill="x", expand=True)


def _panel(parent, **kw) -> tk.Frame:
    return tk.Frame(parent, bg=C["stone_mid"],
                    highlightthickness=1,
                    highlightbackground=C["stone_border"],
                    **kw)


def _label(parent, text, font=None, fg=None, bg=None, **kw):
    return tk.Label(parent, text=text,
                    font=font or F_FELL_S,
                    fg=fg or C["text_sec"],
                    bg=bg or C["stone_mid"], **kw)


def _invisible_scroll(canvas):
    """
    Make a Canvas scroll on mouse-wheel without any visible scrollbar.
    Works on Windows/macOS (MouseWheel) and Linux (Button-4/5).
    Only scrolls when content actually overflows the canvas height.
    """
    def _on_wheel(e):
        bbox = canvas.bbox("all")
        if not bbox or bbox[3] <= canvas.winfo_height():
            return
        if e.num == 4:
            canvas.yview_scroll(-1, "units")
        elif e.num == 5:
            canvas.yview_scroll(1, "units")
        elif e.delta:
            canvas.yview_scroll(-1 if e.delta > 0 else 1, "units")
    def _bind_tree(w):
        try:
            w.bind("<MouseWheel>", _on_wheel)
            w.bind("<Button-4>",   _on_wheel)
            w.bind("<Button-5>",   _on_wheel)
            for child in w.winfo_children():
                if isinstance(child, tk.BaseWidget):
                    _bind_tree(child)
        except Exception:
            pass

    _bind_tree(canvas)
    canvas.bind("<Configure>", lambda e: _bind_tree(canvas))



# ═══════════════════════════════════════════════════════════════════════════
#  NEON TOGGLE  — pill shape, glowing thumb when on
# ═══════════════════════════════════════════════════════════════════════════

class Toggle(tk.Canvas):
    """
    Rectangular toggle matching the reference screenshot.
      OFF: dark track, dim square thumb on left, no glow
      ON:  dark track with green border, bright square thumb on right,
           fog-glow halo pulsing on sine wave (same logic as GlowDot)
    """
    W, H  = 44, 16
    PAD   = 3
    TH    = H - PAD * 2   # 10px thumb

    def __init__(self, parent, initial=True, on_change: Callable = None, **kw):
        self._bg = kw.pop("bg", C["stone_mid"])
        super().__init__(parent, width=self.W, height=self.H,
                         highlightthickness=0, bg=self._bg)
        self._on    = initial
        self._cb    = on_change
        self._phase = 0.0
        self._draw(1.0)
        self._animate()
        self.bind("<ButtonPress-1>", self._toggle)
        self.config(cursor="hand2")

    @staticmethod
    def _parse(h):
        h = h.lstrip("#")
        return int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)

    @staticmethod
    def _blend(fr, fg, fb, tr, tg, tb, t):
        return (int(fr + (tr - fr) * t),
                int(fg + (tg - fg) * t),
                int(fb + (tb - fb) * t))

    def _draw(self, glow_t: float):
        self.delete("all")
        w, h, pad, th = self.W, self.H, self.PAD, self.TH

        if self._on:
            # Track with green border
            self.create_rectangle(0, 0, w - 1, h - 1,
                                  fill=C["stone_darkest"],
                                  outline=C["neon_green"], width=1)
            # Very faint green haze filling the whole track interior
            gr, gg, gb = self._parse(C["neon_green"])
            br, bg_, bb = self._parse(self._bg)
            rh, gh, bh = self._blend(br, bg_, bb, gr, gg, gb, 0.20 * glow_t)
            self.create_rectangle(1, 1, w - 1, h - 1,
                                  fill=f"#{rh:02x}{gh:02x}{bh:02x}", outline="")
            # Thumb sits PAD away from right border
            tx = w - pad - th - 1
            gr, gg, gb = self._parse(C["neon_green"])
            br, bg_, bb = self._parse(self._bg)

            r1, g1, b1 = self._blend(br, bg_, bb, gr, gg, gb, 0.20 * glow_t)
            self.create_rectangle(tx - 2, pad - 2,
                                  tx + th + 2, pad + th + 2,
                                  fill=f"#{r1:02x}{g1:02x}{b1:02x}", outline="")
            r2, g2, b2 = self._blend(br, bg_, bb, gr, gg, gb, 0.45 * glow_t)
            self.create_rectangle(tx - 1, pad - 1,
                                  tx + th + 1, pad + th + 1,
                                  fill=f"#{r2:02x}{g2:02x}{b2:02x}", outline="")
            self.create_rectangle(tx, pad, tx + th - 1, pad + th - 1,
                                  fill=C["neon_green"], outline=C["neon_green"])
        else:
            # Track with dim border
            self.create_rectangle(0, 0, w - 1, h - 1,
                                  fill=C["stone_darkest"],
                                  outline=C["stone_border"], width=1)
            # Thumb sits PAD away from left border
            tx = pad
            self.create_rectangle(tx, pad, tx + th - 1, pad + th - 1,
                                  fill=C["stone_hi"], outline=C["stone_border"])

    def _animate(self):
        if self._on:
            # Gentle constant pulse — stays mostly bright, small breathe
            self._phase = (self._phase + 0.04) % (2 * math.pi)
            self._draw(0.85 + 0.15 * math.sin(self._phase))
        self.after(60, self._animate)

    def _toggle(self, _=None):
        self._on = not self._on
        self._phase = 0.0
        self._draw(1.0)
        if self._cb:
            self._cb(self._on)

    @property
    def value(self) -> bool:
        return self._on


# ═══════════════════════════════════════════════════════════════════════════
#  PULSING STATUS DOT
# ═══════════════════════════════════════════════════════════════════════════

class PulseDot(tk.Canvas):
    def __init__(self, parent, size=7, color=None, **kw):
        kw.setdefault("bg", C["stone_mid"])
        super().__init__(parent, width=size*3, height=size*3,
                         highlightthickness=0, **kw)
        self._size  = size
        self._color = color or C["status_run"]
        self._phase = 0.0
        self._animate()

    def set_color(self, c):
        self._color = c

    def _animate(self):
        self._phase = (self._phase + 0.10) % (2 * math.pi)
        alpha_f = 0.5 + 0.5 * math.sin(self._phase)
        s = self._size
        pad = s
        self.delete("all")
        # Outer glow ring
        r_o = s + int(s * 0.6 * alpha_f)
        self.create_oval(pad - r_o//2, pad - r_o//2,
                         pad + r_o//2, pad + r_o//2,
                         fill="", outline=self._color,
                         width=1 if alpha_f > 0.5 else 0)
        # Core dot
        self.create_oval(pad - s//2, pad - s//2,
                         pad + s//2, pad + s//2,
                         fill=self._color, outline="")
        self.after(50, self._animate)


# ═══════════════════════════════════════════════════════════════════════════
#  GLOW DOT  — static status dot with layered fog-glow like HTML box-shadow
# ═══════════════════════════════════════════════════════════════════════════

class GlowDot(tk.Canvas):
    """
    Small 12×12 canvas. Draws a crisp 4px core dot with 2-3 soft halo rings
    that blend into the background — matching the HTML fog-glow look.
    Active (green) dot pulses its outermost halo.
    """
    S = 12  # canvas size

    def __init__(self, parent, color=None, pulse=False, **kw):
        bg = kw.pop("bg", C["stone_dark"])
        super().__init__(parent, width=self.S, height=self.S,
                         highlightthickness=0, bg=bg)
        self._color = color or C["stone_hi"]
        self._bg    = bg
        self._pulse = pulse
        self._phase = 0.0
        self._draw(1.0)
        if pulse:
            self._animate()

    def _parse(self, h):
        h = h.lstrip("#")
        return int(h[0:2],16), int(h[2:4],16), int(h[4:6],16)

    def _blend(self, fr, fg, fb, tr, tg, tb, t):
        return (int(fr+(tr-fr)*t), int(fg+(tg-fg)*t), int(fb+(tb-fb)*t))

    def _draw(self, t):
        self.delete("all")
        cx = cy = self.S // 2
        cr, cg, cb = self._parse(self._color)
        br, bg_, bb = self._parse(self._bg)

        # Outermost halo — very faint, blends almost fully into bg
        r1, g1, b1 = self._blend(br, bg_, bb, cr, cg, cb, 0.12 * t)
        self.create_oval(cx-5, cy-5, cx+5, cy+5,
                         fill=f"#{r1:02x}{g1:02x}{b1:02x}", outline="")

        # Mid halo
        r2, g2, b2 = self._blend(br, bg_, bb, cr, cg, cb, 0.30 * t)
        self.create_oval(cx-3, cy-3, cx+3, cy+3,
                         fill=f"#{r2:02x}{g2:02x}{b2:02x}", outline="")

        # Crisp core
        self.create_oval(cx-2, cy-2, cx+2, cy+2,
                         fill=self._color, outline="")

    def _animate(self):
        self._phase = (self._phase + 0.08) % (2 * math.pi)
        self._draw(0.5 + 0.5 * math.sin(self._phase))
        self.after(60, self._animate)

    def update_bg(self, bg):
        self._bg = bg
        self.config(bg=bg)
        self._draw(1.0)


# ═══════════════════════════════════════════════════════════════════════════
#  MINIMAP + ANIMATED LOCATION
# ═══════════════════════════════════════════════════════════════════════════

class MinimapWidget(tk.Frame):
    """
    Minimap widget that mirrors the live in-game minimap via screen capture.
    Uses MinimapTracker to get a clean circular-masked frame.
    Falls back to animated placeholder dots when the game window isn't found.
    """
    MAP_SIZE = 154   # matches calibrated capture diameter

    def __init__(self, parent, **kw):
        kw.setdefault("bg", C["stone_darkest"])
        super().__init__(parent, **kw)
        self._coord_phase  = 0.0
        self._pulse_phase  = 0.0
        self._live         = False
        self._photo        = None
        self._player       = None
        self._tracker      = None
        self._loc_detector = None
        self._xp_watcher   = None
        self._location_live = False
        self._build()

    # Background colour matching C["stone_darkest"] — used to fill circle corners
    _BG_COLOUR = (13, 11, 8)   # #0d0b08

    def _build(self):
        outer = tk.Frame(self, bg=C["stone_darkest"])
        outer.pack(fill="x")

        # Centre the canvas in the panel
        canvas_frame = tk.Frame(outer, bg=C["stone_darkest"])
        canvas_frame.pack(pady=6)

        self._c = tk.Canvas(canvas_frame,
                            width=self.MAP_SIZE, height=self.MAP_SIZE,
                            bg=C["stone_darkest"],
                            highlightthickness=0)
        self._c.pack()

        self._draw_placeholder()

        self._coord_var = tk.StringVar(value="— · — · —")
        self._coord_lbl = tk.Label(outer, textvariable=self._coord_var,
                 font=F_MONO_S, fg=C["text_dim"],
                 bg=C["stone_darkest"])
        self._coord_lbl.pack(pady=(2, 0))

        self._loc_var = tk.StringVar(value="SCANNING...")
        self._loc_lbl = tk.Label(outer, textvariable=self._loc_var,
                 font=F_CINZEL_S, fg=C["text_dim"],
                 bg=C["stone_darkest"])
        self._loc_lbl.pack(pady=(0, 6))

        self._animate_location()
        self._poll_capture()
        self._start_location_detector()
        self._start_xp_watcher()

    def _composite_frame(self, frame_bgr):
        """
        Composite the circular minimap onto the stone_darkest background
        so the masked corners match the UI instead of showing as black squares.
        Returns a PIL Image ready for PhotoImage.
        """
        import numpy as np
        s = self.MAP_SIZE
        r = s // 2

        # Build circular alpha mask
        y, x = np.ogrid[:s, :s]
        mask = ((x - r) ** 2 + (y - r) ** 2 <= r ** 2).astype(np.uint8) * 255

        # Background filled with stone_darkest
        bg = np.full((s, s, 3), self._BG_COLOUR, dtype=np.uint8)

        # Composite: where mask=255 use frame, else bg
        rgb = frame_bgr[:, :, ::-1].astype(np.uint8)
        alpha = mask[:, :, np.newaxis] / 255.0
        composited = (rgb * alpha + bg * (1 - alpha)).astype(np.uint8)
        return Image.fromarray(composited)

    def _draw_border(self):
        """
        Draw a smooth gradient gold border ring.
        Light source at top-left: highlight at ~135° fading to shadow at ~315°.
        Each degree gets its own arc so the transition is seamless.
        """
        self._c.delete("border")
        s   = self.MAP_SIZE
        pad = 2

        # Colour stops in RGB — keyed by angle (0=right, going CCW in tkinter)
        # We want: top (90°) = bright, bottom (270°) = dark
        # Interpolate between gold_shine at top and gold_deep at bottom
        def _hex_to_rgb(h):
            h = h.lstrip("#")
            return int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)

        def _lerp(a, b, t):
            return tuple(int(a[i] + (b[i] - a[i]) * t) for i in range(3))

        def _rgb_to_hex(c):
            return "#{:02x}{:02x}{:02x}".format(*c)

        shine  = _hex_to_rgb(C["gold_shine"])   # brightest — top-left
        bright = _hex_to_rgb(C["gold_bright"])
        mid    = _hex_to_rgb(C["gold_mid"])
        deep   = _hex_to_rgb(C["gold_deep"])    # darkest  — bottom-right

        import math
        for angle in range(0, 360, 2):   # step 2° — smooth but not slow
            # Convert angle to 0..1 brightness factor
            # Peak brightness at 120° (top-left), darkest at 300° (bottom-right)
            peak = 120
            diff = ((angle - peak) + 180) % 360 - 180   # signed -180..180
            t = (diff + 180) / 360.0   # 0=brightest, 1→0.5→brightest again

            # Map t to colour: 0.0=shine, 0.25=bright, 0.5=mid, 0.75→1.0=deep
            if t < 0.25:
                colour = _lerp(shine, bright, t / 0.25)
            elif t < 0.5:
                colour = _lerp(bright, mid, (t - 0.25) / 0.25)
            elif t < 0.75:
                colour = _lerp(mid, deep, (t - 0.5) / 0.25)
            else:
                colour = _lerp(deep, shine, (t - 0.75) / 0.25)

            self._c.create_arc(pad, pad, s - pad, s - pad,
                               start=angle, extent=3,
                               outline=_rgb_to_hex(colour), width=3,
                               style="arc", tags="border")

    def _draw_placeholder(self):
        """Static glow-dot placeholder shown when game isn't running."""
        self._c.delete("all")
        trees = [(30,40),(35,55),(28,62),(42,48),(38,35),(55,60),(60,42)]
        water = [(70,25),(72,20),(68,30)]

        def _glow_dot(cx, cy, colour, core=2, halo=3):
            def _p(h): h=h.lstrip("#"); return int(h[0:2],16),int(h[2:4],16),int(h[4:6],16)
            def _b(fc, tc, t): return tuple(int(a+(b-a)*t) for a,b in zip(fc,tc))
            def _hex(c): return "#{:02x}{:02x}{:02x}".format(*c)
            fc, tc = _p("#0a140a"), _p(colour)
            self._c.create_oval(cx-halo-2, cy-halo-2, cx+halo+2, cy+halo+2,
                                fill=_hex(_b(fc,tc,0.18)), outline="")
            self._c.create_oval(cx-halo, cy-halo, cx+halo, cy+halo,
                                fill=_hex(_b(fc,tc,0.40)), outline="")
            self._c.create_oval(cx-core, cy-core, cx+core, cy+core,
                                fill=colour, outline="")

        for (ty, tx) in trees:
            _glow_dot(tx, ty, C["rune_green"], core=2, halo=3)
        for (wy, wx) in water:
            _glow_dot(wx, wy, C["rune_blue"], core=1, halo=2)

        self._player = self._c.create_oval(
            self.MAP_SIZE//2 - 3, self.MAP_SIZE//2 - 3,
            self.MAP_SIZE//2 + 3, self.MAP_SIZE//2 + 3,
            fill="white", outline="")
        self._draw_border()
        self._pulse()

    def _poll_capture(self):
        """
        Grab a clean circular-masked minimap frame via MinimapTracker every 100 ms.
        Also updates coord/location labels from RSEye position if available.
        """
        try:
            if self._tracker is None:
                from core.minimap import MinimapTracker
                self._tracker = MinimapTracker()

            frame = self._tracker.get_frame()
            if frame is not None:
                img  = self._composite_frame(frame)
                self._photo = ImageTk.PhotoImage(img)
                if not self._live:
                    self._c.delete("all")
                    self._live = True
                self._c.delete("img")
                self._c.create_image(0, 0, anchor="nw",
                                     image=self._photo, tags="img")
                self._c.delete("border")
                self._draw_border()
            else:
                if self._live:
                    self._live = False
                    self._draw_placeholder()
        except Exception as e:
            if not getattr(self, "_capture_err_shown", False):
                self._capture_err_shown = True
                print(f"[Minimap] capture error: {e}")

        # Update coord/location labels from RSEye position (preferred)
        # Falls back to LocationDetector OCR result if RSEye not connected.
        try:
            pos = None
            try:
                from core.position_tracker import get_tracker as _get_pos
                pt = _get_pos()
                if pt.plugin_available:
                    pos = pt.position
            except Exception:
                pass

            if pos is None and self._loc_detector is not None:
                coords = self._loc_detector.coords
                if coords:
                    pos = coords

            if pos is not None:
                x, y, z = pos
                from core.detection.location_detector import lookup_location, format_coords
                name = lookup_location(x, y, z)
                raw  = format_coords(x, y, z)
                self._coord_var.set(raw)
                self._loc_var.set(name.upper() if name else f"{x}, {y}")
                self._location_live = True
        except Exception:
            pass

        self._c.after(100, self._poll_capture)

    def _pulse(self):
        if self._live:
            return   # no pulsing dot when showing real minimap
        self._pulse_phase = (self._pulse_phase + 0.12) % (2 * math.pi)
        v = int(180 + 75 * math.sin(self._pulse_phase))
        if self._player:
            self._c.itemconfig(self._player, fill=f"#{v:02x}{v:02x}{v:02x}")
        self._c.after(60, self._pulse)

    def _animate_location(self):
        self._coord_phase = (self._coord_phase + 0.07) % (2 * math.pi)
        t = 0.5 + 0.5 * math.sin(self._coord_phase)
        if self._location_live:
            self._loc_lbl.config(fg=C["gold_bright"])
            self._coord_lbl.config(fg=C["text_sec"])
        else:
            r1,g1,b1 = 0x6a,0x5c,0x3a
            r2,g2,b2 = 0xb8,0x89,0x2a
            r = int(r1+(r2-r1)*t); g = int(g1+(g2-g1)*t); b = int(b1+(b2-b1)*t)
            self._loc_lbl.config(fg=f"#{r:02x}{g:02x}{b:02x}")
            rc = int(0x6a*(0.6+0.4*t)); gc = int(0x5c*(0.6+0.4*t)); bc = int(0x3a*(0.6+0.4*t))
            self._coord_lbl.config(fg=f"#{rc:02x}{gc:02x}{bc:02x}")
        self._loc_lbl.after(60, self._animate_location)

    def _start_location_detector(self):
        try:
            from core.detection.location_detector import LocationDetector
            from core.position_tracker import get_tracker as _get_pos
            self._loc_detector = LocationDetector(interval=0.5)
            # Wire RSEye into the detector so scripts using is_near() etc. get
            # accurate coords — OCR tick is suppressed while RSEye is live.
            pos_tracker = _get_pos()
            _prev_pos_cb = pos_tracker.on_position
            def _on_rseye_pos(x, y, plane):
                try:
                    self._loc_detector.update_from_coords(x, y, plane)
                except Exception:
                    pass
                if _prev_pos_cb:
                    try: _prev_pos_cb(x, y, plane)
                    except Exception: pass
            pos_tracker.on_position = _on_rseye_pos
            self._loc_detector.start()
        except Exception as e:
            print(f"[MinimapWidget] LocationDetector start failed: {e}")

    def _start_xp_watcher(self):
        try:
            from core.xp_drop import get_watcher
            self._xp_watcher = get_watcher()
            self._xp_watcher.on_drop = self._on_xp_drop
            self._xp_watcher.start()
        except Exception as e:
            print(f"[MinimapWidget] XPDropWatcher start failed: {e}")

    def _on_xp_drop(self, skill: str, xp: int, new_level: int):
        """Called from XPDropWatcher thread — schedule GUI refresh safely."""
        def _apply():
            try:
                from scripts.base_script import BaseScript
                tracker  = BaseScript.get_skill_tracker()
                snapshot = tracker.snapshot()
                app = self.winfo_toplevel()
                rp  = getattr(app, "_right_panel", None)
                if rp:
                    rp.update_skill_snapshot(snapshot)
            except Exception:
                pass
        try:
            self._loc_lbl.after(0, _apply)
        except Exception:
            pass

    def _on_location_update(self, coords, name: str, raw: str):
        def _apply():
            try:
                self._coord_var.set(raw)
                self._loc_var.set(name.upper() if name else f"{coords[0]}, {coords[1]}")
                self._location_live = True
            except Exception:
                pass
        try:
            self._loc_lbl.after(0, _apply)
        except Exception:
            pass


# ═══════════════════════════════════════════════════════════════════════════
#  XP BAR  — stays gold at all fill levels, shimmer animation
# ═══════════════════════════════════════════════════════════════════════════

class XPBar(tk.Frame):
    def __init__(self, parent, skill="Woodcutting", level=72,
                 current=847340, goal=1210421, **kw):
        kw.setdefault("bg", C["stone_mid"])
        super().__init__(parent, **kw)
        self._pct = min(1.0, current / max(goal, 1))
        self._shimmer_phase = 0.0
        self._build(skill, level, current, goal)

    def _build(self, skill, level, current, goal):
        hrow = tk.Frame(self, bg=C["stone_mid"])
        hrow.pack(fill="x", pady=(3, 2))
        tk.Label(hrow, text=f"{skill} XP  ·  Level {level}",
                 font=F_MONO_S, fg=C["text_sec"],
                 bg=C["stone_mid"]).pack(side="left")
        tk.Label(hrow, text=f"{current:,} / {goal:,} xp",
                 font=F_MONO_S, fg=C["text_sec"],
                 bg=C["stone_mid"]).pack(side="right")

        track = tk.Frame(self, bg="#0a0800",
                          highlightthickness=1,
                          highlightbackground=C["stone_border"],
                          height=7)
        track.pack(fill="x")
        track.pack_propagate(False)

        self._bar_canvas = tk.Canvas(track, height=7,
                                      bg="#0a0800",
                                      highlightthickness=0)
        self._bar_canvas.pack(fill="x", expand=True)
        self._bar_canvas.bind("<Configure>", self._redraw)
        self._shimmer()

    # Gold gradient stops: dark → mid → bright → shine
    _GRAD = (
        (0x7a, 0x5c, 0x1e),   # gold_deep
        (0xb8, 0x89, 0x2a),   # gold_mid
        (0xd4, 0xa8, 0x43),   # gold_bright
        (0xf0, 0xcc, 0x6a),   # gold_shine
    )

    def _grad_colour(self, t: float) -> str:
        """Smooth interpolation across _GRAD stops for t in [0, 1]."""
        stops = self._GRAD
        n = len(stops) - 1
        scaled = t * n
        lo = min(int(scaled), n - 1)
        hi = lo + 1
        frac = scaled - lo
        r = int(stops[lo][0] + (stops[hi][0] - stops[lo][0]) * frac)
        g = int(stops[lo][1] + (stops[hi][1] - stops[lo][1]) * frac)
        b = int(stops[lo][2] + (stops[hi][2] - stops[lo][2]) * frac)
        return f"#{r:02x}{g:02x}{b:02x}"

    def _redraw(self, e=None):
        w = self._bar_canvas.winfo_width()
        h = self._bar_canvas.winfo_height()
        if w <= 1 or h <= 1:
            return
        fill_w = int(w * self._pct)

        try:
            import numpy as np
            from PIL import Image as _PILImg, ImageTk as _ITk

            # Build pixel array: shape (h, w, 3)
            xs = np.arange(w, dtype=np.float32)
            # Background (empty part)
            img = np.zeros((h, w, 3), dtype=np.uint8)
            img[:, :, :] = [10, 8, 0]

            if fill_w > 0:
                t = xs[:fill_w] / max(fill_w - 1, 1)
                stops = self._GRAD
                # Vectorised gradient interpolation
                t4 = t * (len(stops) - 1)
                lo = np.clip(t4.astype(int), 0, len(stops) - 2)
                hi = lo + 1
                frac = (t4 - lo)[:, np.newaxis]
                s_lo = np.array([stops[i] for i in lo], dtype=np.float32)
                s_hi = np.array([stops[i] for i in hi], dtype=np.float32)
                grad = (s_lo + (s_hi - s_lo) * frac).astype(np.uint8)  # (fill_w, 3)

                # Shimmer overlay
                cx = int(fill_w * ((self._shimmer_phase % (2 * math.pi)) / (2 * math.pi)))
                radius = max(8, fill_w // 6)
                dist = np.abs(xs[:fill_w] - cx) / radius
                strength = np.exp(-4.0 * dist * dist).astype(np.float32)[:, np.newaxis]
                shine = np.array([0xf0, 0xf5, 0xb0], dtype=np.float32)
                shimmered = np.clip(
                    grad.astype(np.float32) + (shine - grad.astype(np.float32)) * strength * 0.7,
                    0, 255).astype(np.uint8)

                img[:, :fill_w, :] = shimmered[np.newaxis, :, :]

            pil = _PILImg.fromarray(img, 'RGB')
            photo = _ITk.PhotoImage(pil)
            self._bar_canvas.delete("all")
            self._bar_canvas.create_image(0, 0, anchor="nw", image=photo)
            self._bar_photo = photo  # prevent GC

        except ImportError:
            # Fallback: single rectangle, no shimmer
            self._bar_canvas.delete("all")
            if fill_w > 0:
                self._bar_canvas.create_rectangle(
                    0, 0, fill_w, h, fill=C["gold_mid"], outline="")

    def _shimmer(self):
        self._shimmer_phase = (self._shimmer_phase + 0.03) % (2 * math.pi)
        self._redraw()
        self._bar_canvas.after(50, self._shimmer)


# ═══════════════════════════════════════════════════════════════════════════
#  STAT CELL
# ═══════════════════════════════════════════════════════════════════════════

class StatCell(tk.Frame):
    def __init__(self, parent, label: str,
                 value: str = "—", unit: str = "", delta: str = "", **kw):
        super().__init__(parent,
                         bg=C["stone_darkest"],
                         highlightthickness=1,
                         highlightbackground=C["stone_border"],
                         **kw)
        self._val_var   = tk.StringVar(value=value)
        self._delta_var = tk.StringVar(value=delta)

        tk.Label(self, text=label.upper(), font=F_CINZEL_T,
                 fg=C["text_dim"], bg=C["stone_darkest"]).pack(
                     anchor="w", padx=8, pady=(7, 1))

        val_row = tk.Frame(self, bg=C["stone_darkest"])
        val_row.pack(anchor="w", padx=8)
        tk.Label(val_row, textvariable=self._val_var,
                 font=F_STAT, fg=C["gold_pale"],
                 bg=C["stone_darkest"]).pack(side="left")
        if unit:
            tk.Label(val_row, text=unit, font=F_MONO_S,
                     fg=C["text_sec"],
                     bg=C["stone_darkest"]).pack(side="left", padx=(2, 0))

        if delta:
            tk.Label(self, textvariable=self._delta_var,
                     font=F_STAT_S, fg=C["status_run"],
                     bg=C["stone_darkest"]).pack(anchor="w", padx=8, pady=(0, 5))
        else:
            tk.Frame(self, bg=C["stone_darkest"], height=5).pack()

    def set_value(self, v: str): self._val_var.set(v)
    def set_delta(self, v: str): self._delta_var.set(v)


# ═══════════════════════════════════════════════════════════════════════════
#  LOG CONSOLE
# ═══════════════════════════════════════════════════════════════════════════

class LogConsole(tk.Frame):
    MAX = 60

    def __init__(self, parent, **kw):
        kw.setdefault("bg", C["stone_darkest"])
        super().__init__(parent,
                         highlightthickness=1,
                         highlightbackground=C["stone_border"],
                         **kw)
        self._count = 0
        self._build()

    def _build(self):
        hdr = tk.Frame(self, bg="#050400")
        hdr.pack(fill="x")
        tk.Label(hdr, text="OUTPUT  ·  LIVE FEED",
                 font=F_CINZEL_T, fg=C["text_dim"],
                 bg="#050400").pack(side="left", padx=10, pady=6)
        tk.Button(hdr, text="[ clear ]",
                  font=F_MONO_S, fg=C["text_dim"], bg="#050400",
                  relief="flat", bd=0,
                  activebackground=C["stone_dark"],
                  activeforeground=C["gold_mid"],
                  cursor="hand2",
                  command=self.clear).pack(side="right", padx=10)
        tk.Frame(self, bg=C["stone_border"], height=1).pack(fill="x")

        body = tk.Frame(self, bg=C["stone_darkest"])
        body.pack(fill="both", expand=True)

        self._text = tk.Text(
            body,
            bg=C["stone_darkest"], fg=C["text_sec"],
            font=F_MONO_S,
            relief="flat", bd=0,
            wrap="word",
            state="disabled",
            cursor="arrow",
            padx=10, pady=5,
            selectbackground=C["stone_light"],
        )
        self._text.pack(side="left", fill="both", expand=True)
        _invisible_scroll(self._text)

        self._text.tag_config("ts",    foreground=C["text_dim"])
        self._text.tag_config("info",  foreground=C["rune_cyan"])
        self._text.tag_config("ok",    foreground=C["status_run"])
        self._text.tag_config("warn",  foreground=C["status_idle"])
        self._text.tag_config("error", foreground=C["status_stop"])
        self._text.tag_config("debug", foreground=C["text_dim"])
        self._text.tag_config("msg",   foreground=C["text_sec"])

    def append(self, level: str, message: str):
        self._text.configure(state="normal")
        ts  = time.strftime("%H:%M:%S")
        tag = level.lower()
        if tag not in ("info", "ok", "warn", "error", "debug"):
            tag = "info"
        prefix = {"info": "[INFO]", "ok": "[OK]  ",
                  "warn": "[WARN]", "error": "[ERR] ",
                  "debug": "[DBG] "}.get(tag, "[INFO]")
        self._text.insert("1.0", "\n")
        self._text.insert("1.0", f"  {message}", "msg")
        self._text.insert("1.0", f"  {prefix}", tag)
        self._text.insert("1.0", f"{ts}", "ts")
        self._count += 1
        if self._count > self.MAX:
            self._text.delete(f"{self.MAX + 1}.0", "end")
            self._count = self.MAX
        self._text.configure(state="disabled")

    def clear(self):
        self._text.configure(state="normal")
        self._text.delete("1.0", "end")
        self._text.configure(state="disabled")
        self._count = 0



# ═══════════════════════════════════════════════════════════════════════════
#  ACTIVITY GRAPH  — rolling XP/hr or actions/hr sparkline
# ═══════════════════════════════════════════════════════════════════════════

class ActivityGraph(tk.Frame):
    """
    60-point rolling sparkline showing XP/hr over the session.
    Accepts push_value(n) calls; demo-animates when no live data.
    """
    POINTS  = 60
    H_GRAPH = 56

    def __init__(self, parent, **kw):
        kw.setdefault("bg", C["stone_darkest"])
        super().__init__(parent,
                         highlightthickness=1,
                         highlightbackground=C["stone_border"],
                         **kw)
        self._data:  list  = [0] * self.POINTS
        self._demo         = True   # use demo data until real values arrive
        self._demo_phase   = 0.0
        self._label_var    = tk.StringVar(value="—  xp/hr")
        self._peak_var     = tk.StringVar(value="peak  —")
        self._build()
        self._tick()

    def _build(self):
        hdr = tk.Frame(self, bg=C["stone_mid"])
        hdr.pack(fill="x")
        tk.Label(hdr, text="ACTIVITY", font=F_CINZEL_S,
                 fg=C["text_dim"], bg=C["stone_mid"]).pack(side="left", padx=10, pady=5)
        tk.Label(hdr, textvariable=self._peak_var, font=F_MONO_S,
                 fg=C["text_dim"], bg=C["stone_mid"]).pack(side="right", padx=10)
        tk.Label(hdr, textvariable=self._label_var, font=F_MONO_S,
                 fg=C["gold_bright"], bg=C["stone_mid"]).pack(side="right", padx=4)
        tk.Frame(self, bg=C["stone_border"], height=1).pack(fill="x")

        self._canvas = tk.Canvas(self, bg=C["stone_darkest"],
                                 height=self.H_GRAPH, highlightthickness=0)
        self._canvas.pack(fill="x", padx=1, pady=(4, 4))
        self._canvas.bind("<Configure>", lambda e: self._draw())

    def push_value(self, xp_hr: int):
        self._demo = False
        self._data.append(xp_hr)
        if len(self._data) > self.POINTS:
            self._data.pop(0)
        self._update_labels()
        self._draw()

    def _update_labels(self):
        cur = self._data[-1] if self._data else 0
        peak = max(self._data) if self._data else 0
        self._label_var.set(f"{cur:,}  xp/hr" if cur else "—  xp/hr")
        self._peak_var.set(f"peak  {peak:,}" if peak else "peak  —")

    def _draw(self):
        c = self._canvas
        c.delete("all")
        w = c.winfo_width()
        h = self.H_GRAPH
        if w < 4:
            return

        data  = self._data
        peak  = max(data) if max(data) > 0 else 1
        step  = w / max(len(data) - 1, 1)

        # Grid lines
        for i in range(1, 4):
            y = int(h * i / 4)
            c.create_line(0, y, w, y, fill=C["stone_border"], dash=(2, 6))

        # Build point list
        pts = []
        for i, v in enumerate(data):
            x = int(i * step)
            y = h - 4 - int((v / peak) * (h - 8))
            pts.append((x, y))

        if len(pts) < 2:
            return

        # Filled area under curve — very faint gold
        poly = []
        for x, y in pts:
            poly += [x, y]
        poly += [pts[-1][0], h, pts[0][0], h]
        gr, gg, gb = int("7a", 16), int("5c", 16), int("1e", 16)
        br, bg_, bb = int("09", 16), int("08", 16), int("04", 16)
        r, g, b = (int(br+(gr-br)*0.25), int(bg_+(gg-bg_)*0.25), int(bb+(gb-bb)*0.25))
        c.create_polygon(poly, fill=f"#{r:02x}{g:02x}{b:02x}", outline="")

        # Line
        flat = [v for pt in pts for v in pt]
        c.create_line(flat, fill=C["gold_bright"], width=1, smooth=True)

        # Current value dot
        lx, ly = pts[-1]
        c.create_oval(lx-3, ly-3, lx+3, ly+3,
                      fill=C["gold_bright"], outline=C["stone_darkest"], width=1)

    def _tick(self):
        if self._demo:
            # Idle state — flat line, no animation
            self._data = [0] * self.POINTS
            self._label_var.set("—  xp/hr")
            self._peak_var.set("peak  —")
            self._draw()
        self.after(2000, self._tick)

    def set_idle(self):
        """Call when script stops — resets graph to flat idle state."""
        self._demo = True
        self._data = [0] * self.POINTS
        self._label_var.set("—  xp/hr")
        self._peak_var.set("peak  —")
        self._draw()


# ═══════════════════════════════════════════════════════════════════════════
#  ALERT PANEL  — surface script warnings without burying them in the log
# ═══════════════════════════════════════════════════════════════════════════

class AlertPanel(tk.Frame):
    """
    Compact notification strip. Alerts stack newest-first, max 4 visible.
    push_alert(level, msg) — level in warn / error / ok / info
    """
    MAX_ALERTS = 4

    def __init__(self, parent, **kw):
        kw.setdefault("bg", C["stone_darkest"])
        super().__init__(parent,
                         highlightthickness=1,
                         highlightbackground=C["stone_border"],
                         **kw)
        self._alerts: list = []
        self._rows:   list = []
        self._build()

    def _build(self):
        hdr = tk.Frame(self, bg=C["stone_mid"])
        hdr.pack(fill="x")
        tk.Label(hdr, text="ALERTS", font=F_CINZEL_S,
                 fg=C["text_dim"], bg=C["stone_mid"]).pack(side="left", padx=10, pady=5)
        tk.Button(hdr, text="[ clear ]", font=F_MONO_S,
                  fg=C["text_dim"], bg=C["stone_mid"],
                  relief="flat", bd=0,
                  activebackground=C["stone_dark"],
                  activeforeground=C["gold_mid"],
                  cursor="hand2",
                  command=self.clear).pack(side="right", padx=10)
        tk.Frame(self, bg=C["stone_border"], height=1).pack(fill="x")

        self._body = tk.Frame(self, bg=C["stone_darkest"])
        self._body.pack(fill="x")
        self._empty_label = tk.Label(
            self._body, text="No alerts",
            font=F_MONO_S, fg=C["text_dim"],
            bg=C["stone_darkest"])
        self._empty_label.pack(pady=8)

    _COLOURS = {
        "warn":  ("#7a5c1e", "#d4a843"),   # bg tint, fg
        "error": ("#3d1a1a", "#cc4444"),
        "ok":    ("#0f2d1a", "#2d6e3e"),
        "info":  ("#0d1f2d", "#4a8fa8"),
    }

    def push_alert(self, level: str, msg: str):
        level = level.lower()
        if level not in self._COLOURS:
            level = "info"
        ts = time.strftime("%H:%M:%S")
        self._alerts.insert(0, (level, ts, msg))
        if len(self._alerts) > self.MAX_ALERTS:
            self._alerts = self._alerts[:self.MAX_ALERTS]
        self._refresh()

    def _refresh(self):
        for r in self._rows:
            r.destroy()
        self._rows.clear()

        if not self._alerts:
            self._empty_label.pack(pady=8)
            return
        self._empty_label.pack_forget()

        tag_text = {"warn": "WARN", "error": "ERR", "ok": "OK", "info": "INFO"}

        for level, ts, msg in self._alerts:
            bg_tint, fg_col = self._COLOURS[level]
            row = tk.Frame(self._body, bg=bg_tint)
            row.pack(fill="x", padx=1, pady=1)
            self._rows.append(row)

            tk.Label(row, text=f" {tag_text[level]} ", font=F_CINZEL_T,
                     fg=fg_col, bg=bg_tint).pack(side="left", padx=(6, 2), pady=4)
            tk.Label(row, text=ts, font=F_MONO_S,
                     fg=C["text_dim"], bg=bg_tint).pack(side="left", padx=(0, 8))
            tk.Label(row, text=msg, font=F_MONO_S,
                     fg=fg_col, bg=bg_tint,
                     anchor="w").pack(side="left", fill="x", expand=True, pady=4)

    def clear(self):
        self._alerts.clear()
        self._refresh()


# ═══════════════════════════════════════════════════════════════════════════
#  REPLAY BUFFER TOGGLE  — record last 30s of gameplay
# ═══════════════════════════════════════════════════════════════════════════

class ReplayBufferToggle(tk.Frame):
    """
    Toggle row for the 30-second replay buffer.
    When enabled, scripts can call save_clip() to write the buffer to
    runescript/recordings/YYYY-MM-DD_HH-MM-SS_<script>.mp4
    """
    def __init__(self, parent, **kw):
        kw.setdefault("bg", C["stone_darkest"])
        super().__init__(parent,
                         highlightthickness=1,
                         highlightbackground=C["stone_border"],
                         **kw)
        self._enabled  = False
        self._status   = tk.StringVar(value="INACTIVE")
        self._clips    = tk.StringVar(value="0 clips saved")
        self._clip_count = 0
        self._build()

    def _build(self):
        row = tk.Frame(self, bg=C["stone_mid"])
        row.pack(fill="x")

        tk.Label(row, text="REPLAY BUFFER", font=F_CINZEL_S,
                 fg=C["text_dim"], bg=C["stone_mid"]).pack(side="left", padx=10, pady=6)

        # Status dot + text
        self._dot = GlowDot(row, color=C["stone_hi"], bg=C["stone_mid"])
        self._dot.pack(side="right", padx=(0, 10))
        tk.Label(row, textvariable=self._status, font=F_MONO_S,
                 fg=C["text_dim"], bg=C["stone_mid"]).pack(side="right", padx=(0, 4))
        tk.Label(row, textvariable=self._clips, font=F_MONO_S,
                 fg=C["text_dim"], bg=C["stone_mid"]).pack(side="right", padx=(0, 16))

        tk.Frame(self, bg=C["stone_border"], height=1).pack(fill="x")

        body = tk.Frame(self, bg=C["stone_darkest"])
        body.pack(fill="x", padx=12, pady=8)

        # Toggle + label
        tog_row = tk.Frame(body, bg=C["stone_darkest"])
        tog_row.pack(fill="x")

        self._toggle = Toggle(tog_row, initial=False,
                              on_change=self._on_toggle,
                              bg=C["stone_darkest"])
        self._toggle.pack(side="left")
        tk.Label(tog_row, text="Record last 30 seconds of gameplay",
                 font=F_FELL, fg=C["text_sec"],
                 bg=C["stone_darkest"]).pack(side="left", padx=10)

        # Save clip button
        self._clip_btn = tk.Button(tog_row, text="⬤  SAVE CLIP",
                                   font=F_CINZEL_T,
                                   fg=C["text_dim"], bg=C["stone_border"],
                                   relief="flat", bd=0, padx=10, pady=4,
                                   activebackground=C["stone_dark"],
                                   activeforeground=C["gold_bright"],
                                   cursor="hand2",
                                   state="disabled",
                                   command=self._save_clip)
        self._clip_btn.pack(side="right")

        # Info line
        tk.Label(body,
                 text="Clips saved to  runescript/recordings/",
                 font=F_MONO_S, fg=C["text_dim"],
                 bg=C["stone_darkest"]).pack(anchor="w", pady=(5, 0))

    def _on_toggle(self, state: bool):
        self._enabled = state
        if state:
            self._status.set("BUFFERING")
            self._dot._color = C["neon_green"]
            self._dot._pulse = True
            self._dot._draw(1.0)
            self._dot._animate()
            self._clip_btn.config(state="normal",
                                  fg=C["gold_bright"],
                                  bg=C["stone_dark"])
        else:
            self._status.set("INACTIVE")
            self._dot._color = C["stone_hi"]
            self._dot._pulse = False
            self._dot._draw(1.0)
            self._clip_btn.config(state="disabled",
                                  fg=C["text_dim"],
                                  bg=C["stone_border"])

    def _save_clip(self):
        """Placeholder — wires to actual buffer encoder when scripts exist."""
        self._clip_count += 1
        self._clips.set(f"{self._clip_count} clip{'s' if self._clip_count != 1 else ''} saved")

    @property
    def is_enabled(self) -> bool:
        return self._enabled


# ═══════════════════════════════════════════════════════════════════════════
#  SIDEBAR
# ═══════════════════════════════════════════════════════════════════════════

class Sidebar(tk.Frame):
    def __init__(self, parent, on_select: Callable, **kw):
        super().__init__(parent, bg=C["stone_darkest"], width=220,
                         highlightthickness=0, **kw)
        self.pack_propagate(False)
        self._on_select = on_select
        self._selected  = None
        self._rows: Dict[str, dict] = {}
        self._build()

    def _build(self):
        canvas = tk.Canvas(self, bg=C["stone_dark"], highlightthickness=0)
        canvas.pack(fill="both", expand=True)

        inner = tk.Frame(canvas, bg=C["stone_dark"])
        win = canvas.create_window((0, 0), window=inner, anchor="nw")
        inner.bind("<Configure>", lambda e: canvas.configure(
            scrollregion=canvas.bbox("all")))
        canvas.bind("<Configure>", lambda e: canvas.itemconfig(
            win, width=e.width))

        first_name = None
        for section_idx, (section_name, items) in enumerate(SIDEBAR_SECTIONS):
            lbl_frame = tk.Frame(inner, bg=C["stone_dark"])
            lbl_frame.pack(fill="x")
            tk.Label(lbl_frame, text=section_name.upper(),
                     font=(_CINZEL, 7, "bold"), fg=C["text_dim"],
                     bg=C["stone_dark"],
                     pady=4, padx=0,
                     anchor="center").pack(fill="x")

            for (name, icon, icon_col, meta, available, running) in items:
                if first_name is None:
                    first_name = name
                self._make_row(inner, name, icon, icon_col,
                               meta, available, running)

        # Bottom filler — sized so the last script-item's meta text sits flush
        # with the bottom edge of the log console in the main column.
        self._filler = tk.Frame(inner, bg=C["stone_dark"])
        self._filler.pack(fill="x")
        self._filler.pack_propagate(False)

        # Bind scroll AFTER all children exist so _bind_tree covers everything
        _invisible_scroll(canvas)

        self._app_ref = None

        def _sync(c=canvas, w=win, i=inner, f=self._filler):
            c.itemconfig(w, width=c.winfo_width())
            app = self._app_ref
            if app is None:
                c.after(200, _sync)
                return

            log = app._log_console
            if log is None or not log.winfo_ismapped():
                c.after(200, _sync)
                return

            # Bottom of the log console in screen coordinates
            log_bottom = log.winfo_rooty() + log.winfo_height()

            # Find the last visible script-item meta label
            last_meta = None
            for row_data in self._rows.values():
                last_meta = row_data["meta_lbl"]   # keep overwriting → last wins

            if last_meta is None or not last_meta.winfo_ismapped():
                c.after(200, _sync)
                return

            # Bottom of that meta label in screen coordinates (no filler yet)
            # Temporarily zero the filler so measurement is clean
            f.config(height=1)
            c.update_idletasks()

            meta_bottom = last_meta.winfo_rooty() + last_meta.winfo_height()
            gap = log_bottom - meta_bottom

            if gap > 2:
                f.config(height=gap - 2)
            else:
                f.config(height=1)

            # Re-run every 300 ms so it tracks window resizes
            c.after(300, _sync)

        canvas.after(400, _sync)

        if first_name:
            inner.after(50, lambda: self.select(first_name))

    def _make_row(self, parent, name, icon, icon_col, meta, available, running):
        row = tk.Frame(parent, bg=C["stone_dark"], cursor="hand2")
        row.pack(fill="x")

        accent = tk.Frame(row, bg=C["stone_dark"], width=2)
        accent.pack(side="left", fill="y")

        # Determine dot colour before packing — dot packs RIGHT first so
        # content's fill="x" expand=True takes exactly the remaining space
        if running:
            dot_col  = C["status_run"];  do_pulse = True
        elif available:
            dot_col  = C["status_idle"]; do_pulse = False
        else:
            dot_col  = C["stone_hi"];    do_pulse = False

        dot_c = GlowDot(row, color=dot_col, pulse=do_pulse, bg=C["stone_dark"])
        dot_c.pack(side="right", padx=(0, 8))

        content = tk.Frame(row, bg=C["stone_dark"])
        content.pack(side="left", fill="x", expand=True, pady=3)

        icon_lbl = tk.Label(content, text=icon,
                             font=("Segoe UI Emoji", 12),
                             fg=icon_col, bg=C["stone_dark"], width=2)
        icon_lbl.pack(side="left", padx=(10, 0))

        info = tk.Frame(content, bg=C["stone_dark"])
        info.pack(side="left", fill="x", expand=True, padx=(5, 0))

        name_lbl = tk.Label(info, text=name,
                             font=(_FELL, 7), fg=C["text"],
                             bg=C["stone_dark"], anchor="w")
        name_lbl.pack(fill="x")
        meta_lbl = tk.Label(info, text=meta,
                             font=(_MONO_ALT, 7), fg=C["text_dim"],
                             bg=C["stone_dark"], anchor="w")
        meta_lbl.pack(fill="x")

        self._rows[name] = {
            "frame": row, "accent": accent,
            "content": content, "info": info,
            "name_lbl": name_lbl, "meta_lbl": meta_lbl,
            "icon_lbl": icon_lbl, "dot": dot_c,
        }

        def _enter(e, n=name):
            if self._selected != n:
                self._set_row_bg(n, C["stone_light"], C["gold_deep"], C["gold_shine"])
        def _leave(e, n=name):
            if self._selected != n:
                self._set_row_bg(n, C["stone_dark"], C["stone_dark"], C["text"])
        def _click(e, n=name):
            self.select(n)

        for widget in [row, content, info, name_lbl, meta_lbl, icon_lbl]:
            widget.bind("<Enter>", _enter)
            widget.bind("<Leave>", _leave)
            widget.bind("<ButtonPress-1>", _click)

    def _set_row_bg(self, name, bg, accent_col, name_col):
        r = self._rows.get(name)
        if not r:
            return
        r["accent"].config(bg=accent_col)
        r["frame"].config(bg=bg)
        r["content"].config(bg=bg)
        r["info"].config(bg=bg)
        r["name_lbl"].config(bg=bg, fg=name_col)
        r["meta_lbl"].config(bg=bg)
        r["icon_lbl"].config(bg=bg)
        r["dot"].update_bg(bg)

    def select(self, name: str):
        if self._selected:
            self._set_row_bg(self._selected, C["stone_dark"],
                             C["stone_dark"], C["text"])
        self._selected = name
        self._set_row_bg(name, C["stone_light"],
                         C["gold_bright"], C["gold_shine"])
        self._on_select(name)


# ═══════════════════════════════════════════════════════════════════════════
#  COLOUR PICKER
# ═══════════════════════════════════════════════════════════════════════════

class ColourPicker(tk.Frame):
    def __init__(self, parent, initial="#00FFFF",
                 on_change: Callable = None, **kw):
        kw.setdefault("bg", C["stone_mid"])
        super().__init__(parent, **kw)
        self._color     = initial
        self._on_change = on_change
        self._build()

    def _build(self):
        bg = self.cget("bg")
        self._swatch = tk.Canvas(self, width=16, height=16,
                                  highlightthickness=1,
                                  highlightbackground=C["stone_border"],
                                  bg=self._color)
        self._swatch.pack(side="left")
        self._hex_var = tk.StringVar(value=self._color)
        tk.Label(self, textvariable=self._hex_var,
                 font=F_MONO_S, fg=C["text_sec"],
                 bg=bg, width=8).pack(side="left", padx=(5, 3))

        btn = tk.Canvas(self, width=24, height=24,
                        bg=C["stone_dark"],
                        highlightthickness=1,
                        highlightbackground=C["stone_border"],
                        cursor="hand2")
        btn.pack(side="left")
        cx, cy, r = 12, 12, 8
        hues = [(0,"#ff0000"),(30,"#ff8000"),(60,"#ffff00"),
                (90,"#80ff00"),(120,"#00ff00"),(150,"#00ff80"),
                (180,"#00ffff"),(210,"#0080ff"),(240,"#0000ff"),
                (270,"#8000ff"),(300,"#ff00ff"),(330,"#ff0080")]
        for h_deg, col in hues:
            btn.create_arc(cx-r, cy-r, cx+r, cy+r,
                           start=h_deg, extent=30,
                           fill=col, outline="")
        btn.create_oval(cx-3, cy-3, cx+3, cy+3,
                        fill=C["stone_dark"], outline="")
        btn.bind("<ButtonPress-1>", self._pick)
        btn.bind("<Enter>",  lambda e: btn.config(highlightbackground=C["gold_deep"]))
        btn.bind("<Leave>",  lambda e: btn.config(highlightbackground=C["stone_border"]))

    def _pick(self, _=None):
        result = colorchooser.askcolor(color=self._color,
                                       title="Pick RuneLite Highlight Colour")
        if result and result[1]:
            self._color = result[1].upper()
            self._swatch.config(bg=self._color)
            self._hex_var.set(self._color)
            if self._on_change:
                self._on_change(self._color)

    @property
    def color(self): return self._color


# ═══════════════════════════════════════════════════════════════════════════
#  CONTROL CARD
# ═══════════════════════════════════════════════════════════════════════════

class ControlCard(tk.Frame):
    def __init__(self, parent, bridge, skill_name="Woodcutting", **kw):
        super().__init__(parent,
                         bg=C["stone_mid"],
                         highlightthickness=1,
                         highlightbackground=C["stone_border"],
                         **kw)
        self._bridge          = bridge
        self._skill           = skill_name
        self._status_var      = tk.StringVar(value="IDLE")
        self._colour_picker   = None
        self._build()

    def _build(self):
        bg = C["stone_mid"]

        top = tk.Frame(self, bg=bg)
        top.pack(fill="x", padx=16, pady=(14, 8))

        left = tk.Frame(top, bg=bg)
        left.pack(side="left", fill="x", expand=True)
        self._name_lbl = tk.Label(left, text=self._skill.upper(),
                                   font=F_TITLE,
                                   fg=C["gold_shine"], bg=bg)
        self._name_lbl.pack(anchor="w")
        self._type_lbl = tk.Label(left,
                                   text="GATHERING  ·  OAK TREE  ·  POWER CHOP",
                                   font=F_MONO_S, fg=C["rune_cyan"], bg=bg)
        self._type_lbl.pack(anchor="w", pady=(1, 0))

        self._badge = tk.Frame(top, bg=bg,
                                highlightthickness=1,
                                highlightbackground=C["status_idle"])
        self._badge.pack(side="right", padx=(10, 0))
        badge_inner = tk.Frame(self._badge, bg=bg)
        badge_inner.pack(padx=8, pady=4)
        self._dot = PulseDot(badge_inner, size=5, color=C["status_idle"], bg=bg)
        self._dot.pack(side="left", padx=(0, 4))
        self._badge_lbl = tk.Label(badge_inner, textvariable=self._status_var,
                                    font=F_CINZEL_S, fg=C["status_idle"], bg=bg)
        self._badge_lbl.pack(side="left")

        _sep(self, color=C["stone_border"], pady=(0, 6))

        # Config row
        cfg_row = tk.Frame(self, bg=bg)
        cfg_row.pack(fill="x", padx=16, pady=(0, 8))

        self._tree_var = tk.StringVar(value="Oak")
        self._add_config_field(cfg_row, "Tree Type",
                               ["Oak","Willow","Maple","Yew","Magic"],
                               self._tree_var)
        self._mode_var = tk.StringVar(value="Power Chop")
        self._add_config_field(cfg_row, "Mode",
                               ["Power Chop","Bank Logs","Tick Manipulation"],
                               self._mode_var)

        col_lbl_frame = tk.Frame(cfg_row, bg=bg)
        col_lbl_frame.pack(side="left", padx=(10, 0))
        tk.Label(col_lbl_frame, text="Highlight Colour",
                 font=F_FELL_S, fg=C["text_sec"], bg=bg).pack(anchor="w")
        self._colour_picker = ColourPicker(col_lbl_frame, initial="#00FFFF",
            on_change=self._on_colour_change, bg=bg)
        self._colour_picker.pack(anchor="w", pady=(3, 0))

        btn_row = tk.Frame(self, bg=bg)
        btn_row.pack(fill="x", padx=16, pady=(2, 12))
        self._start_btn = self._btn(btn_row, "▶  Start",   C["status_run"],  self._on_start)
        self._pause_btn = self._btn(btn_row, "⏸  Pause",   C["status_pause"], self._on_pause)
        self._stop_btn  = self._btn(btn_row, "■  Stop",    C["status_stop"],  self._on_stop)
        self._cfg_btn   = self._btn(btn_row, "⚙  Configure", C["gold_mid"],  None, right=True)

        xp_frame = tk.Frame(self, bg=bg)
        xp_frame.pack(fill="x", padx=16, pady=(0, 12))
        self._xp_bar = XPBar(xp_frame, bg=bg)
        self._xp_bar.pack(fill="x")

    def _add_config_field(self, parent, label, choices, var):
        f = tk.Frame(parent, bg=C["stone_mid"])
        f.pack(side="left", padx=(0, 10))
        tk.Label(f, text=label, font=F_FELL_S, fg=C["text_sec"],
                 bg=C["stone_mid"]).pack(anchor="w")

        # Use a display var that appends ▾ so we can hide the default indicator
        display_var = tk.StringVar(value=var.get() + "  ▾")
        def _on_real(*_):
            display_var.set(var.get() + "  ▾")
        var.trace_add("write", _on_real)

        om = tk.OptionMenu(f, var, *choices)
        om.config(bg=C["stone_darkest"], fg=C["text"],
                  font=F_MONO_S, relief="flat", bd=0,
                  activebackground=C["stone_light"],
                  activeforeground=C["gold_bright"],
                  highlightthickness=1,
                  highlightbackground=C["stone_border"],
                  indicatoron=False,
                  textvariable=display_var,
                  cursor="hand2")
        om["menu"].config(bg=C["stone_dark"], fg=C["text"],
                          font=F_MONO_S,
                          activebackground=C["stone_light"],
                          activeforeground=C["gold_bright"])
        om.pack(fill="x", pady=(3, 0))
        return om

    def _btn(self, parent, text, color, cmd, right=False):
        b = tk.Button(parent, text=text,
                      font=F_CINZEL_S, fg=color,
                      bg=C["stone_mid"],
                      relief="flat", bd=0,
                      highlightthickness=1,
                      highlightbackground=color,
                      activebackground=C["stone_light"],
                      activeforeground=C["gold_bright"],
                      cursor="hand2",
                      padx=12, pady=5,
                      command=cmd)
        if right:
            b.pack(side="right")
        else:
            b.pack(side="left", padx=(0, 6))
        return b

    def _on_colour_change(self, hex_c):
        if self._bridge:
            self._bridge.set_highlight_colour(self._skill.lower(), hex_c)

    def _on_start(self):
        cfg = {
            "tree_type": self._tree_var.get().lower(),
            "mode": self._mode_var.get().lower().replace(" ", "_"),
            "highlight_colour": self._colour_picker.color if self._colour_picker else "#00FFFF",
        }
        if self._bridge:
            r = self._bridge.start_script(self._skill.lower(), cfg)
            if r.get("ok"):
                self.set_status("running")
            elif self._bridge:
                self._bridge.push_log("error", f"Failed: {r.get('error','?')}")

    def _on_pause(self):
        if self._bridge: self._bridge.pause_script()
        self.set_status("paused")

    def _on_stop(self):
        if self._bridge: self._bridge.stop_script()
        self.set_status("idle")

    def set_skill(self, name: str):
        self._skill = name
        self._name_lbl.config(text=name.upper())

    def set_status(self, status: str):
        color_map = {
            "running": C["status_run"],
            "paused":  C["status_pause"],
            "stopped": C["status_stop"],
            "idle":    C["status_idle"],
        }
        c = color_map.get(status, C["status_idle"])
        self._status_var.set(status.upper())
        self._badge.config(highlightbackground=c)
        self._badge_lbl.config(fg=c)
        self._dot.set_color(c)

    @property
    def colour(self):
        return self._colour_picker.color if self._colour_picker else "#00FFFF"


# ═══════════════════════════════════════════════════════════════════════════
#  RIGHT PANEL
# ═══════════════════════════════════════════════════════════════════════════

class RightPanel(tk.Frame):
    def __init__(self, parent, runelite_tracker=None, **kw):
        super().__init__(parent, bg=C["stone_dark"], width=260,
                         highlightthickness=0, **kw)
        self.pack_propagate(False)
        self._skill_level_vars: Dict[str, tk.StringVar] = {}
        self._skill_xp_vars:    Dict[str, tk.StringVar] = {}
        self._antiban_toggles:  Dict[str, Toggle]       = {}
        self._hiscores          = None   # kept for compat, always None now
        self._runelite          = runelite_tracker
        self._status_var        = tk.StringVar(value="—")
        self._build()

    def _build(self):
        canvas = tk.Canvas(self, bg=C["stone_dark"], highlightthickness=0)
        canvas.pack(fill="both", expand=True)

        inner = tk.Frame(canvas, bg=C["stone_dark"])
        canvas.create_window((0, 0), window=inner, anchor="nw", width=256)
        inner.bind("<Configure>", lambda e: canvas.configure(
            scrollregion=canvas.bbox("all")))

        self._build_location(inner)
        self._build_skills(inner)
        self._build_antiban(inner)

        # Bind scroll AFTER all children exist
        _invisible_scroll(canvas)

    def _build_location(self, parent):
        _section_header(parent, "Location", bg=C["stone_dark"])
        MinimapWidget(parent, bg=C["stone_dark"]).pack(
            fill="x", padx=8, pady=(0, 4))

    def _build_skills(self, parent):
        _section_header(parent, "Skills", bg=C["stone_dark"])

        # ── Connection status row ─────────────────────────────────────
        urow = tk.Frame(parent, bg=C["stone_dark"])
        urow.pack(fill="x", padx=8, pady=(0, 4))

        tk.Label(urow, text="RuneLite:", font=F_FELL_S,
                 fg=C["text_dim"], bg=C["stone_dark"]).pack(side="left")

        refresh_btn = tk.Label(urow, text="↻", font=("", 13),
                               fg=C["rune_cyan"], bg=C["stone_dark"],
                               cursor="hand2")
        refresh_btn.pack(side="left", padx=(4, 0))
        refresh_btn.bind("<Button-1>", lambda e: self._on_refresh())

        self._poll_status = tk.Label(urow, textvariable=self._status_var,
                                     font=(_MONO_ALT, 7),
                                     fg=C["text_dim"], bg=C["stone_dark"])
        self._poll_status.pack(side="right")

        # ── Get initial snapshot from RuneLite ────────────────────────
        initial = []
        if self._runelite is not None:
            # Wire callbacks
            self._runelite.on_update  = self._on_hiscores_update
            self._runelite.on_levelup = self._on_levelup
            # Blocking fetch so grid is populated immediately
            self._runelite._fetch_stats()
            initial = self._runelite.snapshot()
            if any(s["level"] > 1 for s in initial):
                self._status_var.set("connected")
            else:
                self._status_var.set("waiting…")

        # ── Skill grid ────────────────────────────────────────────────
        self._skill_rows: Dict[str, dict] = {}

        grid = tk.Frame(parent, bg=C["stone_dark"])
        grid.pack(fill="x", padx=6, pady=(0, 4))
        grid.columnconfigure(0, weight=1)
        grid.columnconfigure(1, weight=1)

        from core.runelite_tracker import SKILL_NAMES as _ORDER

        for i, skill in enumerate(_ORDER):
            row_i, col_i = divmod(i, 2)
            icon, col = SKILL_META.get(skill, ("·", C["text_dim"]))
            snap     = next((s for s in initial if s["skill"] == skill), {})
            level    = snap.get("level", 1)
            xphr     = snap.get("xp_per_hour", 0)
            active_s = snap.get("active", False)

            bg     = C["stone_darkest"]
            border = col if active_s else C["stone_border"]

            cell = tk.Frame(grid, bg=bg, highlightthickness=1,
                            highlightbackground=border)
            cell.grid(row=row_i, column=col_i, sticky="nsew", padx=2, pady=2)

            inner = tk.Frame(cell, bg=bg)
            inner.pack(fill="x", padx=6, pady=4)

            # Always show skill colour — dim it 50% when inactive
            def _dim(hex_col, factor=0.45):
                h = hex_col.lstrip("#")
                r,g,b = int(h[0:2],16), int(h[2:4],16), int(h[4:6],16)
                return f"#{int(r*factor):02x}{int(g*factor):02x}{int(b*factor):02x}"

            icon_fg = col if active_s else _dim(col)
            icon_lbl = tk.Label(inner, text=icon, font=("", 11),
                                fg=icon_fg, bg=bg)
            icon_lbl.pack(side="left", padx=(0, 4))

            data = tk.Frame(inner, bg=bg)
            data.pack(side="left", fill="x", expand=True)

            tk.Label(data, text=skill, font=F_FELL_S,
                     fg=C["text_sec"] if active_s else C["text_dim"],
                     bg=bg, anchor="w").pack(fill="x")

            level_var = tk.StringVar(value=str(level) if level > 1 else "—")
            xphr_var  = tk.StringVar(value=f"{xphr:,}/hr" if xphr else "—")

            level_lbl = tk.Label(data, textvariable=level_var,
                                 font=(_MONO_ALT, 11, "bold"),
                                 fg=C["gold_bright"] if active_s else C["text_dim"],
                                 bg=bg, anchor="w")
            level_lbl.pack(fill="x")
            tk.Label(data, textvariable=xphr_var,
                     font=(_MONO_ALT, 7), fg=C["text_dim"],
                     bg=bg, anchor="w").pack(fill="x")

            self._skill_rows[skill] = {
                "cell": cell, "icon_lbl": icon_lbl,
                "level_var": level_var, "xphr_var": xphr_var,
                "level_lbl": level_lbl, "active": active_s, "col": col,
            }

    def _build_antiban(self, parent):
        tk.Frame(parent, bg=C["stone_dark"], height=4).pack()
        _section_header(parent, "Antiban", bg=C["stone_dark"])

        panel = _panel(parent)
        panel.pack(fill="x", padx=8, pady=(0, 8))

        for i, (label, default) in enumerate(ANTIBAN_SETTINGS):
            row = tk.Frame(panel, bg=C["stone_mid"])
            row.pack(fill="x", padx=10, pady=0)

            tk.Label(row, text=label, font=F_FELL,
                     fg=C["text_sec"], bg=C["stone_mid"],
                     anchor="w").pack(side="left", pady=8)

            tog = Toggle(row, initial=default, bg=C["stone_mid"])
            tog.pack(side="right")
            self._antiban_toggles[label] = tog

            if i < len(ANTIBAN_SETTINGS) - 1:
                tk.Frame(panel, bg=C["stone_border"], height=1).pack(
                    fill="x", padx=10)

    def _on_refresh(self):
        """Force an immediate RuneLite stats fetch."""
        if self._runelite:
            self._status_var.set("fetching…")
            def _fetch():
                self._runelite._fetch_stats()
            threading.Thread(target=_fetch, daemon=True).start()

    def _on_hiscores_update(self, snapshot: list):
        """Called from RuneLite tracker thread — schedule GUI update safely."""
        def _apply():
            self._apply_snapshot(snapshot)
            import time as _t
            self._status_var.set(f"updated {_t.strftime('%H:%M:%S')}")
        try:
            self.after(0, _apply)
        except Exception as e:
            print(f"[GUI] after() failed: {e}")

    def _on_levelup(self, skill: str, level: int):
        """Called from hiscores thread on level-up."""
        def _apply():
            if skill in self._skill_rows:
                self._flash_levelup(self._skill_rows[skill])
        try:
            self.after(0, _apply)
        except Exception:
            pass

    def _apply_snapshot(self, snapshot: list):
        for entry in snapshot:
            skill = entry["skill"]
            if skill not in self._skill_rows:
                continue
            row    = self._skill_rows[skill]
            level  = entry["level"]
            xphr   = entry["xp_per_hour"]
            active = entry["active"]
            col    = row["col"]

            try:
                old_level = int(row["level_var"].get())
            except ValueError:
                old_level = 0
            levelled = level > old_level > 0

            # Always update the display values regardless of active state
            row["level_var"].set(str(level) if level > 1 else "—")
            row["xphr_var"].set(f"{xphr:,}/hr" if xphr else "—")

            def _dim(hex_col, factor=0.45):
                h = hex_col.lstrip("#")
                r,g,b = int(h[0:2],16), int(h[2:4],16), int(h[4:6],16)
                return f"#{int(r*factor):02x}{int(g*factor):02x}{int(b*factor):02x}"

            if active:
                row["cell"].config(highlightbackground=col)
                row["icon_lbl"].config(fg=col)
                row["level_lbl"].config(fg=C["gold_bright"])
                if levelled:
                    self._flash_levelup(row)
            else:
                row["cell"].config(highlightbackground=C["stone_border"])
                row["icon_lbl"].config(fg=_dim(col))
                row["level_lbl"].config(fg=C["text_dim"])
            row["active"] = active

    # Keep for _on_stats compatibility (script-reported data)
    def update_skill_snapshot(self, snapshot: list):
        self._apply_snapshot(snapshot)

    def _flash_levelup(self, row: dict, flashes: int = 8):
        colours = [C["gold_shine"], "#ffffff"] * (flashes // 2)
        def _step(idx=0):
            if idx < len(colours):
                row["level_lbl"].config(fg=colours[idx])
                row["level_lbl"].after(100, lambda: _step(idx + 1))
            else:
                row["level_lbl"].config(fg=C["gold_shine"])
        _step()

    def get_antiban(self) -> Dict[str, bool]:
        return {k: v.value for k, v in self._antiban_toggles.items()}


# ═══════════════════════════════════════════════════════════════════════════
#  MOCK BRIDGE
# ═══════════════════════════════════════════════════════════════════════════

class MockBridge:
    def __init__(self, log_cb, stats_cb, status_cb):
        self._log     = log_cb
        self._stats   = stats_cb
        self._status  = status_cb
        self._running = False
        self._actions = 0
        self._start   = 0.0

    def set_highlight_colour(self, script, colour):
        self._log("info", f"Highlight colour → {colour}")

    def start_script(self, name, config) -> dict:
        if self._running:
            return {"ok": False, "error": "Already running"}
        self._running = True
        self._actions = 0
        self._start   = time.time()
        self._log("info", f"Starting {name} | {config.get('tree_type','?')} | {config.get('mode','?')}")
        self._log("info", f"Highlight colour: {config.get('highlight_colour','?')}")
        self._status("running")
        threading.Thread(target=self._sim, daemon=True).start()
        return {"ok": True}

    def stop_script(self):
        self._running = False
        self._log("warn", "Script stopped by user.")
        self._status("idle")

    def pause_script(self):
        self._log("info", "Script paused.")
        self._status("paused")

    def push_log(self, level, msg):
        self._log(level, msg)

    def _sim(self):
        msgs = [
            ("info",  "Scanning viewport for highlight contour..."),
            ("info",  "Highlight contour found at (743, 412) conf=0.94"),
            ("info",  "Moving mouse to (743, 412)"),
            ("ok",    "Hover confirmed: Chop down Oak tree — clicking"),
            ("ok",    "XP drop detected — trees chopped: {n}"),
            ("info",  "State: FIND_TREE → HOVER_CONFIRM"),
            ("info",  "State: HOVER_CONFIRM → CHOPPING"),
            ("ok",    "Tree depleted — stump detected near (743, 412)"),
            ("warn",  "Antiban: random camera adjustment triggered"),
            ("warn",  "Antiban: reaction delay 287ms"),
            ("info",  "State: CHOPPING → FIND_TREE"),
        ]
        i = 0
        n = 1247
        while self._running:
            time.sleep(random.uniform(1.4, 3.0))
            if not self._running:
                break
            self._actions += 1
            n += 1
            lv, msg = msgs[i % len(msgs)]
            self._log(lv, msg.replace("{n}", str(n)))
            i += 1
            elapsed = time.time() - self._start
            xp_hr   = int(n * 37 * 3600 / max(elapsed, 1))
            self._stats({
                "Runtime":        self._fmt(elapsed),
                "Logs / hr":      str(int(n * 3600 / max(elapsed, 1))),
                "XP / hr":        f"{xp_hr:,}",
                "Trees Chopped":  str(n),
                "XP Drops":       str(n),
                "Detections":     "99%",
                "Hovers":         f"{random.uniform(1.0,2.0):.1f}",
                "GP / hr":        "18k",
                "session_elapsed": int(elapsed),
            })

    @staticmethod
    def _fmt(s):
        s = int(s)
        return f"{s//3600}:{(s%3600)//60:02d}:{s%60:02d}"


# ═══════════════════════════════════════════════════════════════════════════
#  RUNE GLOW CANVAS  (logo icon that pulses like HTML runeGlow)
# ═══════════════════════════════════════════════════════════════════════════

# ═══════════════════════════════════════════════════════════════════════════
#  RS ICON  — R with sword leg + plain S
# ═══════════════════════════════════════════════════════════════════════════


# ═══════════════════════════════════════════════════════════════════════════
#  SETTINGS PAGE
# ═══════════════════════════════════════════════════════════════════════════

# ═══════════════════════════════════════════════════════════════════════════
#  SETTINGS PAGE  (full rewrite)
# ═══════════════════════════════════════════════════════════════════════════

class HSlider(tk.Canvas):
    """Custom horizontal slider that respects our colour palette."""

    H = 16  # total canvas height

    def __init__(self, parent, variable, from_=0.0, to=1.0,
                 resolution=0.1, length=200, command=None, **kw):
        kw.setdefault("bg",     C["stone_dark"])
        kw.setdefault("height", self.H)
        kw.setdefault("width",  length)
        kw["highlightthickness"] = 0
        super().__init__(parent, **kw)
        self._var      = variable
        self._from     = from_
        self._to       = to
        self._res      = resolution
        self._cmd      = command
        self._dragging = False

        self._track  = self.create_rectangle(0, 0, 1, 1,
                           fill=C["stone_border"], outline="", width=0)
        self._fill   = self.create_rectangle(0, 0, 1, 1,
                           fill=C["gold_deep"], outline="", width=0)
        self._thumb  = self.create_rectangle(0, 0, 1, 1,
                           fill=C["gold_mid"], outline=C["gold_bright"], width=1)

        self.bind("<Configure>",       self._redraw)
        self.bind("<ButtonPress-1>",   self._on_press)
        self.bind("<B1-Motion>",       self._on_drag)
        self.bind("<ButtonRelease-1>", self._on_release)
        self.bind("<Enter>",  lambda e: self.itemconfig(self._thumb, fill=C["gold_bright"]))
        self.bind("<Leave>",  lambda e: self.itemconfig(self._thumb,
                              fill=C["gold_bright"] if self._dragging else C["gold_mid"]))
        self._var.trace_add("write", lambda *_: self._redraw())

    def _frac(self):
        span = self._to - self._from
        if span == 0: return 0.0
        return max(0.0, min(1.0, (self._var.get() - self._from) / span))

    def _redraw(self, *_):
        w, h = self.winfo_width(), self.winfo_height()
        if w < 2: return
        TH, TW = 12, 8   # thumb height, half-width
        ty = h // 2
        track_y1, track_y2 = ty - 3, ty + 3
        f   = self._frac()
        pad = TW + 2
        x   = pad + f * (w - 2 * pad)
        self.coords(self._track, pad, track_y1, w - pad, track_y2)
        self.coords(self._fill,  pad, track_y1, x,       track_y2)
        self.coords(self._thumb, x - TW, ty - TH//2, x + TW, ty + TH//2)

    def _x_to_val(self, x):
        w   = self.winfo_width()
        TW  = 10
        pad = TW + 2
        frac = max(0.0, min(1.0, (x - pad) / max(1, w - 2 * pad)))
        raw  = self._from + frac * (self._to - self._from)
        if self._res:
            raw = round(raw / self._res) * self._res
        return max(self._from, min(self._to, raw))

    def _on_press(self, e):
        self._dragging = True
        self.itemconfig(self._thumb, fill=C["gold_bright"])
        self._set(self._x_to_val(e.x))

    def _on_drag(self, e):
        if self._dragging:
            self._set(self._x_to_val(e.x))

    def _on_release(self, e):
        self._dragging = False
        self.itemconfig(self._thumb, fill=C["gold_mid"])

    def _set(self, val):
        self._var.set(round(val, 6))
        if self._cmd:
            self._cmd(str(val))


# ═══════════════════════════════════════════════════════════════════════════
#  DETECTION PAGE
# ═══════════════════════════════════════════════════════════════════════════
# ═══════════════════════════════════════════════════════════════════════════
#  DETECTION PAGE
# ═══════════════════════════════════════════════════════════════════════════
#
#  Two-panel layout:
#    Left  — Highlight Detector: colour picker, presets, live test
#    Right — Live OSRS map with player dot from LocationDetector coords
#
#  Map tile maths (OSRS Wiki Leaflet tiles):
#    URL:  https://maps.runescape.wiki/osrs/tiles/base/{plane}_{zoom}/{tx}_{ty}.png
#    Each tile = 256px, covers 64 game squares at zoom=2 (4px/sq)
#    px_per_sq  = 2 ** zoom   (zoom 2 → 4px/sq, zoom 3 → 8px/sq)
#    tile_sq    = 256 / px_per_sq  (zoom 2 → 64 sq/tile)
#    tx         = world_x // tile_sq
#    ty         = world_y // tile_sq
#    pixel within tile: (world_x % tile_sq) * px_per_sq
#
# ═══════════════════════════════════════════════════════════════════════════

import io
import math
import os
import threading
import time
import urllib.request
from typing import Optional, Tuple

# Colour presets for common RuneLite highlight colours
_COLOUR_PRESETS = [
    ("#00FFFF", "Cyan"),
    ("#00FF00", "Green"),
    ("#FF6600", "Orange"),
    ("#FF0000", "Red"),
    ("#FF00FF", "Magenta"),
    ("#FFFF00", "Yellow"),
    ("#FFFFFF", "White"),
]

# Map config — flat image from wiki
# ── Tile map engine (replaces flat world_map.png) ────────────────────────
# Tiles served from maps.runescape.wiki — pixel-perfect, no calibration needed.
# Internal zoom Z=3: 8px/sq, 32sq/tile. GUI zoom multiplier applied on top.
from tile_map import (
    get_tile_cache, stitch_viewport, canvas_to_world,
    _ZOOM_LEVELS, _ZOOM_DEF_IDX, _PX_PER_SQ, _SQ_PER_TILE,
)

# Default centre: Lumbridge
_DEFAULT_X   = 3222
_DEFAULT_Y   = 3218




def lookup_location_improved(x: int, y: int, z: int = 0) -> str:
    """Return a human-readable area name for world coords, or empty string."""
    try:
        from core.detection.location_detector import lookup_location
        return lookup_location(x, y, z)
    except Exception:
        return ""


class DetectionPage(tk.Frame):
    """
    Left panel  — Highlight Detector config + capture test
    Right panel — Live OSRS map tile viewer with player dot
    """

    def __init__(self, parent, bridge=None, **kw):
        kw.setdefault("bg", C["stone_darkest"])
        super().__init__(parent, **kw)
        self._bridge = bridge

        # Map state
        self._zoom_idx   = _ZOOM_DEF_IDX   # index into _ZOOM_LEVELS
        self._center_x   = _DEFAULT_X      # world tile X
        self._center_y   = _DEFAULT_Y      # world tile Y
        self._player_x   = None
        self._player_y   = None
        self._player_z   = None
        self._drag_start = None
        self._drag_cx    = None
        self._drag_cy    = None

        # Highlight state
        self._hl_colour  = "#00FFFF"
        self._test_img   = None
        self._test_lock  = threading.Lock()
        self._pulse_scheduled = False

        # Tile map — wiki tile server, pixel-perfect, no calibration
        self._map_photo   = None
        self._render_lock = threading.Lock()
        self._render_pending = False
        self._redraw_queued  = False
        # Pan-offset state — for instant drag without re-render
        self._buf_center_x  = None   # world coords the current buffer was rendered at
        self._buf_center_y  = None
        self._buf_margin    = 0      # no oversized margin — instant moveto during drag
        self._pan_ox        = 0      # current pixel offset of image on canvas
        self._pan_oy        = 0
        self._latest_render = None   # (cx, cy, zm, pz) of most recently requested render
        self._tile_cache  = get_tile_cache()
        self._tile_cache.set_on_ready(self._on_tile_ready)

        self._build()
        self.after(200, self._poll_location)

        # Primary: PositionTracker polls RuneLite Position Broadcast plugin (:8081)
        # Fallback: LocationDetector OCR when plugin unavailable
        self._pos_tracker = None
        try:
            from core.position_tracker import get_tracker as _get_pos
            self._pos_tracker = _get_pos()
            _prev_pos_cb = self._pos_tracker.on_update
            def _on_pos(x, y, plane, _prev=_prev_pos_cb):
                if _prev:
                    try: _prev(x, y, plane)
                    except Exception: pass
                try:
                    if self.winfo_exists():
                        self.after(0, self._update_location)
                except Exception:
                    pass
            self._pos_tracker.on_position = _on_pos
            if not self._pos_tracker._running:
                self._pos_tracker.start()
        except Exception:
            pass

        # Fallback: LocationDetector OCR (only fires when plugin not connected)
        try:
            ld = getattr(bridge, "location_detector", None)
            if ld is not None:
                _prev_cb = ld.on_update
                def _on_loc(coords, name, raw, _prev=_prev_cb):
                    if _prev:
                        try: _prev(coords, name, raw)
                        except Exception: pass
                    if not (self._pos_tracker and self._pos_tracker.plugin_available):
                        try:
                            if self.winfo_exists():
                                self.after(0, self._update_location)
                        except Exception:
                            pass
                ld.on_update = _on_loc
        except Exception:
            pass

    # ── layout ───────────────────────────────────────────────────────────

    def _build(self):
        bg = C["stone_darkest"]

        panes = tk.Frame(self, bg=bg)
        panes.pack(fill="both", expand=True)

        # ── Map fills entire space ────────────────────────────────────
        self._build_map_panel(panes)

    # ── highlight panel ───────────────────────────────────────────────────

    def _build_highlight_panel(self, parent):
        bg = C["stone_darkest"]
        px = 14

        _section_header(parent, "Highlight Detector", bg=bg)

        # Colour picker card
        card = tk.Frame(parent, bg=C["stone_mid"],
                        highlightthickness=1,
                        highlightbackground=C["stone_border"])
        card.pack(fill="x", padx=px, pady=(0, 10))
        inn = tk.Frame(card, bg=C["stone_mid"])
        inn.pack(fill="x", padx=12, pady=10)

        row = tk.Frame(inn, bg=C["stone_mid"])
        row.pack(fill="x", pady=(0, 8))
        _label(row, "Target Colour", font=F_CINZEL_S).pack(side="left")
        self._cp = ColourPicker(row, initial=self._hl_colour,
                                on_change=self._on_colour_change,
                                bg=C["stone_mid"])
        self._cp.pack(side="left", padx=(10, 0))
        self._hex_lbl = tk.Label(row, text=self._hl_colour,
                                 font=F_MONO_S, fg=C["gold_pale"],
                                 bg=C["stone_mid"])
        self._hex_lbl.pack(side="left", padx=(8, 0))

        # Presets
        _label(inn, "Quick Presets", font=F_CINZEL_S).pack(anchor="w",
                                                             pady=(0, 5))
        preset_row = tk.Frame(inn, bg=C["stone_mid"])
        preset_row.pack(fill="x", pady=(0, 4))
        for hex_c, name in _COLOUR_PRESETS:
            self._preset_swatch(preset_row, hex_c, name)

        # Tuning params
        _sep(inn, color=C["stone_border"], pady=(8, 8))
        _label(inn, "Detector Tuning", font=F_CINZEL_S).pack(anchor="w",
                                                               pady=(0, 6))
        params = [
            ("Hue Tolerance",  "hue_tol",  0, 30, 1,  12),
            ("Sat Tolerance",  "sat_tol",  0, 80, 5,  50),
            ("Min Area (px²)", "min_area", 20, 500, 10, 80),
            ("Max Area (px²)", "max_area", 1000, 80000, 1000, 40000),
        ]
        self._tune_vars = {}
        for label, key, lo, hi, res, default in params:
            r = tk.Frame(inn, bg=C["stone_mid"])
            r.pack(fill="x", pady=(0, 6))
            _label(r, label, font=F_CINZEL_T,
                   fg=C["text_sec"]).pack(side="left")
            var = tk.DoubleVar(value=default)
            self._tune_vars[key] = var
            lbl = tk.Label(r, text=str(default), font=F_MONO_S,
                           fg=C["gold_pale"], bg=C["stone_mid"], width=6,
                           anchor="e")
            lbl.pack(side="right")
            def _cmd(v, l=lbl, r_=res):
                l.config(text=str(int(float(v))) if r_ >= 1
                         else f"{float(v):.1f}")
            HSlider(inn, variable=var, from_=lo, to=hi,
                    resolution=res, command=_cmd,
                    bg=C["stone_mid"]).pack(fill="x", pady=(0, 2))

        # Apply button
        tk.Button(inn, text="Apply to Script",
                  font=F_CINZEL_S, fg=C["gold_mid"],
                  bg=C["stone_light"], relief="flat", bd=0,
                  highlightthickness=1,
                  highlightbackground=C["stone_border"],
                  activebackground=C["stone_hi"],
                  activeforeground=C["gold_bright"],
                  cursor="hand2", pady=4,
                  command=self._apply_detector).pack(fill="x", pady=(8, 0))

        # Test capture
        _section_header(parent, "Capture Test", bg=bg)
        test_card = tk.Frame(parent, bg=C["stone_mid"],
                             highlightthickness=1,
                             highlightbackground=C["stone_border"])
        test_card.pack(fill="x", padx=px, pady=(0, 10))
        test_inn = tk.Frame(test_card, bg=C["stone_mid"])
        test_inn.pack(fill="x", padx=12, pady=10)

        btn_row = tk.Frame(test_inn, bg=C["stone_mid"])
        btn_row.pack(fill="x", pady=(0, 8))
        tk.Button(btn_row, text="▶  Test Capture",
                  font=F_CINZEL_S, fg=C["status_run"],
                  bg=C["stone_light"], relief="flat", bd=0,
                  highlightthickness=1,
                  highlightbackground=C["stone_border"],
                  activebackground=C["stone_hi"],
                  activeforeground=C["gold_bright"],
                  cursor="hand2", pady=4,
                  command=self._run_test_capture).pack(side="left",
                                                       fill="x", expand=True)

        self._test_status = tk.Label(test_inn, text="No capture yet.",
                                     font=F_MONO_S, fg=C["text_dim"],
                                     bg=C["stone_mid"], wraplength=240,
                                     justify="left")
        self._test_status.pack(anchor="w", pady=(0, 6))

        # Preview canvas — shows debug_frame output
        self._preview_canvas = tk.Canvas(test_inn, bg=C["stone_dark"],
                                         highlightthickness=1,
                                         highlightbackground=C["stone_border"],
                                         height=160)
        self._preview_canvas.pack(fill="x")
        self._preview_canvas.create_text(
            120, 80, text="Capture preview",
            font=F_CINZEL_T, fill=C["text_dim"], tags="placeholder")

    def _preset_swatch(self, parent, hex_c, name):
        try:
            r = int(hex_c[1:3], 16)
            g = int(hex_c[3:5], 16)
            b = int(hex_c[5:7], 16)
            lum = 0.299*r + 0.587*g + 0.114*b
            text_col = "#000000" if lum > 140 else "#ffffff"
        except Exception:
            text_col = "#ffffff"

        btn = tk.Button(parent, text=name, font=F_CINZEL_T,
                        bg=hex_c, fg=text_col,
                        relief="flat", bd=0, padx=6, pady=3,
                        cursor="hand2",
                        highlightthickness=1,
                        highlightbackground=C["stone_border"],
                        activebackground=hex_c,
                        command=lambda h=hex_c: self._set_colour(h))
        btn.pack(side="left", padx=(0, 4), pady=(0, 4))

    def _on_colour_change(self, hex_c):
        self._hl_colour = hex_c
        self._hex_lbl.config(text=hex_c)

    def _set_colour(self, hex_c):
        self._hl_colour = hex_c
        self._hex_lbl.config(text=hex_c)
        self._cp.set_color(hex_c)

    def _apply_detector(self):
        try:
            bridge = self._bridge
            if bridge and hasattr(bridge, "set_highlight_colour"):
                bridge.set_highlight_colour("woodcutting", self._hl_colour)
            # Also push tuning vars to highlight_detector module constants
            import core.highlight_detector as hd
            hd.HUE_TOLERANCE = int(self._tune_vars["hue_tol"].get())
            hd.SAT_TOLERANCE = int(self._tune_vars["sat_tol"].get())
            hd.MIN_AREA      = int(self._tune_vars["min_area"].get())
            hd.MAX_AREA      = int(self._tune_vars["max_area"].get())
            self._test_status.config(text="Settings applied.",
                                     fg=C["status_run"])
        except Exception as e:
            self._test_status.config(text=f"Apply failed: {e}",
                                     fg=C["status_stop"])

    def _run_test_capture(self):
        self._test_status.config(text="Capturing…", fg=C["text_dim"])
        self._preview_canvas.delete("all")
        self._preview_canvas.create_text(
            self._preview_canvas.winfo_width() // 2 or 120, 80,
            text="Capturing…", font=F_CINZEL_T, fill=C["text_dim"])
        threading.Thread(target=self._do_capture, daemon=True).start()

    def _do_capture(self):
        try:
            from core.capture import CaptureManager
            from core.highlight_detector import HighlightDetector
            cap  = CaptureManager()
            frame = cap.screenshot()
            if frame is None:
                raise RuntimeError("No frame — is OSRS open?")
            det = HighlightDetector(self._hl_colour)
            targets = det.find(frame,
                min_area=int(self._tune_vars["min_area"].get()),
                max_area=int(self._tune_vars["max_area"].get()))
            vis = det.debug_frame(frame)
            # Convert BGR numpy → PhotoImage
            import cv2
            from PIL import Image
            rgb = cv2.cvtColor(vis, cv2.COLOR_BGR2RGB)
            pil = Image.fromarray(rgb)
            # Fit inside preview canvas
            pw = max(1, self._preview_canvas.winfo_width())
            ph = 160
            pil.thumbnail((pw, ph), Image.LANCZOS)
            import tkinter as _tk
            photo = _tk.PhotoImage(data=pil.tobytes())   # won't work
            # Use ImageTk if available
            try:
                from PIL import ImageTk
                photo = ImageTk.PhotoImage(pil)
            except ImportError:
                photo = None
            with self._test_lock:
                self._test_img = photo
            n = len(targets)
            msg = (f"Found {n} target{'s' if n != 1 else ''}." if n
                   else "No targets detected.")
            if targets:
                cx, cy = targets[0].centre
                msg += f"  Nearest: ({cx}, {cy})  area={targets[0].area:.0f}"
            self.after(0, self._show_capture_result, msg, True)
        except Exception as e:
            self.after(0, self._show_capture_result, str(e), False)

    def _show_capture_result(self, msg, ok):
        self._test_status.config(
            text=msg, fg=C["status_run"] if ok else C["status_stop"])
        self._preview_canvas.delete("all")
        with self._test_lock:
            photo = self._test_img
        if photo:
            pw = self._preview_canvas.winfo_width() or 240
            self._preview_canvas.config(height=160)
            self._preview_canvas.create_image(pw//2, 80,
                                              image=photo, anchor="center")
            self._preview_canvas._photo_ref = photo
        else:
            self._preview_canvas.create_text(
                120, 80, text="PIL/ImageTk required for preview.",
                font=F_CINZEL_T, fill=C["text_dim"])

    # ── map panel ─────────────────────────────────────────────────────────

    def _build_map_panel(self, parent):
        bg = C["stone_darkest"]
        frm = tk.Frame(parent, bg=bg)
        frm.pack(fill="both", expand=True, padx=14, pady=(0, 14))

        _section_header(frm, "Live OSRS Map", bg=bg)

        # Zoom controls
        zoom_frame = tk.Frame(frm, bg=bg)
        zoom_frame.pack(fill="x", pady=(0, 4))

        self._zoom_lbl = tk.Label(zoom_frame,
                                  text="%.2f×" % _ZOOM_LEVELS[self._zoom_idx],
                                  font=F_MONO_S, fg=C["gold_pale"], bg=bg)
        self._zoom_lbl.pack(side="left")

        for sym, delta in (("−", -1), ("+", 1)):
            tk.Button(zoom_frame, text=sym, font=F_CINZEL_S,
                      fg=C["gold_bright"], bg=C["stone_mid"],
                      relief="flat", bd=0, width=2, cursor="hand2",
                      activebackground=C["stone_light"],
                      command=lambda d=delta: self._zoom_map(d)
                      ).pack(side="left", padx=2)

        # Coord bar
        self._coord_lbl = tk.Label(zoom_frame, text="",
                                   font=F_MONO_S, fg=C["text_dim"], bg=bg)
        self._coord_lbl.pack(side="right")

        # Map canvas
        self._map_canvas = tk.Canvas(frm, bg=C["stone_darkest"],
                                     highlightthickness=1,
                                     highlightbackground=C["stone_border"],
                                     cursor="crosshair")
        self._map_canvas.pack(fill="both", expand=True)

        # Controls row
        ctrl_row = tk.Frame(frm, bg=bg)
        ctrl_row.pack(fill="x", pady=(4, 0))

        tk.Button(ctrl_row, text="⊕  Centre on Player",
                  font=F_CINZEL_T, fg=C["rune_cyan"],
                  bg=C["stone_mid"], relief="flat", bd=0,
                  highlightthickness=1, highlightbackground=C["stone_border"],
                  activebackground=C["stone_light"],
                  activeforeground=C["rune_cyan"], cursor="hand2",
                  padx=8, pady=3,
                  command=self._centre_on_player).pack(side="left")

        self._tracking_lbl = tk.Label(ctrl_row, text="Location detector inactive",
                                      font=F_CINZEL_T, fg=C["text_dim"], bg=bg)
        self._tracking_lbl.pack(side="left", padx=(10, 0))

        self._tile_status_lbl = tk.Label(ctrl_row, text="Loading map…",
                                         font=F_MONO_S, fg=C["gold_mid"], bg=bg)
        self._tile_status_lbl.pack(side="right")

        # Bindings
        self._map_canvas.bind("<ButtonPress-1>",   self._drag_start_cb)
        self._map_canvas.bind("<B1-Motion>",        self._drag_move_cb)
        self._map_canvas.bind("<ButtonRelease-1>",  self._drag_end_cb)
        self._map_canvas.bind("<MouseWheel>",       self._scroll_zoom)
        self._map_canvas.bind("<Button-4>",         self._scroll_zoom)
        self._map_canvas.bind("<Button-5>",         self._scroll_zoom)
        self._map_canvas.bind("<Double-Button-1>",  self._double_click_centre)
        self._map_canvas.bind("<Motion>",           self._hover_coords)
        self._map_canvas.bind("<Configure>",        self._on_canvas_resize)
        self._map_canvas.bind("<ButtonPress-3>",    self._right_click_coords)

        # Kick off map load
        self._poll_tile_status()

    # ── coordinate helpers ────────────────────────────────────────────────

    def _zoom_mult(self):
        return _ZOOM_LEVELS[self._zoom_idx]

    def _eff_scale(self):
        """Canvas pixels per game square at current zoom."""
        from tile_map import _PX_PER_SQ
        return _PX_PER_SQ * self._zoom_mult()

    def _world_to_canvas(self, wx, wy, cw, ch):
        """World tile coords → canvas pixel coords."""
        eff = self._eff_scale()
        cx = cw // 2 + (wx - self._center_x) * eff
        cy = ch // 2 - (wy - self._center_y) * eff
        return int(cx), int(cy)

    def _canvas_to_world(self, cx, cy, cw, ch):
        """Canvas pixel → world tile coords via tile_map module."""
        from tile_map import canvas_to_world as _ctw
        return _ctw(cx, cy, self._center_x, self._center_y, cw, ch, self._zoom_mult())

    # ── drawing ───────────────────────────────────────────────────────────

    def _try_exists(self):
        try: return self.winfo_exists()
        except Exception: return False

    def _redraw_map(self, *_):
        """Schedule a background render — debounced so rapid calls collapse."""
        if self._redraw_queued:
            return
        self._redraw_queued = True
        try:
            self.after(16, self._redraw_map_now)
        except Exception:
            self._redraw_queued = False

    def _redraw_map_now(self):
        """Kick off oversized background render, blit result on main thread."""
        self._redraw_queued = False
        c = self._map_canvas
        try:
            cw = c.winfo_width()
            ch = c.winfo_height()
        except Exception:
            return
        if cw < 2 or ch < 2:
            return

        cx  = self._center_x
        cy  = self._center_y
        pz  = self._player_z or 0
        zm  = self._zoom_mult()
        pwx = self._player_x
        pwy = self._player_y
        mgn = self._buf_margin

        # Store latest request so a finishing render can re-check
        self._latest_render = (cx, cy, zm, pz)

        if self._render_pending:
            # Already rendering — it will re-check _latest_render when done
            return
        self._render_pending = True

        def _render(rcx, rcy, rpz, rzm):
            try:
                from tile_map import stitch_viewport
                img, dot_cx, dot_cy, icons = stitch_viewport(
                    rcx, rcy, rpz, cw, ch, rzm, pwx, pwy, margin_px=mgn)
            except Exception as e:
                self._render_pending = False
                _err = str(e)
                try:
                    self.after(0, lambda msg=_err: (
                        c.delete("all"),
                        c.create_text(cw//2, ch//2, text="Map error:\n"+msg,
                                      font=F_FELL_S, fill=C["status_stop"],
                                      justify="center")
                    ))
                except Exception:
                    pass
                return
            try:
                self.after(0, lambda: self._blit(
                    c, img, dot_cx, dot_cy, cw, ch, pwx, pwy, icons,
                    rcx, rcy, rzm))
            except Exception:
                pass
            finally:
                self._render_pending = False
                # If state changed while we were rendering, kick another render
                latest = self._latest_render
                if latest and latest != (rcx, rcy, rzm, rpz):
                    try:
                        self.after(0, self._redraw_map)
                    except Exception:
                        pass

        threading.Thread(target=_render,
                         args=(cx, cy, pz, zm), daemon=True).start()

    def _blit(self, c, img, dot_cx, dot_cy, cw, ch, px_w, px_y, icons,
              buf_cx, buf_cy, buf_zm):
        """Called on main thread: swap in new oversized PhotoImage."""
        try:
            if not self._try_exists():
                return
            from PIL import ImageTk
            photo = ImageTk.PhotoImage(img)

            c.delete("all")
            c.create_image(0, 0, image=photo, anchor="nw", tags="mapbuf")
            self._map_photo    = photo
            self._buf_center_x = buf_cx
            self._buf_center_y = buf_cy
            self._buf_zoom     = buf_zm
            self._pan_ox = 0
            self._pan_oy = 0

            self._draw_icons_and_dot(c, icons, dot_cx, dot_cy, cw, ch, px_w, px_y)
        except Exception:
            pass

    def _draw_icons_and_dot(self, c, icons, dot_cx, dot_cy, cw, ch, px_w, px_y):
        """Draw icons and player beacon on top of the map image."""
        from tile_map import _fetch_icon, _CAT_COLOURS
        from PIL import ImageTk, Image as _PILImg
        zm  = self._zoom_mult()
        isz = max(18, int(20 * zm))

        if not hasattr(c, '_icon_imgs'):
            c._icon_imgs = {}

        if icons:
            for icx, icy, icon_id, cat, name in icons:
                sx = icx
                sy = icy
                is_city = (cat == 'city')
                pil_icon = _fetch_icon(icon_id)
                if pil_icon is not None and not is_city:
                    key = f"{icon_id}_{isz}"
                    if key not in c._icon_imgs:
                        sized = pil_icon.resize((isz, isz), _PILImg.BILINEAR)
                        c._icon_imgs[key] = ImageTk.PhotoImage(sized)
                    c.create_image(sx, sy, image=c._icon_imgs[key],
                                   anchor="center", tags="icon")
                elif not is_city:
                    col = _CAT_COLOURS.get(cat, '#FFD700')
                    r   = max(6, isz // 3)
                    c.create_oval(sx-r, sy-r, sx+r, sy+r,
                                  fill=col, outline="#000", width=1, tags="icon")

                if is_city and name:
                    fsz = max(8, int(10 * zm))
                    c.create_text(sx+1, sy+1, text=name,
                                  font=("Helvetica", fsz, "bold"),
                                  fill="#000000", tags="icon_shadow")
                    c.create_text(sx, sy, text=name,
                                  font=("Helvetica", fsz, "bold"),
                                  fill="#FFDD88", tags="icon_label")
                elif zm >= 1.0 and name:
                    c.create_text(sx+1, sy - isz//2 - 4, text=name,
                                  font=("Helvetica", max(7, int(8*zm))),
                                  fill="#000000", tags="icon_shadow")
                    c.create_text(sx,   sy - isz//2 - 5, text=name,
                                  font=("Helvetica", max(7, int(8*zm))),
                                  fill="#FFFFFF", tags="icon_label")

        # Player beacon
        if px_w is not None:
            px, py = dot_cx, dot_cy
            if -20 <= px <= cw + 20 and -20 <= py <= ch + 20:
                t = time.time()
                pulse = 0.5 + 0.5 * math.sin(t * 4)
                R  = int(8 + pulse * 4)
                R2 = 5
                c.create_oval(px-R-2, py-R-2, px+R+2, py+R+2,
                              outline="#000000", width=3, tags="player")
                c.create_oval(px-R, py-R, px+R, py+R,
                              outline="#FFFFFF", width=2, fill="", tags="player")
                c.create_oval(px-R2, py-R2, px+R2, py+R2,
                              fill=C["gold_bright"], outline="#000000",
                              width=1, tags="player")
                T, TI = R + 5, R + 2
                for dx, dy in ((0,-1),(0,1),(-1,0),(1,0)):
                    c.create_line(px+dx*TI, py+dy*TI, px+dx*T, py+dy*T,
                                  fill="#000000", width=4, tags="player_shadow")
                for dx, dy in ((0,-1),(0,1),(-1,0),(1,0)):
                    c.create_line(px+dx*TI, py+dy*TI, px+dx*T, py+dy*T,
                                  fill="#FFFFFF", width=2, tags="player")
                if not self._pulse_scheduled:
                    self._pulse_scheduled = True
                    try:
                        if self._try_exists():
                            def _pulse_tick():
                                self._pulse_scheduled = False
                                if not self._render_pending:
                                    self._redraw_map()
                            self.after(150, _pulse_tick)
                    except Exception:
                        self._pulse_scheduled = False

    # ── callbacks ─────────────────────────────────────────────────────────

    def _on_tile_ready(self):
        """Called from tile-cache worker thread when a tile arrives.
        Debounced: collapses rapid tile arrivals into one redraw."""
        try:
            if self._try_exists():
                self.after(0, self._redraw_map)
        except Exception:
            pass

    def _on_map_ready(self):
        """Legacy hook — kept for compatibility."""
        self._on_tile_ready()

    def _drag_start_cb(self, e):
        self._drag_start = (e.x, e.y)
        self._drag_cx    = self._center_x
        self._drag_cy    = self._center_y

    def _drag_move_cb(self, e):
        if self._drag_start is None:
            return
        eff = self._eff_scale()
        dx_px = e.x - self._drag_start[0]
        dy_px = e.y - self._drag_start[1]

        # Update logical centre
        self._center_x = int(self._drag_cx - dx_px / eff)
        self._center_y = int(self._drag_cy + dy_px / eff)

        # Instantly slide the image on canvas — zero cost, instant feedback
        c = self._map_canvas
        c.moveto("mapbuf",      dx_px, dy_px)
        c.moveto("icon",        dx_px, dy_px)
        c.moveto("icon_shadow", dx_px, dy_px)
        c.moveto("icon_label",  dx_px, dy_px)
        c.moveto("player",        dx_px, dy_px)
        c.moveto("player_shadow", dx_px, dy_px)

    def _on_canvas_resize(self, e=None):
        """Debounced resize — wait 200ms after last Configure before re-rendering."""
        try:
            if hasattr(self, '_resize_after_id'):
                self.after_cancel(self._resize_after_id)
            self._resize_after_id = self.after(200, self._redraw_map)
        except Exception:
            pass

    def _drag_end_cb(self, e):
        """On mouse release, commit a clean re-render centred on new position."""
        self._drag_start = None
        self._redraw_map()

    def _scroll_zoom(self, e):
        if e.num == 4 or e.delta > 0:
            self._zoom_map(1)
        else:
            self._zoom_map(-1)

    def _double_click_centre(self, e):
        cw = self._map_canvas.winfo_width()
        ch = self._map_canvas.winfo_height()
        self._center_x, self._center_y = self._canvas_to_world(e.x, e.y, cw, ch)
        self._redraw_map()

    def _hover_coords(self, e):
        cw = self._map_canvas.winfo_width()
        ch = self._map_canvas.winfo_height()
        wx, wy = self._canvas_to_world(e.x, e.y, cw, ch)
        loc = lookup_location_improved(wx, wy)
        loc_str = "  —  " + loc if loc else ""
        self._coord_lbl.config(text="%d, %d%s" % (wx, wy, loc_str))

    def _right_click_coords(self, e):
        """Right-click: copy world coords to clipboard and show a brief toast."""
        cw = self._map_canvas.winfo_width()
        ch = self._map_canvas.winfo_height()
        wx, wy = self._canvas_to_world(e.x, e.y, cw, ch)
        coord_str = f"({wx}, {wy})"
        try:
            self._map_canvas.clipboard_clear()
            self._map_canvas.clipboard_append(coord_str)
        except Exception:
            pass
        # Show a small toast label near the click point
        c = self._map_canvas
        tag = "coord_toast"
        c.delete(tag)
        px = min(e.x + 8, cw - 120)
        py = max(e.y - 22, 4)
        c.create_rectangle(px - 2, py - 2, px + 112, py + 16,
                           fill="#1a1610", outline="#b8892a", width=1, tags=tag)
        c.create_text(px + 55, py + 7, text=f"Copied {coord_str}",
                      font=("Courier", 8), fill="#f0cc6a", tags=tag)
        try:
            self.after(1500, lambda: c.delete(tag))
        except Exception:
            pass

    def _zoom_map(self, delta):
        new_idx = max(0, min(len(_ZOOM_LEVELS) - 1, self._zoom_idx + delta))
        if new_idx != self._zoom_idx:
            self._zoom_idx = new_idx
            self._zoom_lbl.config(text="%.2f×" % _ZOOM_LEVELS[self._zoom_idx])
            self._redraw_map()

    def _poll_tile_status(self):
        try:
            cache = get_tile_cache()
            pending = len(cache._pending)
            if pending:
                self._tile_status_lbl.config(
                    text=f"Loading {pending} tile(s)…", fg=C["gold_mid"])
            else:
                self._tile_status_lbl.config(text="Tiles ready ✓", fg=C["text_dim"])
        except Exception:
            pass
        try:
            if self._try_exists():
                self.after(1000, self._poll_tile_status)
        except Exception:
            pass

    def _centre_on_player(self):
        if self._player_x is not None:
            self._center_x = self._player_x
            self._center_y = self._player_y
            self._redraw_map()

    def _set_plane(self, plane):
        self._player_z = plane
        self._redraw_map()

    def _poll_location(self):
        try:
            self._update_location()
        except Exception:
            pass
        try:
            self.after(1000, self._poll_location)
        except Exception:
            pass

    def _update_location(self):
        coords = None
        # Primary: PositionTracker (RuneLite plugin)
        try:
            if self._pos_tracker and self._pos_tracker.plugin_available:
                pos = self._pos_tracker.position
                if pos:
                    coords = pos
        except Exception:
            pass
        # Fallback: LocationDetector OCR
        if coords is None:
            try:
                ld = getattr(self._bridge, "location_detector", None)
                if ld is None:
                    ld = getattr(self._bridge, "_location_detector", None)
                if ld and ld.coords:
                    coords = ld.coords
            except Exception:
                pass

        if coords:
            x, y, z = coords
            first_fix = self._player_x is None
            self._player_x = x
            self._player_y = y
            self._player_z = z
            # Auto-centre on first fix so player is immediately visible
            if first_fix:
                self._center_x = x
                self._center_y = y
            name = lookup_location_improved(x, y, z)
            loc_str = ("  —  " + name) if name else ""
            self._coord_lbl.config(
                text="%d, %d%s" % (x, y, loc_str),
                fg=C["rune_cyan"])
            self._tracking_lbl.config(
                text="● Tracking", fg=C["status_run"])
            self._redraw_map()
        else:
            self._tracking_lbl.config(
                text="Location detector inactive",
                fg=C["text_dim"])


# ═══════════════════════════════════════════════════════════════════════════
#  PROFILES PAGE
# ═══════════════════════════════════════════════════════════════════════════

# Static XP/hr estimates per script+type (used for badge display only)
_XP_HR_ESTIMATES = {
    "Woodcutting": {"Oak":175000,"Willow":80000,"Teak":130000,"Maple":55000,
                    "Yew":40000,"Magic":28000,"Mahogany":100000},
    "Mining":      {"Iron":65000,"Coal":35000,"Gold":48000,"Mithril":22000,
                    "Adamantite":15000,"Runite":10000},
    "Fishing":     {"Shrimp / Anchovies":20000,"Trout / Salmon":45000,
                    "Lobster":30000,"Swordfish / Tuna":25000,"Shark":18000},
    "Firemaking":  {"Normal":250000,"Oak":300000,"Willow":350000,
                    "Maple":380000,"Yew":400000,"Magic":420000},
    "Cooking":     {"Shrimp":80000,"Trout":150000,"Salmon":180000,
                    "Lobster":220000,"Swordfish":250000,"Shark":270000},
    "Agility":     {"Gnome Stronghold":9000,"Draynor":12000,"Al Kharid":16000,
                    "Varrock":18000,"Canifis":30000,"Falador":40000,
                    "Seers Village":55000,"Rellekka":60000,"Ardougne":68000},
}


class ProfilesPage(tk.Frame):
    """
    Left panel  — scrollable list of saved profiles as selectable cards.
    Right panel — editor for the selected profile.
    """

    SCRIPTS = {
        "Woodcutting": {
            "category": "Gathering",
            "xp_key": "tree_type",
            "fields": [
                ("tree_type","Tree Type","dropdown",
                 ["Oak","Willow","Maple","Yew","Magic","Teak","Mahogany"]),
                ("mode","Mode","dropdown",
                 ["Power Chop","Bank Logs","Tick Manipulation"]),
                ("highlight_colour","Highlight Colour","colour","#00FFFF"),
            ],
        },
        "Mining": {
            "category": "Gathering",
            "xp_key": "rock_type",
            "fields": [
                ("rock_type","Rock Type","dropdown",
                 ["Iron","Coal","Gold","Mithril","Adamantite","Runite"]),
                ("mode","Mode","dropdown",
                 ["Power Mine","Bank Ore","3-Tick"]),
                ("highlight_colour","Highlight Colour","colour","#FF8800"),
            ],
        },
        "Fishing": {
            "category": "Gathering",
            "xp_key": "fish_type",
            "fields": [
                ("fish_type","Fish Type","dropdown",
                 ["Shrimp / Anchovies","Trout / Salmon","Lobster",
                  "Swordfish / Tuna","Shark"]),
                ("mode","Mode","dropdown",["Power Fish","Bank Fish"]),
                ("highlight_colour","Highlight Colour","colour","#4488FF"),
            ],
        },
        "Firemaking": {
            "category": "Processing",
            "xp_key": "log_type",
            "fields": [
                ("log_type","Log Type","dropdown",
                 ["Normal","Oak","Willow","Maple","Yew","Magic"]),
                ("method","Method","dropdown",
                 ["Straight Line","Wintertodt"]),
            ],
        },
        "Cooking": {
            "category": "Processing",
            "xp_key": "food_type",
            "fields": [
                ("food_type","Food","dropdown",
                 ["Shrimp","Trout","Salmon","Lobster","Swordfish","Shark"]),
                ("location","Location","dropdown",
                 ["Rogues Den","Hosidius Range","Al Kharid"]),
            ],
        },
        "Agility": {
            "category": "Support",
            "xp_key": "course",
            "fields": [
                ("course","Course","dropdown",
                 ["Gnome Stronghold","Draynor","Al Kharid","Varrock","Canifis",
                  "Falador","Seers Village","Rellekka","Ardougne"]),
            ],
        },
    }

    _PROFILE_FILE = None

    def __init__(self, parent, bridge=None, nav_callback=None, **kw):
        kw.setdefault("bg", C["stone_darkest"])
        super().__init__(parent, **kw)
        self._bridge       = bridge
        self._nav_callback = nav_callback
        self._profiles     = []
        self._selected_idx = None
        self._field_vars   = {}

        import os as _os
        here = _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__)))
        self._PROFILE_FILE = _os.path.join(here, "data", "profiles.json")
        self._load_profiles()
        self._build()

    # ── persistence ──────────────────────────────────────────────────────

    def _load_profiles(self):
        import json, os as _os
        try:
            if _os.path.isfile(self._PROFILE_FILE):
                with open(self._PROFILE_FILE, encoding="utf-8") as f:
                    self._profiles = json.load(f)
        except Exception:
            self._profiles = []
        if not self._profiles:
            self._profiles = [self._default_profile("Oak Power Chop","Woodcutting")]

    def _save_profiles(self):
        import json, os as _os
        try:
            _os.makedirs(_os.path.dirname(self._PROFILE_FILE), exist_ok=True)
            with open(self._PROFILE_FILE, "w", encoding="utf-8") as f:
                json.dump(self._profiles, f, indent=2)
        except Exception:
            pass

    def _default_profile(self, name, script):
        p = {"name": name, "script": script, "config": {},
             "antiban": 1.0, "antiban_global": True, "rsn": "",
             "duration_min": 0, "notes": "", "last_run": None, "last_xp": 0}
        for key, _, ftype, default in self.SCRIPTS.get(script, {}).get("fields", []):
            if ftype == "dropdown":
                p["config"][key] = default[0] if isinstance(default, list) else default
            elif ftype == "colour":
                p["config"][key] = default
        return p

    # ── layout ───────────────────────────────────────────────────────────

    def _build(self):
        bg = C["stone_darkest"]

        panes = tk.Frame(self, bg=bg)
        panes.pack(fill="both", expand=True)

        # ── Left panel ────────────────────────────────────────────────
        left = tk.Frame(panes, bg=bg, width=270)
        left.pack(side="left", fill="y")
        left.pack_propagate(False)

        _section_header(left, "Profiles", bg=bg)

        # Toolbar row 1 — profile actions
        tb = tk.Frame(left, bg=bg)
        tb.pack(fill="x", pady=(0, 4), padx=12)
        for text, cmd in [("+ New",  self._new_profile),
                          ("Dupe",   self._dupe_profile),
                          ("Delete", self._delete_profile)]:
            tk.Button(tb, text=text, font=F_CINZEL_T,
                      fg=C["gold_mid"], bg=C["stone_mid"],
                      relief="flat", bd=0, padx=8, pady=3,
                      cursor="hand2",
                      highlightthickness=1,
                      highlightbackground=C["stone_border"],
                      activebackground=C["stone_light"],
                      activeforeground=C["gold_bright"],
                      command=cmd).pack(side="left", padx=(0, 4))

        # Toolbar row 2 — import/export
        tb2 = tk.Frame(left, bg=bg)
        tb2.pack(fill="x", pady=(0, 8), padx=12)
        for text, cmd in [("↑ Export", self._export_profiles),
                          ("↓ Import", self._import_profiles)]:
            tk.Button(tb2, text=text, font=F_CINZEL_T,
                      fg=C["rune_cyan"], bg=C["stone_mid"],
                      relief="flat", bd=0, padx=8, pady=3,
                      cursor="hand2",
                      highlightthickness=1,
                      highlightbackground=C["stone_border"],
                      activebackground=C["stone_light"],
                      activeforeground=C["rune_cyan"],
                      command=cmd).pack(side="left", padx=(0, 4))

        # Scrollable card list
        list_frame = tk.Frame(left, bg=bg)
        list_frame.pack(fill="both", expand=True, padx=12)

        list_canvas = tk.Canvas(list_frame, bg=bg, highlightthickness=0)
        list_canvas.pack(side="left", fill="both", expand=True)
        vsb = tk.Scrollbar(list_frame, orient="vertical",
                           command=list_canvas.yview)
        vsb.pack(side="right", fill="y")
        list_canvas.config(yscrollcommand=vsb.set)

        self._list_inner = tk.Frame(list_canvas, bg=bg)
        self._list_win   = list_canvas.create_window(
            (0, 0), window=self._list_inner, anchor="nw")
        self._list_inner.bind("<Configure>", lambda e: list_canvas.configure(
            scrollregion=list_canvas.bbox("all")))
        list_canvas.bind("<Configure>", lambda e: list_canvas.itemconfig(
            self._list_win, width=e.width))
        _invisible_scroll(list_canvas)

        # Divider
        tk.Frame(panes, bg=C["stone_border"], width=1).pack(
            side="left", fill="y")

        # ── Right panel ───────────────────────────────────────────────
        right_outer = tk.Frame(panes, bg=bg)
        right_outer.pack(side="left", fill="both", expand=True)

        self._editor_canvas = tk.Canvas(right_outer, bg=bg, highlightthickness=0)
        self._editor_canvas.pack(fill="both", expand=True)
        self._editor_inner = tk.Frame(self._editor_canvas, bg=bg)
        self._editor_win   = self._editor_canvas.create_window(
            (0, 0), window=self._editor_inner, anchor="nw")
        self._editor_inner.bind("<Configure>", lambda e: self._editor_canvas.configure(
            scrollregion=self._editor_canvas.bbox("all")))
        self._editor_canvas.bind("<Configure>", lambda e: self._editor_canvas.itemconfig(
            self._editor_win, width=e.width))
        _invisible_scroll(self._editor_canvas)

        self._rebuild_list()
        if self._profiles:
            self._select(0)

    # ── helpers ──────────────────────────────────────────────────────────

    def _om(self, parent, var, choices):
        """Styled OptionMenu with ▾ caret, no native indicator."""
        disp = tk.StringVar(value=var.get() + "  ▾")
        def _upd(*_, v=var, d=disp): d.set(v.get() + "  ▾")
        var.trace_add("write", _upd)
        om = tk.OptionMenu(parent, var, *choices)
        om.config(font=F_MONO_S, bg=C["stone_dark"], fg=C["text_mono"],
                  relief="flat", highlightthickness=1,
                  highlightbackground=C["stone_border"],
                  activebackground=C["stone_light"],
                  activeforeground=C["gold_bright"],
                  indicatoron=False, bd=0, textvariable=disp)
        om["menu"].config(bg=C["stone_dark"], fg=C["text_mono"],
                          font=F_MONO_S,
                          activebackground=C["stone_light"],
                          activeforeground=C["gold_bright"])
        return om

    def _entry(self, parent, var, width=18):
        return tk.Entry(parent, textvariable=var, width=width,
                        font=F_MONO_S, bg=C["stone_dark"],
                        fg=C["text_mono"],
                        insertbackground=C["gold_mid"],
                        relief="flat", bd=3,
                        highlightthickness=1,
                        highlightbackground=C["stone_border"],
                        highlightcolor=C["gold_deep"])

    def _card_section(self, parent, title):
        _section_header(parent, title, bg=C["stone_darkest"])
        outer = tk.Frame(parent, bg=C["stone_mid"],
                         highlightthickness=1,
                         highlightbackground=C["stone_border"])
        outer.pack(fill="x", padx=24, pady=(0, 12))
        inner = tk.Frame(outer, bg=C["stone_mid"])
        inner.pack(fill="x", padx=14, pady=12)
        return inner

    @staticmethod
    def _xp_hr_str(script, cfg):
        xp_key = {"Woodcutting":"tree_type","Mining":"rock_type",
                  "Fishing":"fish_type","Firemaking":"log_type",
                  "Cooking":"food_type","Agility":"course"}.get(script)
        if not xp_key:
            return None
        val = cfg.get(xp_key)
        xp  = _XP_HR_ESTIMATES.get(script, {}).get(val)
        if not xp:
            return None
        return f"~{xp//1000}k xp/hr"

    @staticmethod
    def _last_run_str(ts):
        if not ts:
            return "Never run"
        import time as _t
        diff = int(_t.time() - ts)
        if diff < 60:    return "Just now"
        if diff < 3600:  return f"{diff//60}m ago"
        if diff < 86400: return f"{diff//3600}h ago"
        return f"{diff//86400}d ago"

    # ── profile list ─────────────────────────────────────────────────────

    def _rebuild_list(self):
        for w in self._list_inner.winfo_children():
            w.destroy()
        for i, p in enumerate(self._profiles):
            self._make_card(i, p)

    def _make_card(self, idx, profile):
        selected = (idx == self._selected_idx)
        border   = C["gold_deep"]    if selected else C["stone_border"]
        bg_card  = C["stone_mid"]    if selected else C["stone_dark"]

        card = tk.Frame(self._list_inner, bg=bg_card,
                        highlightthickness=1,
                        highlightbackground=border,
                        cursor="hand2")
        card.pack(fill="x", pady=(0, 5))

        inner = tk.Frame(card, bg=bg_card)
        inner.pack(fill="x", padx=10, pady=8)

        # Top row: category + xp/hr estimate
        top = tk.Frame(inner, bg=bg_card)
        top.pack(fill="x", pady=(0, 2))
        script = profile.get("script", "Woodcutting")
        cat    = self.SCRIPTS.get(script, {}).get("category", "")
        tk.Label(top, text=cat.upper(), font=F_CINZEL_T,
                 fg=C["gold_deep"], bg=bg_card).pack(side="left")

        xp_str = self._xp_hr_str(script, profile.get("config", {}))
        if xp_str:
            tk.Label(top, text=xp_str, font=F_MONO_S,
                     fg=C["rune_green"], bg=bg_card).pack(side="right")

        # Profile name
        name_col = C["gold_shine"] if selected else C["text_sec"]
        tk.Label(inner, text=profile.get("name", "Unnamed"),
                 font=F_CINZEL_S, fg=name_col,
                 bg=bg_card).pack(anchor="w")

        # Summary line
        cfg = profile.get("config", {})
        parts = [script]
        for key, _, ftype, _ in self.SCRIPTS.get(script, {}).get("fields", []):
            if ftype == "dropdown" and key in cfg:
                parts.append(cfg[key])
        tk.Label(inner, text="  ·  ".join(parts[:3]),
                 font=F_MONO_S, fg=C["text_dim"],
                 bg=bg_card).pack(anchor="w", pady=(1, 3))

        # Bottom row: last run + duration badge
        bot = tk.Frame(inner, bg=bg_card)
        bot.pack(fill="x")
        tk.Label(bot, text=self._last_run_str(profile.get("last_run")),
                 font=F_MONO_S, fg=C["text_dim"],
                 bg=bg_card).pack(side="left")
        dur = profile.get("duration_min", 0)
        if dur:
            tk.Label(bot, text=f"⏱ {dur}m", font=F_CINZEL_T,
                     fg=C["gold_deep"], bg=bg_card).pack(side="right")

        # Bind clicks on card and all children
        def _bind_all(w, i=idx):
            w.bind("<Button-1>", lambda e: self._select(i))
            for c in w.winfo_children():
                _bind_all(c, i)
        _bind_all(card)

    def _select(self, idx):
        self._selected_idx = idx
        self._rebuild_list()
        self._rebuild_editor()

    # ── editor ───────────────────────────────────────────────────────────

    def _rebuild_editor(self):
        for w in self._editor_inner.winfo_children():
            w.destroy()
        self._field_vars = {}

        if self._selected_idx is None or self._selected_idx >= len(self._profiles):
            tk.Label(self._editor_inner,
                     text="Select a profile to edit.",
                     font=F_FELL_S, fg=C["text_dim"],
                     bg=C["stone_darkest"]).pack(expand=True, pady=40)
            return

        profile = self._profiles[self._selected_idx]
        bg = C["stone_darkest"]

        # ── Identity ──────────────────────────────────────────────────
        inn = self._card_section(self._editor_inner, "Edit Profile")

        r = tk.Frame(inn, bg=C["stone_mid"])
        r.pack(fill="x", pady=(0, 8))
        _label(r, "Profile Name", font=F_CINZEL_S).pack(side="left")
        name_var = tk.StringVar(value=profile.get("name",""))
        self._field_vars["_name"] = name_var
        self._entry(r, name_var, width=26).pack(side="left", padx=(8, 0))

        r2 = tk.Frame(inn, bg=C["stone_mid"])
        r2.pack(fill="x")
        _label(r2, "Script", font=F_CINZEL_S).pack(side="left")
        script_var = tk.StringVar(value=profile.get("script","Woodcutting"))
        self._field_vars["_script"] = script_var
        self._om(r2, script_var, list(self.SCRIPTS.keys())).pack(
            side="left", padx=(8, 0))
        script_var.trace_add("write", lambda *_: self._on_script_change())

        # ── Script config ─────────────────────────────────────────────
        _section_header(self._editor_inner, "Configuration", bg=bg)
        self._fields_panel = tk.Frame(self._editor_inner, bg=C["stone_mid"],
                                      highlightthickness=1,
                                      highlightbackground=C["stone_border"])
        self._fields_panel.pack(fill="x", padx=24, pady=(0, 12))
        self._build_script_fields(profile)

        # ── Behaviour overrides ───────────────────────────────────────
        inn2 = self._card_section(self._editor_inner, "Behaviour Overrides")

        # Antiban
        ab_r = tk.Frame(inn2, bg=C["stone_mid"])
        ab_r.pack(fill="x", pady=(0, 4))
        _label(ab_r, "Antiban Intensity", font=F_CINZEL_S).pack(side="left")
        ab_global = tk.BooleanVar(value=profile.get("antiban_global", True))
        self._field_vars["_antiban_global"] = ab_global
        tk.Checkbutton(ab_r, text="Use global", variable=ab_global,
                       font=F_CINZEL_T, fg=C["text_dim"],
                       bg=C["stone_mid"], selectcolor=C["stone_dark"],
                       activebackground=C["stone_mid"],
                       activeforeground=C["gold_bright"]).pack(side="right")

        ab_box = tk.Frame(inn2, bg=C["stone_dark"],
                          highlightthickness=1,
                          highlightbackground=C["stone_border"])
        ab_box.pack(fill="x", pady=(0, 10))
        ab_inner = tk.Frame(ab_box, bg=C["stone_dark"])
        ab_inner.pack(fill="x", padx=8, pady=6)

        ab_val = tk.DoubleVar(value=profile.get("antiban", 1.0))
        self._field_vars["_antiban"] = ab_val
        ab_lbl = tk.Label(ab_inner, text=f"{ab_val.get():.1f}×",
                          font=F_MONO_S, fg=C["gold_pale"], bg=C["stone_dark"])
        ab_lbl.pack(anchor="e")
        def _ab_mv(v): ab_lbl.config(text=f"{float(v):.1f}×")
        HSlider(ab_inner, variable=ab_val, from_=0.0, to=2.0,
                resolution=0.1, length=200, command=_ab_mv,
                bg=C["stone_dark"]).pack(anchor="w", fill="x")

        # RSN override
        rsn_r = tk.Frame(inn2, bg=C["stone_mid"])
        rsn_r.pack(fill="x", pady=(0, 8))
        _label(rsn_r, "RSN Override", font=F_CINZEL_S).pack(side="left")
        rsn_var = tk.StringVar(value=profile.get("rsn",""))
        self._field_vars["_rsn"] = rsn_var
        self._entry(rsn_r, rsn_var, width=16).pack(side="left", padx=(8, 6))
        _label(rsn_r, "(blank = use global)", font=F_CINZEL_T,
               fg=C["text_dim"]).pack(side="left")

        # Duration limit
        dur_r = tk.Frame(inn2, bg=C["stone_mid"])
        dur_r.pack(fill="x")
        _label(dur_r, "Run for (minutes)", font=F_CINZEL_S).pack(side="left")
        dur_var = tk.StringVar(value=str(profile.get("duration_min", 0)))
        self._field_vars["_duration_min"] = dur_var
        self._entry(dur_r, dur_var, width=6).pack(side="left", padx=(8, 6))
        _label(dur_r, "0 = unlimited", font=F_CINZEL_T,
               fg=C["text_dim"]).pack(side="left")

        # ── Notes ─────────────────────────────────────────────────────
        inn3 = self._card_section(self._editor_inner, "Notes")
        notes_frame = tk.Frame(inn3, bg=C["stone_dark"],
                               highlightthickness=1,
                               highlightbackground=C["stone_border"])
        notes_frame.pack(fill="x")
        self._notes_text = tk.Text(notes_frame, height=4,
                                   bg=C["stone_dark"], fg=C["text_sec"],
                                   font=F_MONO_S, relief="flat", bd=0,
                                   wrap="word", insertbackground=C["gold_mid"],
                                   highlightthickness=0,
                                   selectbackground=C["stone_border"])
        self._notes_text.pack(fill="x", padx=6, pady=6)
        self._notes_text.insert("1.0", profile.get("notes", ""))

        # ── Action buttons ────────────────────────────────────────────
        btn_row = tk.Frame(self._editor_inner, bg=bg)
        btn_row.pack(fill="x", padx=24, pady=(4, 20))

        def _btn(text, fg, cmd, right=False):
            b = tk.Button(btn_row, text=text, font=F_CINZEL_S,
                          fg=fg, bg=C["stone_mid"], relief="flat", bd=0,
                          highlightthickness=1,
                          highlightbackground=C["stone_border"],
                          activebackground=C["stone_light"],
                          activeforeground=C["gold_bright"],
                          cursor="hand2", padx=12, pady=5, command=cmd)
            b.pack(side="right" if right else "left",
                   padx=(6, 0) if right else (0, 6))
            return b

        _btn("Save",          C["gold_mid"],   self._save_current)
        _btn("▶  Load & Run", C["status_run"], self._load_and_run, right=True)
        _btn("Apply to Card", C["rune_cyan"],  self._apply_to_card, right=True)

    def _build_script_fields(self, profile):
        for w in self._fields_panel.winfo_children():
            w.destroy()
        script = self._field_vars.get("_script",
                 tk.StringVar(value=profile.get("script","Woodcutting"))).get()
        fields = self.SCRIPTS.get(script, {}).get("fields", [])
        cfg    = profile.get("config", {})
        bg     = C["stone_mid"]
        inner  = tk.Frame(self._fields_panel, bg=bg)
        inner.pack(fill="x", padx=14, pady=12)

        for key, label, ftype, default in fields:
            row = tk.Frame(inner, bg=bg)
            row.pack(fill="x", pady=(0, 8))
            _label(row, label, font=F_CINZEL_S).pack(side="left", anchor="n", pady=(2,0))

            if ftype == "dropdown":
                choices = default if isinstance(default, list) else [default]
                var = tk.StringVar(value=cfg.get(key, choices[0]))
                self._field_vars[key] = var
                self._om(row, var, choices).pack(side="left", padx=(8, 0))

            elif ftype == "colour":
                current = cfg.get(key, default)
                var = tk.StringVar(value=current)
                self._field_vars[key] = var
                pf = tk.Frame(row, bg=bg)
                pf.pack(side="left", padx=(8, 0))
                cp = ColourPicker(pf, initial=current,
                                  on_change=lambda h, v=var: v.set(h), bg=bg)
                cp.pack()

    def _on_script_change(self):
        if self._selected_idx is None:
            return
        profile = self._profiles[self._selected_idx]
        new_script = self._field_vars.get("_script",
                     tk.StringVar(value="Woodcutting")).get()
        profile["script"] = new_script
        profile["config"] = {}
        for key, _, ftype, default in self.SCRIPTS.get(new_script,{}).get("fields",[]):
            if ftype == "dropdown":
                profile["config"][key] = default[0] if isinstance(default,list) else default
            elif ftype == "colour":
                profile["config"][key] = default
        self._build_script_fields(profile)

    # ── collect / save ────────────────────────────────────────────────────

    def _collect_current(self):
        if self._selected_idx is None:
            return
        p = self._profiles[self._selected_idx]
        if "_name"           in self._field_vars:
            p["name"]            = self._field_vars["_name"].get().strip() or "Unnamed"
        if "_script"         in self._field_vars:
            p["script"]          = self._field_vars["_script"].get()
        if "_antiban"        in self._field_vars:
            p["antiban"]         = self._field_vars["_antiban"].get()
        if "_antiban_global" in self._field_vars:
            p["antiban_global"]  = self._field_vars["_antiban_global"].get()
        if "_rsn"            in self._field_vars:
            p["rsn"]             = self._field_vars["_rsn"].get().strip()
        if "_duration_min"   in self._field_vars:
            try:    p["duration_min"] = int(self._field_vars["_duration_min"].get())
            except: p["duration_min"] = 0
        if hasattr(self, "_notes_text"):
            p["notes"] = self._notes_text.get("1.0", "end-1c")
        # Script config fields
        cfg    = p.setdefault("config", {})
        script = p.get("script", "Woodcutting")
        for key, _, ftype, _ in self.SCRIPTS.get(script, {}).get("fields", []):
            if key in self._field_vars:
                cfg[key] = self._field_vars[key].get()

    def _save_current(self):
        self._collect_current()
        self._save_profiles()
        self._rebuild_list()

    # ── import / export ───────────────────────────────────────────────────

    def _export_profiles(self):
        import json
        from tkinter import filedialog
        path = filedialog.asksaveasfilename(
            title="Export Profiles",
            defaultextension=".json",
            filetypes=[("JSON files","*.json"),("All files","*.*")],
            initialfile="runescript_profiles.json")
        if not path:
            return
        try:
            with open(path, "w", encoding="utf-8") as f:
                json.dump(self._profiles, f, indent=2)
        except Exception as e:
            from tkinter import messagebox
            messagebox.showerror("Export Failed", str(e))

    def _import_profiles(self):
        import json
        from tkinter import filedialog, messagebox
        path = filedialog.askopenfilename(
            title="Import Profiles",
            filetypes=[("JSON files","*.json"),("All files","*.*")])
        if not path:
            return
        try:
            with open(path, encoding="utf-8") as f:
                imported = json.load(f)
            if not isinstance(imported, list):
                raise ValueError("Expected a list of profiles.")
            self._profiles.extend(imported)
            self._save_profiles()
            self._rebuild_list()
            self._select(len(self._profiles) - 1)
        except Exception as e:
            messagebox.showerror("Import Failed", str(e))

    # ── profile list mutations ────────────────────────────────────────────

    def _new_profile(self):
        p = self._default_profile(
            f"New Profile {len(self._profiles)+1}", "Woodcutting")
        self._profiles.append(p)
        self._save_profiles()
        self._select(len(self._profiles) - 1)

    def _dupe_profile(self):
        if self._selected_idx is None:
            return
        import copy
        p = copy.deepcopy(self._profiles[self._selected_idx])
        p["name"] = p.get("name","Profile") + " (copy)"
        self._profiles.append(p)
        self._save_profiles()
        self._select(len(self._profiles) - 1)

    def _delete_profile(self):
        if self._selected_idx is None or not self._profiles:
            return
        self._profiles.pop(self._selected_idx)
        self._save_profiles()
        new_idx = min(self._selected_idx, len(self._profiles)-1)
        self._selected_idx = None
        if self._profiles:
            self._select(new_idx)
        else:
            self._rebuild_list()
            self._rebuild_editor()

    # ── apply / run ───────────────────────────────────────────────────────

    def _apply_to_card(self):
        self._collect_current()
        if self._selected_idx is None:
            return
        p   = self._profiles[self._selected_idx]
        cfg = p.get("config", {})
        script = p.get("script", "Woodcutting")
        try:
            cc = getattr(self._bridge, "_control_card", None)
            if cc is None:
                return
            cc.set_skill(script)
            if hasattr(cc, "_tree_var") and "tree_type" in cfg:
                cc._tree_var.set(cfg["tree_type"].title())
            if hasattr(cc, "_mode_var") and "mode" in cfg:
                cc._mode_var.set(cfg["mode"].replace("_"," ").title())
            if hasattr(cc, "_colour_picker") and "highlight_colour" in cfg:
                cc._colour_picker.set_color(cfg["highlight_colour"])
            if not p.get("antiban_global", True):
                if hasattr(self._bridge, "set_antiban_intensity"):
                    self._bridge.set_antiban_intensity(p.get("antiban", 1.0))
        except Exception:
            pass

    def _load_and_run(self):
        self._collect_current()
        if self._selected_idx is None:
            return
        import time as _t
        self._profiles[self._selected_idx]["last_run"] = _t.time()
        self._save_profiles()
        self._apply_to_card()

        # Schedule auto-stop if duration set
        dur = self._profiles[self._selected_idx].get("duration_min", 0)
        if dur and dur > 0 and self._bridge:
            self.after(int(dur * 60 * 1000),
                       lambda: self._bridge.stop_script()
                       if hasattr(self._bridge, "stop_script") else None)

        if self._nav_callback:
            self._nav_callback("Dashboard")


class HScrollbar(tk.Canvas):
    """Custom horizontal scrollbar that respects our colour palette."""

    H = 8   # track height px

    def __init__(self, parent, canvas_target, **kw):
        kw.setdefault("bg",    C["stone_dark"])
        kw.setdefault("height", self.H + 4)
        kw["highlightthickness"] = 0
        super().__init__(parent, **kw)
        self._target  = canvas_target
        self._drag_x  = None
        self._thumb_x1 = 0
        self._thumb_x2 = 0

        self._track = self.create_rectangle(
            0, 2, 1, self.H + 2,
            fill=C["stone_mid"], outline=C["stone_border"], width=1)
        self._thumb = self.create_rectangle(
            0, 2, 1, self.H + 2,
            fill=C["stone_border"], outline="", width=0)

        self.bind("<Configure>",       self._redraw)
        self.bind("<ButtonPress-1>",   self._on_press)
        self.bind("<B1-Motion>",       self._on_drag)
        self.bind("<ButtonRelease-1>", self._on_release)
        self.bind("<Enter>",  lambda e: self.itemconfig(self._thumb, fill=C["gold_mid"]))
        self.bind("<Leave>",  lambda e: self.itemconfig(self._thumb, fill=C["stone_border"]))

        canvas_target.bind("<Configure>", lambda e: self._redraw(), add="+")

    def set(self, lo, hi):
        """Called by canvas xscrollcommand."""
        self._lo, self._hi = float(lo), float(hi)
        self._redraw()

    def _redraw(self, *_):
        w = self.winfo_width()
        if w < 2:
            return
        lo, hi = getattr(self, "_lo", 0.0), getattr(self, "_hi", 1.0)
        self.coords(self._track, 2, 2, w - 2, self.H + 2)
        x1 = 2 + lo * (w - 4)
        x2 = 2 + hi * (w - 4)
        x2 = max(x1 + 12, x2)   # minimum thumb width
        self._thumb_x1, self._thumb_x2 = x1, x2
        self.coords(self._thumb, x1, 3, x2, self.H + 1)

    def _on_press(self, e):
        self._drag_x = e.x

    def _on_drag(self, e):
        if self._drag_x is None:
            return
        w = self.winfo_width() - 4
        if w <= 0:
            return
        dx = (e.x - self._drag_x) / w
        self._drag_x = e.x
        self._target.xview_moveto(
            max(0.0, min(1.0, getattr(self, "_lo", 0.0) + dx)))

    def _on_release(self, e):
        self._drag_x = None


class SettingsPage(tk.Frame):
    """
    Three-column settings layout.  Each column is a fixed 260 px wide so
    the block never overruns the right-hand tracker panel.
    """

    # fixed px per column — 3 × 260 + 2 × 8 gap = 796 px total
    COL_W = 260

    def __init__(self, parent, bridge=None, root=None, **kw):
        kw.setdefault("bg", C["stone_darkest"])
        super().__init__(parent, **kw)
        self._bridge = bridge
        self._root   = root

        from core.settings_store import get_store as _gs
        self._store = _gs()
        s = self._store

        self._rl_status_var   = tk.StringVar(value="Not tested")
        self._tess_status_var = tk.StringVar(value="Not tested")
        self._opacity_var     = tk.DoubleVar(value=s.get("opacity",      1.0))
        self._font_scale_var  = tk.DoubleVar(value=s.get("font_scale",   1.0))
        self._antiban_intensity = tk.DoubleVar(value=s.get("antiban_intensity", 1.0))
        self._rl_poll_var     = tk.DoubleVar(value=s.get("rl_poll_interval",  2.0))
        self._loc_poll_var    = tk.DoubleVar(value=s.get("loc_poll_interval", 0.5))
        self._log_level       = tk.StringVar(value=s.get("log_level", "INFO"))
        self._rsn_status_var  = tk.StringVar(value="")

        # Detection tuning vars — shared with DetectionPage via bridge
        self._det_hue_var    = tk.DoubleVar(value=s.get("det_hue_tol",  12))
        self._det_sat_var    = tk.DoubleVar(value=s.get("det_sat_tol",  50))
        self._det_min_var    = tk.DoubleVar(value=s.get("det_min_area", 80))
        self._det_max_var    = tk.DoubleVar(value=s.get("det_max_area", 40000))

        self._build()

    # ── helpers ──────────────────────────────────────────────────────────

    def _card(self, parent, title):
        """Titled card panel. Returns the inner content frame."""
        _section_header(parent, title, bg=C["stone_darkest"])
        outer = tk.Frame(parent, bg=C["stone_mid"],
                         highlightthickness=1,
                         highlightbackground=C["stone_border"])
        outer.pack(fill="x", pady=(0, 10))
        inner = tk.Frame(outer, bg=C["stone_mid"])
        inner.pack(fill="x", padx=10, pady=10)
        return inner

    def _entry(self, parent, width=14):
        return tk.Entry(parent, width=width, font=F_MONO_S,
                        bg=C["stone_dark"], fg=C["text_mono"],
                        insertbackground=C["gold_mid"],
                        relief="flat", bd=3,
                        highlightthickness=1,
                        highlightbackground=C["stone_border"],
                        highlightcolor=C["gold_deep"])

    def _btn(self, parent, text, cmd):
        return tk.Button(parent, text=text,
                         font=F_CINZEL_S, fg=C["gold_mid"],
                         bg=C["stone_dark"], relief="flat", bd=0,
                         activebackground=C["stone_mid"],
                         activeforeground=C["gold_bright"],
                         cursor="hand2", padx=8, pady=3,
                         highlightthickness=1,
                         highlightbackground=C["stone_border"],
                         command=cmd)

    def _slider(self, parent, var, from_, to, res, length, cmd=None):
        return HSlider(parent, variable=var, from_=from_, to=to,
                       resolution=res, length=length, command=cmd,
                       bg=C["stone_mid"])

    @staticmethod
    def _dot_canvas(parent):
        c = tk.Canvas(parent, width=8, height=8,
                      bg=C["stone_mid"], highlightthickness=0)
        item = c.create_oval(1, 1, 7, 7, fill=C["text_dim"], outline="")
        return c, item

    @staticmethod
    def _set_dot(canvas, item_id, colour):
        canvas.itemconfig(item_id, fill=colour)

    def _val_lbl(self, parent, text, width=5):
        return tk.Label(parent, text=text, font=F_MONO_S,
                        fg=C["gold_pale"], bg=C["stone_mid"], width=width)

    # ── layout ───────────────────────────────────────────────────────────

    def _build(self):
        bg  = C["stone_darkest"]
        GAP = 8

        grid = tk.Frame(self, bg=bg)
        grid.pack(expand=True, pady=(14, 14), padx=(67, 67))
        grid.columnconfigure(0, weight=1)
        grid.columnconfigure(1, weight=1)
        grid.columnconfigure(2, weight=1)
        grid.rowconfigure(0, weight=1)

        cols = []
        for i in range(3):
            f = tk.Frame(grid, bg=bg)
            f.grid(row=0, column=i, sticky="nsew",
                   padx=(0 if i == 0 else GAP//2, GAP//2 if i < 2 else 0))
            cols.append(f)

        # Column 0 — integrations + logging
        self._build_runelite(cols[0])
        self._build_polling(cols[0])
        self._build_hiscores(cols[0])
        self._build_logging(cols[0])

        # Column 1 — detection + antiban
        self._build_tesseract(cols[1])
        self._build_detection_tuning(cols[1])
        self._build_antiban(cols[1])

        # Column 2 — appearance + about
        self._build_appearance(cols[2])
        self._build_about(cols[2])

    # ── col 0 ─────────────────────────────────────────────────────────────

    def _build_runelite(self, parent):
        inn = self._card(parent, "RuneLite HTTP Server")
        _label(inn, "Exposes live skill data on a local port.",
               font=F_FELL_S, fg=C["text_dim"]).pack(anchor="w", pady=(0, 8))

        row = tk.Frame(inn, bg=C["stone_mid"])
        row.pack(fill="x", pady=(0, 6))
        _label(row, "Host", font=F_CINZEL_S).pack(side="left")
        self._rl_host = self._entry(row, width=12)
        self._rl_host.insert(0, self._store.get("rl_host", "http://localhost"))
        self._rl_host.pack(side="left", padx=(4, 8))
        _label(row, "Port", font=F_CINZEL_S).pack(side="left")
        self._rl_port = self._entry(row, width=5)
        self._rl_port.insert(0, str(self._store.get("rl_port", 8080)))
        self._rl_port.pack(side="left", padx=(4, 0))

        sr = tk.Frame(inn, bg=C["stone_mid"])
        sr.pack(fill="x")
        self._rl_dot, self._rl_dot_id = self._dot_canvas(sr)
        self._rl_dot.pack(side="left", padx=(0, 4))
        tk.Label(sr, textvariable=self._rl_status_var,
                 font=F_MONO_S, fg=C["text_dim"],
                 bg=C["stone_mid"]).pack(side="left")
        self._btn(sr, "Apply & Connect",
                  self._test_runelite).pack(side="right")

    def _build_polling(self, parent):
        inn = self._card(parent, "Polling Intervals")

        def _row(label, var, from_, to, unit, cmd):
            r = tk.Frame(inn, bg=C["stone_mid"])
            r.pack(fill="x", pady=(0, 6))
            _label(r, label, font=F_CINZEL_S, fg=C["text_sec"]).pack(side="left")
            vl = self._val_lbl(r, f"{var.get():.1f}{unit}")
            vl.pack(side="right")
            self._btn(r, "Apply", cmd).pack(side="right", padx=(0, 4))
            def _mv(v, l=vl, u=unit): l.config(text=f"{float(v):.1f}{u}")
            self._slider(inn, var, from_, to, 0.5, 140, _mv).pack(
                anchor="w", pady=(0, 4))

        _row("RuneLite stats",    self._rl_poll_var,  0.5, 10.0, "s", self._apply_rl_poll)
        _row("Location detector", self._loc_poll_var, 0.5,  5.0, "s", self._apply_loc_poll)

    def _build_hiscores(self, parent):
        inn = self._card(parent, "Hiscores  ·  Username")
        _label(inn, "RSN used to fetch skill levels from the OSRS hiscores API.",
               font=F_FELL_S, fg=C["text_dim"]).pack(anchor="w", pady=(0, 8))

        row = tk.Frame(inn, bg=C["stone_mid"])
        row.pack(fill="x", pady=(0, 4))
        _label(row, "RSN", font=F_CINZEL_S).pack(side="left")
        self._username_entry = self._entry(row, width=14)
        try:
            import json, os as _os
            _hf = _os.path.join(_os.path.dirname(_os.path.dirname(
                _os.path.abspath(__file__))), "data", "hiscores.json")
            pre = self._store.get("username", "")
            if _os.path.isfile(_hf):
                with open(_hf) as _f:
                    pre = json.load(_f).get("username", pre)
            if pre:
                self._username_entry.insert(0, pre)
        except Exception:
            pass
        self._username_entry.pack(side="left", padx=(4, 6))
        self._btn(inn, "Save & Refresh",
                  self._apply_username).pack(anchor="w", pady=(4, 0))
        tk.Label(inn, textvariable=self._rsn_status_var,
                 font=F_MONO_S, fg=C["text_dim"],
                 bg=C["stone_mid"]).pack(anchor="w", pady=(4, 0))

    # ── col 1 ─────────────────────────────────────────────────────────────

    def _build_tesseract(self, parent):
        inn = self._card(parent, "Location Detector  ·  Tesseract OCR")
        _label(inn, "Reads tile coords from the RuneLite World Location plugin.",
               font=F_FELL_S, fg=C["text_dim"]).pack(anchor="w", pady=(0, 8))

        pr = tk.Frame(inn, bg=C["stone_mid"])
        pr.pack(fill="x", pady=(0, 6))
        _label(pr, "Binary", font=F_CINZEL_S).pack(side="left")
        self._tess_path = self._entry(pr, width=16)
        saved = self._store.get("tesseract_path", "")
        default = saved or r"C:\Program Files\Tesseract-OCR\tesseract.exe"
        try:
            import sys as _sys, os as _os
            if not saved and _sys.platform == "win32":
                for p in [r"C:\Program Files\Tesseract-OCR\tesseract.exe",
                          r"C:\Program Files (x86)\Tesseract-OCR\tesseract.exe"]:
                    if _os.path.isfile(p):
                        default = p; break
        except Exception:
            pass
        self._tess_path.insert(0, default)
        self._tess_path.pack(side="left", padx=(4, 4), fill="x", expand=True)
        self._btn(pr, "Browse…", self._browse_tesseract).pack(side="left")

        sr = tk.Frame(inn, bg=C["stone_mid"])
        sr.pack(fill="x")
        self._tess_dot, self._tess_dot_id = self._dot_canvas(sr)
        self._tess_dot.pack(side="left", padx=(0, 4))
        tk.Label(sr, textvariable=self._tess_status_var,
                 font=F_MONO_S, fg=C["text_dim"],
                 bg=C["stone_mid"]).pack(side="left")
        self._btn(sr, "Apply & Test",
                  self._test_tesseract).pack(side="right")

    def _build_detection_tuning(self, parent):
        inn = self._card(parent, "Highlight Detector Tuning")
        _label(inn, "Adjust how the colour detector matches RuneLite highlights.",
               font=F_FELL_S, fg=C["text_dim"]).pack(anchor="w", pady=(0, 8))

        params = [
            ("Hue Tolerance",  self._det_hue_var, 0,    30,    1,    "det_hue_tol"),
            ("Sat Tolerance",  self._det_sat_var, 0,    80,    5,    "det_sat_tol"),
            ("Min Area (px²)", self._det_min_var, 20,   500,   10,   "det_min_area"),
            ("Max Area (px²)", self._det_max_var, 1000, 80000, 1000, "det_max_area"),
        ]
        for label, var, lo, hi, res, store_key in params:
            r = tk.Frame(inn, bg=C["stone_mid"])
            r.pack(fill="x", pady=(0, 6))
            _label(r, label, font=F_CINZEL_S).pack(side="left")
            lbl = tk.Label(r, text=str(int(var.get())),
                           font=F_MONO_S, fg=C["gold_pale"],
                           bg=C["stone_mid"], width=7, anchor="e")
            lbl.pack(side="right")
            def _cmd(v, l=lbl, sk=store_key):
                iv = int(float(v))
                l.config(text=str(iv))
                self._store.set(sk, iv)
                self._push_det_tuning()
            self._slider(inn, var, lo, hi, res, 180, _cmd).pack(
                fill="x", pady=(0, 2))

    def _push_det_tuning(self):
        """Push current tuning values live to highlight_detector constants."""
        try:
            import core.highlight_detector as hd
            hd.HUE_TOLERANCE = int(self._det_hue_var.get())
            hd.SAT_TOLERANCE = int(self._det_sat_var.get())
            hd.MIN_AREA      = int(self._det_min_var.get())
            hd.MAX_AREA      = int(self._det_max_var.get())
        except Exception:
            pass

    def _build_antiban(self, parent):
        inn = self._card(parent, "Antiban Intensity")
        _label(inn, "Controls how aggressively human-like behaviour is simulated.",
               font=F_FELL_S, fg=C["text_dim"]).pack(anchor="w", pady=(0, 6))

        lbl_row = tk.Frame(inn, bg=C["stone_mid"])
        lbl_row.pack(fill="x")
        for t in ("Off", "Light", "Normal", "Paranoid"):
            tk.Label(lbl_row, text=t, font=F_CINZEL_T,
                     fg=C["text_dim"], bg=C["stone_mid"]).pack(
                side="left", expand=True)

        self._ab_val_lbl = tk.Label(inn, text="Normal  (1.0×)",
                                    font=F_MONO_S, fg=C["gold_pale"],
                                    bg=C["stone_mid"])
        self._ab_val_lbl.pack(anchor="e", pady=(2, 2))
        self._slider(inn, self._antiban_intensity, 0.0, 2.0, 0.1, 200,
                     self._on_antiban_move).pack(fill="x", pady=(0, 8))

        grid = tk.Frame(inn, bg=C["stone_mid"])
        grid.pack(fill="x")
        grid.columnconfigure(0, weight=1)
        grid.columnconfigure(1, weight=1)
        self._ab_cells = {}
        for i, (lbl, default) in enumerate([
            ("Reaction delay", "150–350 ms"),
            ("Idle chance",    "1.5% / action"),
            ("Camera nudge",   "6% / action"),
            ("Short pause",    "50–180 ms"),
        ]):
            r, c = divmod(i, 2)
            cell = tk.Frame(grid, bg=C["stone_dark"],
                            highlightthickness=1,
                            highlightbackground=C["stone_border"])
            cell.grid(row=r, column=c, sticky="ew", padx=3, pady=3)
            tk.Label(cell, text=lbl, font=F_CINZEL_T,
                     fg=C["text_dim"], bg=C["stone_dark"]).pack(
                anchor="w", padx=5, pady=(3, 0))
            v = tk.StringVar(value=default)
            self._ab_cells[lbl] = v
            tk.Label(cell, textvariable=v, font=F_MONO_S,
                     fg=C["gold_pale"], bg=C["stone_dark"]).pack(
                anchor="w", padx=5, pady=(0, 3))

        tk.Frame(inn, bg=C["stone_border"], height=1).pack(
            fill="x", pady=(10, 6))
        _label(inn, "Activity", font=F_CINZEL_S,
               fg=C["text_dim"]).pack(anchor="w", pady=(0, 4))
        lf = tk.Frame(inn, bg=C["stone_dark"], highlightthickness=1,
                      highlightbackground=C["stone_border"])
        lf.pack(fill="both", expand=True)
        self._ab_log = tk.Text(lf, height=5, bg=C["stone_dark"],
                               fg=C["text_dim"], font=F_MONO_S,
                               relief="flat", bd=0, state="disabled",
                               wrap="word", highlightthickness=0)
        self._ab_log.pack(fill="both", expand=True, padx=5, pady=5)
        self._ab_log.tag_config("event", foreground=C["gold_pale"])
        self._ab_log.tag_config("dim",   foreground=C["text_dim"])
        self._ab_log_lines = 0
        self._ab_append("Antiban monitor ready.", "dim")

    # ── col 2 ─────────────────────────────────────────────────────────────

    def _build_appearance(self, parent):
        inn = self._card(parent, "Appearance")

        _label(inn, "Window opacity", font=F_CINZEL_S).pack(anchor="w", pady=(0, 3))
        op_row = tk.Frame(inn, bg=C["stone_mid"])
        op_row.pack(fill="x", pady=(0, 8))
        self._op_val_lbl = self._val_lbl(op_row, "100%")
        self._op_val_lbl.pack(side="right")
        self._slider(op_row, self._opacity_var, 0.3, 1.0, 0.05, 160,
                     self._on_opacity_move).pack(side="left", fill="x", expand=True)

        _label(inn, "Font scale", font=F_CINZEL_S).pack(anchor="w", pady=(0, 3))
        fs_row = tk.Frame(inn, bg=C["stone_mid"])
        fs_row.pack(fill="x", pady=(0, 4))
        self._fs_val_lbl = self._val_lbl(fs_row, "1.0×")
        self._fs_val_lbl.pack(side="right")
        self._slider(fs_row, self._font_scale_var, 0.8, 1.4, 0.1, 160,
                     self._on_font_scale_move).pack(side="left", fill="x", expand=True)

        tk.Label(inn, text="Restart required to apply font changes.",
                 font=F_CINZEL_T, fg=C["text_dim"],
                 bg=C["stone_mid"]).pack(anchor="w", pady=(4, 0))

    def _build_logging(self, parent):
        inn = self._card(parent, "Logging")

        row = tk.Frame(inn, bg=C["stone_mid"])
        row.pack(fill="x", pady=(0, 6))
        _label(row, "Log level", font=F_CINZEL_S).pack(side="left")
        for lvl in ("DEBUG", "INFO", "WARNING", "ERROR"):
            tk.Radiobutton(row, text=lvl, variable=self._log_level,
                           value=lvl, font=F_MONO_S,
                           fg=C["text_sec"], selectcolor=C["stone_dark"],
                           bg=C["stone_mid"], activebackground=C["stone_mid"],
                           activeforeground=C["gold_bright"], cursor="hand2",
                           command=self._apply_log_level).pack(
                side="left", padx=(6, 0))

        import os as _os
        _default_log = _os.path.join(
            _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))),
            "logs", "session.log")
        self._log_path_var = tk.StringVar(value=_default_log)
        pr = tk.Frame(inn, bg=C["stone_mid"])
        pr.pack(fill="x")
        _label(pr, "Log file", font=F_CINZEL_S).pack(side="left")
        tk.Label(pr, textvariable=self._log_path_var,
                 font=F_MONO_S, fg=C["text_dim"],
                 bg=C["stone_mid"]).pack(side="left", padx=(6, 0))

    def _build_about(self, parent):
        inn = self._card(parent, "About")

        for text, font, fg in [
            ("RuneScript",             F_LOGO,   C["gold_shine"]),
            ("Automation Suite  v2.0", F_CINZEL, C["gold_mid"]),
        ]:
            tk.Label(inn, text=text, font=font, fg=fg,
                     bg=C["stone_mid"]).pack(anchor="w")

        tk.Frame(inn, bg=C["stone_border"], height=1).pack(
            fill="x", pady=(8, 6))

        for text in ("Screen-read only.",
                     "No memory injection.",
                     "No packet manipulation."):
            _label(inn, text, font=F_FELL_S, fg=C["text_sec"]).pack(anchor="w")

        tk.Frame(inn, bg=C["stone_border"], height=1).pack(
            fill="x", pady=(8, 6))

        import sys as _sys, platform as _pl
        _py = (f"Python {_sys.version_info.major}."
               f"{_sys.version_info.minor}."
               f"{_sys.version_info.micro}")
        for text in (f"{_py}  ·  {_pl.system()}",
                     "tkinter  ·  OpenCV  ·  mss",
                     "pytesseract  ·  Pillow"):
            _label(inn, text, font=F_MONO_S, fg=C["text_dim"]).pack(anchor="w")

        tk.Frame(inn, bg=C["stone_border"], height=1).pack(
            fill="x", pady=(8, 6))

        _section_header(inn, "System Status", bg=C["stone_mid"])
        self._sys_status_frame = tk.Frame(inn, bg=C["stone_mid"])
        self._sys_status_frame.pack(fill="x")
        for label in ("RuneLite HTTP", "Tesseract OCR", f"Python {_sys.version_info.major}.{_sys.version_info.minor}.{_sys.version_info.micro}"):
            row = tk.Frame(self._sys_status_frame, bg=C["stone_mid"])
            row.pack(fill="x", pady=1)
            dot = tk.Canvas(row, width=8, height=8,
                            bg=C["stone_mid"], highlightthickness=0)
            dot.create_oval(1, 1, 7, 7, fill=C["status_run"], outline="")
            dot.pack(side="left", padx=(0, 6))
            _label(row, label, font=F_CINZEL_S,
                   fg=C["text_sec"]).pack(side="left")

    # ── callbacks ─────────────────────────────────────────────────────────

    def _test_runelite(self):
        self._rl_status_var.set("Testing…")
        self._set_dot(self._rl_dot, self._rl_dot_id, C["gold_pale"])
        host = self._rl_host.get().strip().rstrip("/")
        try:
            port = int(self._rl_port.get().strip())
        except ValueError:
            self._rl_status_var.set("Invalid port")
            self._set_dot(self._rl_dot, self._rl_dot_id, C["status_err"])
            return
        def _run():
            try:
                from urllib.request import urlopen
                with urlopen(f"{host}:{port}/stats", timeout=3) as r:
                    r.read()
                self.after(0, lambda: self._rl_ok(host, port))
            except Exception as e:
                self.after(0, lambda m=str(e): self._rl_fail(m))
        import threading
        threading.Thread(target=_run, daemon=True).start()

    def _rl_ok(self, host, port):
        self._rl_status_var.set(f"Connected — {host}:{port}")
        self._set_dot(self._rl_dot, self._rl_dot_id, C["status_run"])
        self._store.set("rl_host", host)
        self._store.set("rl_port", port)
        try:
            rl = getattr(self._bridge, "runelite_tracker", None)
            if rl:
                rl.stop()
                rl.base_url = f"{host}:{port}"
                rl.start()
        except Exception:
            pass

    def _rl_fail(self, msg):
        self._rl_status_var.set(f"Failed — {msg[:40]}")
        self._set_dot(self._rl_dot, self._rl_dot_id, C["status_err"])

    def _apply_rl_poll(self):
        v = self._rl_poll_var.get()
        self._store.set("rl_poll_interval", v)
        try:
            import core.runelite_tracker as _rlt
            _rlt.STATS_POLL_INTERVAL = v
        except Exception:
            pass

    def _apply_loc_poll(self):
        interval = self._loc_poll_var.get()
        self._store.set("loc_poll_interval", interval)
        if self._root:
            self._walk_set_attr(self._root, "_loc_detector", "interval", interval)

    def _walk_set_attr(self, widget, obj_attr, field, value):
        obj = getattr(widget, obj_attr, None)
        if obj is not None:
            try: setattr(obj, field, value)
            except Exception: pass
        for child in widget.winfo_children():
            self._walk_set_attr(child, obj_attr, field, value)

    def _apply_username(self):
        name = self._username_entry.get().strip()
        if not name:
            self._rsn_status_var.set("Enter a username first.")
            return
        self._rsn_status_var.set("Saving…")
        try:
            ht = getattr(self._bridge, "hiscores_tracker", None)
            if ht:
                ht.username = name
                ht.force_poll()
                self._rsn_status_var.set(f"Fetching for {name}…")
            else:
                self._rsn_status_var.set(f"Saved — {name}")
            import json, os as _os
            _hf = _os.path.join(_os.path.dirname(_os.path.dirname(
                _os.path.abspath(__file__))), "data", "hiscores.json")
            try:
                with open(_hf) as _f: data = json.load(_f)
            except Exception: data = {}
            data["username"] = name
            _os.makedirs(_os.path.dirname(_hf), exist_ok=True)
            with open(_hf, "w") as _f: json.dump(data, _f, indent=2)
            self._store.set("username", name)
        except Exception as e:
            self._rsn_status_var.set(f"Error: {e}")

    def _browse_tesseract(self):
        try:
            from tkinter import filedialog
            path = filedialog.askopenfilename(
                title="Select Tesseract binary",
                filetypes=[("Executable", "*.exe"), ("All files", "*.*")],
                initialdir=r"C:\Program Files")
            if path:
                self._tess_path.delete(0, "end")
                self._tess_path.insert(0, path)
        except Exception:
            pass

    def _test_tesseract(self):
        self._tess_status_var.set("Testing…")
        self._set_dot(self._tess_dot, self._tess_dot_id, C["gold_pale"])
        path = self._tess_path.get().strip()
        def _run():
            try:
                import pytesseract
                pytesseract.pytesseract.tesseract_cmd = path
                ver = pytesseract.get_tesseract_version()
                self.after(0, lambda v=str(ver): self._tess_ok(v))
            except Exception as e:
                self.after(0, lambda m=str(e): self._tess_fail(m))
        import threading
        threading.Thread(target=_run, daemon=True).start()

    def _tess_ok(self, ver):
        self._tess_status_var.set(f"OK — Tesseract {ver}")
        self._set_dot(self._tess_dot, self._tess_dot_id, C["status_run"])
        self._store.set("tesseract_path", self._tess_path.get().strip())
        try:
            from core.detection import location_detector as _ld
            import pytesseract as _pt
            _pt.pytesseract.tesseract_cmd = self._tess_path.get().strip()
            _ld._tess_ok = None
        except Exception:
            pass

    def _tess_fail(self, msg):
        self._tess_status_var.set(f"Failed — {msg[:40]}")
        self._set_dot(self._tess_dot, self._tess_dot_id, C["status_err"])

    def _on_antiban_move(self, val):
        x = float(val)
        if x == 0:         label = "Off  (0×)"
        elif x <= 0.5:     label = f"Light  ({x:.1f}×)"
        elif x <= 1.2:     label = f"Normal  ({x:.1f}×)"
        else:              label = f"Paranoid  ({x:.1f}×)"
        self._ab_val_lbl.config(text=label)
        if x == 0:
            for v in self._ab_cells.values(): v.set("disabled")
        else:
            self._ab_cells["Reaction delay"].set(f"{int(150*x)}–{int(350*x)} ms")
            self._ab_cells["Idle chance"].set(f"{x*1.5:.1f}% / action")
            self._ab_cells["Camera nudge"].set(f"{x*6:.0f}% / action")
            self._ab_cells["Short pause"].set(f"{int(50*x)}–{int(180*x)} ms")
        self._store.set("antiban_intensity", x)
        self._ab_append(f"Intensity → {label}")
        try:
            script = getattr(self._bridge, "_script", None)
            if script:
                ab = getattr(script, "antiban", None)
                if ab:
                    ab.enabled   = x > 0
                    ab.intensity = x
        except Exception:
            pass

    def _ab_append(self, msg, tag="event"):
        try:
            import time as _t
            ts = _t.strftime("%H:%M:%S")
            self._ab_log.config(state="normal")
            if self._ab_log_lines >= 50:
                self._ab_log.delete("1.0", "2.0")
            else:
                self._ab_log_lines += 1
            self._ab_log.insert("end", f"{ts}  {msg}\n", tag)
            self._ab_log.see("end")
            self._ab_log.config(state="disabled")
        except Exception:
            pass

    def _on_opacity_move(self, val):
        v = float(val)
        self._op_val_lbl.config(text=f"{int(v*100)}%")
        self._store.set("opacity", v)
        try:
            if self._root:
                self._root.attributes("-alpha", v)
        except Exception:
            pass

    def _on_font_scale_move(self, val):
        v = float(val)
        self._fs_val_lbl.config(text=f"{v:.1f}×")
        self._store.set("font_scale", v)
        try:
            import builtins
            builtins._RUNESCRIPT_FONT_SCALE = v
        except Exception:
            pass

    def _apply_log_level(self):
        import logging
        level = getattr(logging, self._log_level.get(), logging.INFO)
        logging.getLogger().setLevel(level)
        self._store.set("log_level", self._log_level.get())


class RuneScriptIcon(tk.Canvas):
    """
    RS logo: sword IS the left spine of the R (pommel above, diamond tip below).
    R bowl and leg drawn as vector strokes. S drawn as two arcs.
    No text glyphs — everything is lines/polygons.
    """
    W, H = 64, 56

    def __init__(self, parent, **kw):
        kw.setdefault("bg", C["stone_darkest"])
        super().__init__(parent, width=self.W, height=self.H,
                         highlightthickness=0, **kw)
        self._draw()

    def _draw(self):
        self.delete("all")
        gold   = C["gold_bright"]
        shine  = C["gold_shine"]
        mid    = C["gold_mid"]
        shadow = C["gold_deep"]

        # ── Geometry ─────────────────────────────────────────────────
        # Sword/spine x centre
        sp = 10

        # R vertical extents
        r_top = 14
        r_bot = 50

        # R bowl
        bowl_r  = 10          # half-height of bowl
        bowl_cx = sp + 11     # x centre of bowl arc
        bowl_top = r_top
        bowl_mid = r_top + bowl_r * 2   # y of mid-bar

        # R leg diagonal end point
        leg_ex = sp + 22
        leg_ey = r_bot

        # ── SWORD (drawn first so R strokes sit on top at join) ──────
        blade_top  = r_top        # blade starts at crossguard = R top
        blade_bot  = 54
        taper_y    = blade_bot - 8
        bw         = 3

        # Blade polygon
        self.create_polygon(
            sp - bw, blade_top,
            sp + bw, blade_top,
            sp + bw, taper_y,
            sp,      blade_bot,
            sp - bw, taper_y,
            fill=gold, outline=shadow, width=1
        )
        # Centre highlight
        self.create_line(sp, blade_top, sp, taper_y, fill=shine, width=1)

        # Crossguard at r_top — extends left of spine and right to bowl edge
        cg_y  = r_top - 1
        cg_l  = sp - 7
        cg_r  = sp + 22
        self.create_line(cg_l, cg_y, cg_r, cg_y,
                         fill=gold, width=3, capstyle="round")
        for ex in (cg_l, cg_r):
            self.create_oval(ex - 2, cg_y - 2, ex + 2, cg_y + 2,
                             fill=shadow, outline=mid, width=1)

        # Grip
        self.create_line(sp, cg_y, sp, 4, fill="#3d2810", width=4)
        for gy in range(5, cg_y, 3):
            self.create_line(sp - 2, gy, sp + 2, gy, fill="#6a4820", width=1)

        # Pommel
        self.create_oval(sp - 5, 0, sp + 5, 10,
                         fill=gold, outline=shine, width=1)
        self.create_oval(sp - 2, 1, sp + 2, 5, fill=shine, outline="")

        # ── R (drawn over sword so they share the left spine) ────────
        sw = 4   # stroke width

        # Top cap
        self.create_line(sp, r_top, sp + 20, r_top,
                         fill=gold, width=sw, capstyle="butt")

        # Bowl right arc — approximated as smooth polyline
        self.create_line(
            sp + 20, r_top + 2,
            sp + 22, r_top + bowl_r,
            sp + 20, bowl_mid,
            fill=gold, width=sw, capstyle="butt", smooth=True
        )

        # Mid bar
        self.create_line(sp, bowl_mid, sp + 20, bowl_mid,
                         fill=gold, width=sw, capstyle="butt")

        # Diagonal leg (from mid-bar down-right)
        self.create_line(
            sp + 18, bowl_mid + 2,
            leg_ex,  leg_ey,
            fill=gold, width=sw, capstyle="round"
        )

        # Left spine highlight (sword inner edge reads as part of R)
        self.create_line(sp + bw, r_top, sp + bw, r_bot,
                         fill=mid, width=1)

        # ── S (two arcs, right side) ──────────────────────────────────
        sl = 36   # S left bound
        sr = 61   # S right bound
        st = 12   # S top
        sb = 50   # S bottom
        sm = (st + sb) // 2

        # Upper arc (opens downward-left)
        self.create_arc(sl, st, sr, sm + 5,
                        start=0, extent=210,
                        outline=gold, width=sw, style="arc")
        # Lower arc (opens upward-right)
        self.create_arc(sl, sm - 5, sr, sb,
                        start=180, extent=210,
                        outline=gold, width=sw, style="arc")


# ═══════════════════════════════════════════════════════════════════════════
#  MAIN APPLICATION
# ═══════════════════════════════════════════════════════════════════════════

class RuneScriptApp:
    W, H = 1260, 820

    STAT_DEFS = [
        ("Runtime",       "",     "↑ running"),
        ("Logs / hr",     "/hr",  "↑ +12 last 10m"),
        ("XP / hr",       "",     "↑ steady"),
        ("Trees Chopped", "",     ""),
        ("XP Drops",      "",     "100% success"),
        ("Detections",    "%",    "↑ 12,847 total"),
        ("Hovers",        "avg",  "per tree"),
        ("GP / hr",       "",     ""),
    ]

    def __init__(self, bridge=None, bridge_factory=None):
        self.root = tk.Tk()
        _resolve_fonts(self.root)
        self.root.title("RuneScript - Automation Suite")
        self.root.geometry(f"{self.W}x{self.H}+60+40")
        self.root.minsize(1000, 680)
        self.root.configure(bg=C["stone_darkest"])
        self.root.overrideredirect(True)

        # Drag state for custom titlebar
        self._drag_x = 0
        self._drag_y = 0
        self._maximised = False
        self._restore_geom = f"{self.W}x{self.H}+60+40"

        self._stat_cells:   Dict[str, StatCell]  = {}
        self._log_console:  Optional[LogConsole]  = None
        self._control_card: Optional[ControlCard] = None
        self._right_panel:  Optional[RightPanel]  = None
        self._status_var    = tk.StringVar(value="00:00:00")
        self._current_page: Optional[tk.Frame] = None
        self._pages: Dict[str, tk.Frame] = {}
        self._wall_clock_var = tk.StringVar(value="")

        if bridge:
            self._bridge = bridge
        elif bridge_factory:
            self._bridge = bridge_factory(
                log_cb    = self._on_log,
                stats_cb  = self._on_stats,
                status_cb = self._on_status,
            )
        else:
            self._bridge = MockBridge(
                log_cb    = self._on_log,
                stats_cb  = self._on_stats,
                status_cb = self._on_status,
            )
        self._build()
        self._tick_wall_clock()

        try:
            icon_path = os.path.join(os.path.dirname(__file__), "icon.ico")
            if os.path.exists(icon_path):
                self.root.iconbitmap(default=icon_path)
        except Exception:
            pass

        self.root.bind("<<ToggleMaximize>>", lambda e: self._toggle_maximize())

    def _build(self):
        self._build_titlebar()
        self._build_header()
        self._build_body()
        self._build_footer()

    def _build_titlebar(self):
        """
        Custom OS-free titlebar: drag strip with minimize / maximize / close.
        Sits above the app header and replaces the Windows frame entirely.
        """
        tb = tk.Frame(self.root, bg=C["stone_darkest"], height=28)
        tb.pack(fill="x")
        tb.pack_propagate(False)

        # Thin gold separator at bottom of titlebar
        tk.Frame(tb, bg=C["gold_deep"], height=1).pack(side="bottom", fill="x")

        # ── Window title centred ─────────────────────────────────────
        tk.Label(tb, text="R U N E S C R I P T  —  A U T O M A T I O N  S U I T E",
                 font=(_CINZEL, 7, "bold"), fg=C["text_dim"],
                 bg=C["stone_darkest"]).place(relx=0.5, rely=0.5, anchor="center")

        # ── Window controls (right side) ─────────────────────────────
        ctrl = tk.Frame(tb, bg=C["stone_darkest"])
        ctrl.pack(side="right")

        def _wbtn(parent, symbol, hover_fg, command):
            b = tk.Label(parent, text=symbol,
                         font=(_MONO_ALT, 10),
                         fg=C["text_dim"],
                         bg=C["stone_darkest"],
                         width=3, cursor="hand2")
            b.pack(side="left")
            b.bind("<Enter>",  lambda e: b.config(fg=hover_fg, bg=C["stone_light"]))
            b.bind("<Leave>",  lambda e: b.config(fg=C["text_dim"], bg=C["stone_darkest"]))
            b.bind("<ButtonPress-1>", lambda e: command())
            return b

        _wbtn(ctrl, "—", C["gold_bright"],  self._minimize)
        _wbtn(ctrl, "□", C["gold_bright"],  self._toggle_maximize)
        _wbtn(ctrl, "✕", C["status_stop"],  self.root.destroy)

        tb.bind("<Double-Button-1>", lambda e: self._toggle_maximize())

        # ── Drag ──────────────────────────────────────────────────────────
        def _start_drag(e):
            if self._maximised:
                return
            self._drag_x = e.x_root - self.root.winfo_x()
            self._drag_y = e.y_root - self.root.winfo_y()

        def _do_drag(e):
            if self._maximised:
                return
            self.root.geometry(f"+{e.x_root - self._drag_x}+{e.y_root - self._drag_y}")

        tb.bind("<ButtonPress-1>", _start_drag)
        tb.bind("<B1-Motion>",     _do_drag)

        # Also bind to child widgets so clicks on the label/gaps all trigger drag
        for child in tb.winfo_children():
            if child not in (ctrl,):  # skip the control buttons frame
                child.bind("<ButtonPress-1>", _start_drag)
                child.bind("<B1-Motion>",     _do_drag)

        # Resize grip — bottom-right corner (HTBOTTOMRIGHT via wndproc handles
        # native resize; this grip is a visual hint only)
        grip = tk.Label(self.root, text="⠿", font=(_MONO_ALT, 8),
                        fg=C["stone_border"], bg=C["stone_darkest"],
                        cursor="size_nw_se")
        grip.place(relx=1.0, rely=1.0, anchor="se", x=-2, y=-2)

        def _start_resize(e):
            self._res_x = e.x_root
            self._res_y = e.y_root
            self._res_w = self.root.winfo_width()
            self._res_h = self.root.winfo_height()

        def _do_resize(e):
            nw = max(1000, self._res_w + e.x_root - self._res_x)
            nh = max(680,  self._res_h + e.y_root - self._res_y)
            self.root.geometry(f"{nw}x{nh}")

        grip.bind("<ButtonPress-1>", _start_resize)
        grip.bind("<B1-Motion>",     _do_resize)

    def _minimize(self):
        self.root.iconify()

    def _toggle_maximize(self):
        if self._maximised:
            self.root.withdraw()
            self.root.geometry(self._restore_geom)
            self.root.update_idletasks()
            self.root.deiconify()
            self._maximised = False
        else:
            self._restore_geom = self.root.geometry()
            mx, my, mw, mh = self._get_monitor_rect(self.root.winfo_x(), self.root.winfo_y())
            self.root.withdraw()
            self.root.geometry(f"{mw}x{mh}+{mx}+{my}")
            self.root.update_idletasks()
            self.root.deiconify()
            self._maximised = True
        self.root.after(50, self._force_repaint)
        self.root.after(150, self._force_repaint)

    def _force_repaint(self):
        self.root.update_idletasks()

    def _get_monitor_rect(self, wx: int, wy: int):
        """Return (x, y, w, h) of the monitor containing point (wx, wy)."""
        try:
            import ctypes
            # MONITOR_DEFAULTTONEAREST = 2
            pt = ctypes.wintypes.POINT(wx, wy)
            hmon = ctypes.windll.user32.MonitorFromPoint(pt, 2)
            info = ctypes.create_string_buffer(40)
            ctypes.c_uint32.from_buffer(info, 0).value = 40  # cbSize
            ctypes.windll.user32.GetMonitorInfoW(hmon, info)
            # MONITORINFO layout: cbSize(4), rcMonitor(16), rcWork(16), dwFlags(4)
            import struct
            _, ml, mt, mr, mb, wl, wt, wr, wb, _ = struct.unpack_from("=IiiiiiiiII", info)
            # Use work area (excludes taskbar)
            return wl, wt, wr - wl, wb - wt
        except Exception:
            # Fallback to primary screen
            return 0, 0, self.root.winfo_screenwidth(), self.root.winfo_screenheight()

    def _build_header(self):
        hdr = tk.Frame(self.root, bg=C["stone_darkest"], height=64)
        hdr.pack(fill="x")
        hdr.pack_propagate(False)
        tk.Frame(hdr, bg=C["gold_deep"], height=2).pack(side="bottom", fill="x")

        # Logo
        logo = tk.Frame(hdr, bg=C["stone_darkest"])
        logo.pack(side="left", padx=20, pady=8)
        _logo_shown = False
        try:
            import os as _os
            from PIL import Image as _I, ImageTk as _ITk
            _here = _os.path.dirname(_os.path.abspath(__file__))
            for _p in (_os.path.join(_here, "logo.png"),
                       _os.path.join(_here, "GUI_Logo.png")):
                if _os.path.isfile(_p):
                    _im  = _I.open(_p).convert("RGBA").resize((48, 48), _I.LANCZOS)
                    _ph  = _ITk.PhotoImage(_im)
                    _lbl = tk.Label(logo, image=_ph, bg=C["stone_darkest"],
                                    bd=0, highlightthickness=0)
                    _lbl.image = _ph
                    _lbl.pack(side="left", padx=(0, 8))
                    _logo_shown = True
                    break
        except Exception:
            pass
        if not _logo_shown:
            tk.Frame(logo, bg=C["stone_darkest"], width=48).pack(side="left", padx=(0, 8))
        txt = tk.Frame(logo, bg=C["stone_darkest"])
        txt.pack(side="left")
        tk.Label(txt, text="RuneScript", font=F_LOGO,
                 fg=C["gold_shine"], bg=C["stone_darkest"]).pack(anchor="w")
        tk.Label(txt, text="A U T O M A T I O N   S U I T E  ·  v 2 . 0",
                 font=F_LOGO_SUB, fg=C["text_dim"],
                 bg=C["stone_darkest"]).pack(anchor="w")

        # ── Nav buttons — centred ─────────────────────────────────────
        # Use a centred frame that floats in the middle of the header
        nav_outer = tk.Frame(hdr, bg=C["stone_darkest"])
        nav_outer.place(relx=0.5, rely=0.5, anchor="center")

        self._nav_btns = []
        for label in ("Dashboard", "Scripts", "Detection", "Profiles", "Settings"):
            b = tk.Button(nav_outer, text=label,
                          font=F_NAV, fg=C["text_sec"],
                          bg=C["stone_darkest"], relief="flat", bd=0,
                          activebackground=C["stone_dark"],
                          activeforeground=C["gold_bright"],
                          cursor="hand2", padx=14, pady=4,
                          highlightthickness=0,
                          command=lambda l=label: self._nav_click(l))
            b.pack(side="left")
            self._nav_btns.append((label, b))

        # Right: connection badge + wall clock
        right_hdr = tk.Frame(hdr, bg=C["stone_darkest"])
        right_hdr.pack(side="right", padx=20)

        conn = tk.Frame(right_hdr, bg=C["stone_darkest"])
        conn.pack(side="left", padx=(0, 16))
        PulseDot(conn, size=5, color=C["status_run"],
                 bg=C["stone_darkest"]).pack(side="left", padx=(0, 4))
        tk.Label(conn, text="RUNELITE CONNECTED",
                 font=F_CINZEL_T, fg=C["text_sec"],
                 bg=C["stone_darkest"]).pack(side="left")

        # Wall clock (real time) — updates every second
        tk.Label(right_hdr, textvariable=self._wall_clock_var,
                 font=(_MONO_ALT, 12), fg=C["gold_pale"],
                 bg=C["stone_darkest"]).pack(side="left")

    def _nav_click(self, active):
        # Update button styles
        for label, btn in self._nav_btns:
            if label == active:
                btn.config(fg=C["gold_bright"],
                           highlightthickness=1,
                           highlightbackground=C["gold_deep"],
                           relief="solid",
                           bd=0)
            else:
                btn.config(fg=C["text_sec"],
                           highlightthickness=0,
                           relief="flat")

        # Swap page frames (pages dict populated in _build_body)
        pages = getattr(self, "_pages", {})
        if not pages:
            return   # called before _build_body — ignore

        if self._current_page is not None:
            self._current_page.pack_forget()

        page = pages.get(active)
        if page is not None:
            page.pack(fill="both", expand=True)
            self._current_page = page

    def _build_body(self):
        body = tk.Frame(self.root, bg=C["stone_darkest"])
        body.pack(fill="both", expand=True)

        # ── Persistent left sidebar ───────────────────────────────────────
        sidebar = Sidebar(body, on_select=self._on_skill)
        sidebar.pack(side="left", fill="y")
        self._sidebar = sidebar

        # ── Persistent right panel ────────────────────────────────────────
        rl = getattr(self._bridge, "runelite_tracker", None)
        self._right_panel = RightPanel(body, runelite_tracker=rl)
        self._right_panel.pack(side="right", fill="y")

        # ── Page host — shared area between sidebar and right panel ───────
        self._page_host = tk.Frame(body, bg=C["stone_darkest"])
        self._page_host.pack(fill="both", expand=True)

        # ── Dashboard page — scrollable canvas (original layout) ──────────
        dash_canvas = tk.Canvas(self._page_host,
                                 bg=C["stone_darkest"], highlightthickness=0)
        self._dash_inner = tk.Frame(dash_canvas, bg=C["stone_darkest"])
        self._dash_win = dash_canvas.create_window(
            (0, 0), window=self._dash_inner, anchor="nw")
        self._dash_inner.bind("<Configure>", lambda e: dash_canvas.configure(
            scrollregion=dash_canvas.bbox("all")))

        def _on_dash_resize(e):
            dash_canvas.coords(self._dash_win, 400, 0)
            dash_canvas.itemconfig(self._dash_win, width=max(200, e.width - 400))
        dash_canvas.bind("<Configure>", _on_dash_resize)
        self._build_main(self._dash_inner)
        _invisible_scroll(dash_canvas)
        self._pages["Dashboard"] = dash_canvas

        # ── Settings page ─────────────────────────────────────────────────
        set_frame = tk.Frame(self._page_host, bg=C["stone_darkest"])
        set_canvas = tk.Canvas(set_frame, bg=C["stone_darkest"],
                                highlightthickness=0)
        set_canvas.pack(side="top", fill="both", expand=True)
        set_hbar = HScrollbar(set_frame, canvas_target=set_canvas,
                              bg=C["stone_dark"])
        set_hbar.pack(side="bottom", fill="x")
        set_canvas.config(xscrollcommand=set_hbar.set)
        set_inner = tk.Frame(set_canvas, bg=C["stone_darkest"])
        set_win = set_canvas.create_window((0, 0), window=set_inner, anchor="nw")
        set_inner.bind("<Configure>", lambda e: set_canvas.configure(
            scrollregion=set_canvas.bbox("all")))
        def _on_set_resize(e):
            set_canvas.itemconfig(set_win, width=e.width)
        set_canvas.bind("<Configure>", _on_set_resize)
        self._settings_page = SettingsPage(set_inner, bridge=self._bridge, root=self.root)
        self._settings_page.pack(fill="both", expand=True)
        _invisible_scroll(set_canvas)
        self._pages["Settings"] = set_frame

        # ── Stub pages for not-yet-built tabs ─────────────────────────────
        # Scripts stub
        stub = tk.Frame(self._page_host, bg=C["stone_darkest"])
        tk.Label(stub, text="Scripts  —  Coming soon",
                 font=F_CINZEL, fg=C["text_dim"],
                 bg=C["stone_darkest"]).pack(expand=True)
        self._pages["Scripts"] = stub

        # Detection page
        self._detection_page = DetectionPage(
            self._page_host, bridge=self._bridge)
        self._pages["Detection"] = self._detection_page

        # ── Profiles page ─────────────────────────────────────────────────
        self._profiles_page = ProfilesPage(
            self._page_host,
            bridge=self._bridge,
            nav_callback=self._nav_click,
        )
        self._pages["Profiles"] = self._profiles_page

        # Give sidebar a reference to self
        self._sidebar._app_ref = self

        # Show Dashboard — must run AFTER _pages is populated
        self._nav_click("Dashboard")

    def _build_main(self, parent):
        px = 20
        bg = C["stone_darkest"]

        # ── Row 0: Control card — full width ──────────────────────────────
        self._control_card = ControlCard(parent, bridge=self._bridge)
        # Expose to bridge so ProfilesPage can reach it
        if hasattr(self._bridge, '__dict__'):
            self._bridge._control_card = self._control_card
        self._control_card.pack(fill="x", padx=px, pady=(18, 0))

        # ── Row 1: Session Stats (left) + Activity Graph (right) ──────────
        row1 = tk.Frame(parent, bg=bg)
        row1.pack(fill="x", padx=px, pady=(14, 0))
        row1.columnconfigure(0, weight=3)
        row1.columnconfigure(1, weight=2)

        stats_block = tk.Frame(row1, bg=bg)
        stats_block.grid(row=0, column=0, sticky="nsew", padx=(0, 6))
        _section_header(stats_block, "Session Statistics", bg=bg)
        stats_grid = tk.Frame(stats_block, bg=bg)
        stats_grid.pack(fill="x")
        for col in range(4):
            stats_grid.columnconfigure(col, weight=1)
        for i, (label, unit, delta) in enumerate(self.STAT_DEFS):
            r, c = divmod(i, 4)
            cell = StatCell(stats_grid, label=label, unit=unit,
                            delta=delta, value="—")
            cell.grid(row=r, column=c, sticky="nsew", padx=3, pady=3)
            self._stat_cells[label] = cell

        self._activity_graph = ActivityGraph(row1)
        self._activity_graph.grid(row=0, column=1, sticky="nsew", padx=(6, 0), pady=(8, 0))

        # ── Row 2: Alerts (left) + Replay Buffer (right) ──────────────────
        row2 = tk.Frame(parent, bg=bg)
        row2.pack(fill="x", padx=px, pady=(14, 0))
        row2.columnconfigure(0, weight=3)
        row2.columnconfigure(1, weight=2)

        self._alert_panel = AlertPanel(row2)
        self._alert_panel.grid(row=0, column=0, sticky="nsew", padx=(0, 6))

        self._replay_toggle = ReplayBufferToggle(row2)
        self._replay_toggle.grid(row=0, column=1, sticky="nsew", padx=(6, 0))

        # ── Row 3: Script log — full width ────────────────────────────────
        log_block = tk.Frame(parent, bg=bg)
        log_block.pack(fill="x", padx=px, pady=(14, 0))
        _section_header(log_block, "Script Log", bg=bg)
        self._log_console = LogConsole(log_block, height=180)
        self._log_console.pack(fill="x")

        tk.Frame(parent, bg=bg, height=16).pack()


    def _build_footer(self):
        ft = tk.Frame(self.root, bg="#090700", height=34)
        ft.pack(fill="x", side="bottom")
        ft.pack_propagate(False)
        tk.Frame(ft, bg=C["stone_border"], height=1).pack(fill="x", side="top")

        left = tk.Frame(ft, bg="#090700")
        left.pack(side="left", padx=16)
        self._footer_vars: Dict[str, tk.StringVar] = {}
        for label, default in [("CPU","12%"),("MEM","148 MB"),
                                ("FPS","28"),("CAPTURE","mss · 18ms"),
                                ("INPUT","Interception · active")]:
            f = tk.Frame(left, bg="#090700")
            f.pack(side="left", padx=(0, 16))
            tk.Label(f, text=label + " ", font=F_SMALL,
                     fg=C["text_dim"], bg="#090700").pack(side="left")
            v = tk.StringVar(value=default)
            self._footer_vars[label] = v
            tk.Label(f, textvariable=v, font=F_SMALL,
                     fg=C["text_sec"], bg="#090700").pack(side="left")

        tk.Label(ft, text="RuneScript  ·  External  ·  Screen-Read Only",
                 font=F_CINZEL_T, fg=C["text_dim"],
                 bg="#090700").pack(side="right", padx=16)

    # ── Callbacks ──────────────────────────────────────────────────────────

    def _on_skill(self, name: str):
        if self._control_card:
            self._control_card.set_skill(name)

    def _on_log(self, level: str, msg: str):
        if self._log_console:
            self._log_console.append(level, msg)

    def _on_stats(self, stats: dict):
        for label, cell in self._stat_cells.items():
            if label in stats:
                cell.set_value(str(stats[label]))
        # Push full skill snapshot to tracker panel
        if self._right_panel and "skill_snapshot" in stats and stats["skill_snapshot"]:
            def _update(snap=stats["skill_snapshot"]):
                try:
                    self._right_panel.update_skill_snapshot(snap)
                except Exception:
                    pass
            self.root.after(0, _update)

    def _on_status(self, status: str):
        if self._control_card:
            self._control_card.set_status(status)

    def _tick_wall_clock(self):
        """Update the header clock every second with real wall time."""
        self._wall_clock_var.set(time.strftime("%H:%M:%S"))
        self.root.after(1000, self._tick_wall_clock)

    def run(self):
        self.root.bind("<F5>", self._restart)
        self.root.mainloop()

    def _restart(self, _event=None):
        """Restart the GUI process in-place when F5 is pressed."""
        import sys, os
        self.root.destroy()
        os.execv(sys.executable, [sys.executable] + sys.argv)


# ═══════════════════════════════════════════════════════════════════════════
if __name__ == "__main__":
    # Boost process priority so Windows schedules us more aggressively
    try:
        import ctypes, ctypes.wintypes
        ABOVE_NORMAL = 0x00008000
        handle = ctypes.windll.kernel32.GetCurrentProcess()
        ctypes.windll.kernel32.SetPriorityClass(handle, ABOVE_NORMAL)
    except Exception:
        pass
    RuneScriptApp().run()
