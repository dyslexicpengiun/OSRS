"""
OSRS map location data — hardcoded for reliability.
Contains banks, cities, dungeons, teleport spots and key landmarks.
Format: (world_x, world_y, plane, category, name)
"""

# Category colours for map rendering
CATEGORY_COLOURS = {
    "bank":      "#FFD700",   # gold
    "city":      "#FFFFFF",   # white
    "dungeon":   "#FF6B6B",   # red
    "teleport":  "#7B68EE",   # purple
    "agility":   "#00CED1",   # teal
    "shop":      "#90EE90",   # green
    "landmark":  "#FFA500",   # orange
}

LOCATIONS = [
    # ── Banks ─────────────────────────────────────────────────────────────
    (3092, 3491, 0, "bank",    "Edgeville Bank"),
    (3253, 3420, 0, "bank",    "Varrock West Bank"),
    (3185, 3436, 0, "bank",    "Varrock East Bank"),
    (3094, 3240, 0, "bank",    "Lumbridge Bank"),
    (2724, 3491, 0, "bank",    "Falador East Bank"),
    (2946, 3368, 0, "bank",    "Falador West Bank"),
    (2612, 3332, 0, "bank",    "Port Sarim Deposit"),
    (2943, 3143, 0, "bank",    "Draynor Bank"),
    (2445, 3083, 0, "bank",    "Rimmington Deposit"),
    (3040, 4974, 1, "bank",    "Prifddinas Bank"),
    (2482, 3854, 0, "bank",    "Neitiznot Bank"),
    (2631, 3680, 0, "bank",    "Catherby Bank"),
    (2855, 3690, 0, "bank",    "Camelot/Seers Bank"),
    (2609, 3093, 0, "bank",    "Entrana Bank"),
    (3013, 3355, 0, "bank",    "Draynor Village Bank"),
    (2659, 3282, 0, "bank",    "Alkharid Bank"),
    (3293, 3175, 0, "bank",    "Al Kharid Bank"),
    (2440, 3415, 0, "bank",    "Ardougne North Bank"),
    (2655, 3283, 0, "bank",    "Al Kharid Bank"),
    (2523, 3092, 0, "bank",    "Corsair Cove Bank"),
    (3510, 3479, 0, "bank",    "Canifis Bank"),
    (3800, 2998, 0, "bank",    "Shilo Village Bank"),
    (2213, 3099, 0, "bank",    "Ape Atoll Bank"),
    (2381, 3153, 0, "bank",    "Zanaris Bank"),
    (3049, 4974, 1, "bank",    "Prifddinas Bank"),
    (1639, 3944, 0, "bank",    "Tithe Farm Bank"),
    (1805, 3566, 0, "bank",    "Hosidius Bank"),
    (1626, 3668, 0, "bank",    "Kourend Castle Bank"),
    (1811, 3854, 0, "bank",    "Arceuus Bank"),
    (1753, 3802, 0, "bank",    "Lovakengj Bank"),
    (1506, 3634, 0, "bank",    "Piscarilius Bank"),
    (3622, 3339, 0, "bank",    "Mort'ton Bank"),
    (2799, 2766, 0, "bank",    "Gu'Tanoth Bank"),
    (2833, 2956, 0, "bank",    "Gu'Tanoth Bank"),
    (3355, 2974, 0, "bank",    "Burgh de Rott Bank"),

    # ── Cities / Towns ────────────────────────────────────────────────────
    (3213, 3424, 0, "city",    "Varrock"),
    (3222, 3218, 0, "city",    "Lumbridge"),
    (2965, 3379, 0, "city",    "Falador"),
    (3088, 3488, 0, "city",    "Edgeville"),
    (2757, 3478, 0, "city",    "Taverley"),
    (2843, 3430, 0, "city",    "Burthorpe"),
    (2617, 3333, 0, "city",    "Port Sarim"),
    (2957, 3210, 0, "city",    "Draynor"),
    (2440, 3415, 0, "city",    "Ardougne"),
    (2729, 3485, 0, "city",    "Falador"),
    (2606, 3667, 0, "city",    "Catherby"),
    (2757, 3477, 0, "city",    "Taverley"),
    (2795, 3615, 0, "city",    "Seers Village"),
    (2709, 3490, 0, "city",    "Rellekka"),
    (2343, 3690, 0, "city",    "Camelot"),
    (3488, 3444, 0, "city",    "Canifis"),
    (3590, 3480, 0, "city",    "Slayer Tower area"),
    (2513, 3636, 0, "city",    "Sinclair Mansion area"),
    (3293, 3163, 0, "city",    "Al Kharid"),
    (3429, 3538, 0, "city",    "Paterdomus"),
    (3240, 3611, 0, "city",    "Edgeville Monastery"),
    (1811, 3566, 0, "city",    "Hosidius"),
    (1628, 3668, 0, "city",    "Kourend Castle"),
    (1811, 3854, 0, "city",    "Arceuus"),
    (1753, 3803, 0, "city",    "Lovakengj"),
    (1505, 3634, 0, "city",    "Piscarilius"),
    (1766, 3584, 0, "city",    "Shayzien"),
    (3726, 3534, 0, "city",    "Meiyerditch"),
    (3600, 3151, 0, "city",    "Shilo Village"),

    # ── Dungeons ──────────────────────────────────────────────────────────
    (3097, 9867, 0, "dungeon", "Edgeville Dungeon"),
    (3280, 9856, 0, "dungeon", "Varrock Sewers"),
    (3230, 9617, 0, "dungeon", "Draynor Sewers"),
    (2884, 9799, 0, "dungeon", "Taverley Dungeon"),
    (2434, 9803, 0, "dungeon", "Brimhaven Dungeon"),
    (2699, 9564, 0, "dungeon", "Karamja Dungeon"),
    (3360, 9669, 0, "dungeon", "Stronghold of Security"),
    (1999, 4716, 0, "dungeon", "Lumbridge Swamp Caves"),
    (3231, 9913, 0, "dungeon", "Wilderness Dungeon"),
    (2782, 10000, 0,"dungeon", "Kalphite Lair"),
    (3202, 9974, 0, "dungeon", "Chaos Temple Dungeon"),
    (3041, 10236, 0,"dungeon", "God Wars Dungeon"),
    (2897, 4449, 0, "dungeon", "Ancient Cavern"),
    (2800, 10000, 0,"dungeon", "Smoke Dungeon"),
    (3507, 9494, 0, "dungeon", "Slayer Tower Dungeon"),

    # ── Teleport destinations ─────────────────────────────────────────────
    (2899, 3544, 0, "teleport","Camelot Teleport"),
    (3087, 3496, 0, "teleport","Edgeville Lever"),
    (2461, 3442, 0, "teleport","Ardougne Teleport"),
    (3091, 3242, 0, "teleport","Lumbridge Teleport"),
    (3210, 3424, 0, "teleport","Varrock Teleport"),
    (2964, 3379, 0, "teleport","Falador Teleport"),
    (2757, 3478, 0, "teleport","Taverley Teleport"),
    (3105, 3251, 0, "teleport","Home Teleport (Lumbridge)"),
    (2440, 5765, 0, "teleport","Lunar Isle Teleport"),

    # ── Agility courses ───────────────────────────────────────────────────
    (3103, 3279, 0, "agility", "Draynor Agility"),
    (3192, 3413, 0, "agility", "Al Kharid Agility"),
    (2474, 3436, 0, "agility", "Gnome Agility"),
    (2530, 3547, 0, "agility", "Barbarian Agility"),
    (2666, 3298, 0, "agility", "Werewolf Agility"),
    (3240, 3913, 0, "agility", "Wilderness Agility"),
    (2996, 3914, 0, "agility", "Wilderness Agility Course"),
    (3008, 3960, 0, "agility", "Wilderness Rooftop"),
    (1641, 3676, 0, "agility", "Shayzien Agility"),
    (2755, 3476, 0, "agility", "Falador Rooftop"),
    (3294, 3186, 0, "agility", "Al Kharid Rooftop"),
    (3118, 3241, 0, "agility", "Draynor Rooftop"),
    (3212, 3414, 0, "agility", "Varrock Rooftop"),
    (2963, 3400, 0, "agility", "Falador Rooftop"),
    (2792, 3472, 0, "agility", "Seers Rooftop"),
    (2673, 3488, 0, "agility", "Rellekka Rooftop"),
    (3040, 4974, 1, "agility", "Prifddinas Agility"),
    (2669, 3297, 0, "agility", "Ape Atoll Agility"),

    # ── Key landmarks ─────────────────────────────────────────────────────
    (3165, 3485, 0, "landmark","Grand Exchange"),
    (2957, 3370, 0, "landmark","Falador Park"),
    (3231, 3459, 0, "landmark","Varrock Palace"),
    (3201, 3206, 0, "landmark","Lumbridge Castle"),
    (2966, 3343, 0, "landmark","White Knights Castle"),
    (2452, 3426, 0, "landmark","Ardougne Castle"),
    (2901, 3356, 0, "landmark","Crafting Guild"),
    (2434, 3543, 0, "landmark","Fight Arena"),
    (2897, 3550, 0, "landmark","Legends Guild"),
    (3403, 3159, 0, "landmark","Duel Arena"),
    (3200, 3940, 0, "landmark","Wilderness Ditch"),
    (3026, 3958, 0, "landmark","Mage of Zamorak"),
    (3295, 3293, 0, "landmark","Barbarian Village"),
    (2513, 3877, 0, "landmark","Waterbirth Island"),
    (2609, 4317, 0, "landmark","Jatizso/Neitiznot"),
    (3087, 3470, 0, "landmark","Thessaly's Farm"),
]


def get_locations_in_region(wx_min, wy_min, wx_max, wy_max, plane=0,
                             categories=None):
    """
    Return list of (wx, wy, plane, category, name) within the given bounds.
    categories: list of category strings to filter, or None for all.
    """
    results = []
    for (x, y, p, cat, name) in LOCATIONS:
        if p != plane:
            continue
        if categories and cat not in categories:
            continue
        if wx_min <= x <= wx_max and wy_min <= y <= wy_max:
            results.append((x, y, p, cat, name))
    return results
