"""
Position Tracker  v3
====================
Receives game state from the rseye-connector RuneLite Plugin Hub plugin.

Setup (one-time):
  1. Install "rseye-connector" from the RuneLite Plugin Hub
  2. Disable the old "HTTP Server" plugin (conflicts on port 8080)
  3. In rseye-connector settings:
       Endpoint    -> http://localhost   (port 80, default)
       bearerToken -> token              (default)
       Position Data -> ON, frequency 1 tick
       Stat Data     -> ON  (replaces old HTTP Server /stats)
       Inventory Data, Equipment Data -> ON as needed

The plugin POSTs to http://localhost/api/v1/<type>_update/

Usage:
    from core.position_tracker import get_tracker
    tracker = get_tracker()
    tracker.start()

    pos = tracker.position          # (x, y, plane) or None
    tracker.on_position = callback  # (x, y, plane)
    tracker.on_stats    = callback  # (dict of skill->{"level":n,"xp":n})
"""
from __future__ import annotations

import json
import logging
import threading
from http.server import BaseHTTPRequestHandler, HTTPServer
from typing import Callable, Dict, Optional, Tuple

logger = logging.getLogger(__name__)

LISTEN_PORT  = 80
BEARER_TOKEN = "token"


class PositionTracker:

    def __init__(self, port: int = LISTEN_PORT, token: str = BEARER_TOKEN):
        self._port   = port
        self._token  = token

        self._pos:      Optional[Tuple[int, int, int]] = None
        self._stats:    Dict[str, dict] = {}
        self._inv:      list = []
        self._equip:    dict = {}
        self._username: str  = ""

        self._lock      = threading.Lock()
        self._server:   Optional[HTTPServer] = None
        self._thread:   Optional[threading.Thread] = None
        self._connected = False

        # Callbacks
        self.on_position: Optional[Callable[[int, int, int], None]] = None
        self.on_stats:    Optional[Callable[[dict], None]]          = None
        self.on_update:   Optional[Callable[[int, int, int], None]] = None  # alias for on_position

    # ── Public ──────────────────────────────────────────────────────────

    @property
    def position(self) -> Optional[Tuple[int, int, int]]:
        with self._lock: return self._pos

    @property
    def x(self) -> Optional[int]:
        p = self.position; return p[0] if p else None

    @property
    def y(self) -> Optional[int]:
        p = self.position; return p[1] if p else None

    @property
    def plane(self) -> Optional[int]:
        p = self.position; return p[2] if p else None

    @property
    def username(self) -> str:
        with self._lock: return self._username

    @property
    def stats(self) -> Dict[str, dict]:
        with self._lock: return dict(self._stats)

    @property
    def inventory(self) -> list:
        with self._lock: return list(self._inv)

    @property
    def equipment(self) -> dict:
        with self._lock: return dict(self._equip)

    @property
    def plugin_available(self) -> bool:
        return self._connected

    def start(self):
        if self._thread and self._thread.is_alive():
            return
        tracker = self

        class _Handler(BaseHTTPRequestHandler):
            def log_message(self, *a): pass

            def do_POST(self):
                # Auth check
                auth = self.headers.get("Authorization", "")
                if tracker._token and auth != f"Bearer: {tracker._token}":
                    self.send_response(401); self.end_headers(); return

                length = int(self.headers.get("Content-Length", 0))
                body   = self.rfile.read(length)
                path   = self.path.rstrip("/")

                try:
                    data = json.loads(body)
                    # Update username whenever we get any packet
                    if "username" in data:
                        with tracker._lock:
                            tracker._username = data["username"]
                            if not tracker._connected:
                                tracker._connected = True
                                logger.info("[Position] rseye-connector connected — user: %s",
                                            data["username"])

                    if "position_update" in path:
                        pos = data.get("position", {})
                        x, y, plane = int(pos["x"]), int(pos["y"]), int(pos.get("plane", 0))
                        if 1000 <= x <= 5000 and 1000 <= y <= 15000:
                            tracker._recv_position(x, y, plane)

                    elif "stat_update" in path:
                        changes = data.get("statChanges", [])
                        skills  = {
                            s["skill"].capitalize(): {
                                "level":       s["level"],
                                "boostedLevel":s["boostedLevel"],
                                "xp":          s["xp"],
                            }
                            for s in changes
                        }
                        with tracker._lock:
                            tracker._stats = skills
                        if tracker.on_stats:
                            try: tracker.on_stats(skills)
                            except Exception as e:
                                logger.debug("[Position] on_stats error: %s", e)

                    elif "inventory_update" in path:
                        with tracker._lock:
                            tracker._inv = data.get("items", [])

                    elif "equipment_update" in path:
                        with tracker._lock:
                            tracker._equip = data.get("items", {})

                    self.send_response(200)
                except Exception as e:
                    logger.debug("[Position] parse error: %s — body: %s", e, body[:80])
                    self.send_response(400)
                self.end_headers()

        try:
            self._server = HTTPServer(("", self._port), _Handler)
            self._thread = threading.Thread(
                target=self._server.serve_forever,
                daemon=True,
                name="PositionTracker"
            )
            self._thread.start()
            logger.info("[Position] Listening on http://localhost:%d/api/v1/", self._port)
        except OSError as e:
            logger.error("[Position] Could not bind port %d: %s", self._port, e)

    def stop(self):
        if self._server:
            self._server.shutdown()
            self._server = None

    def push(self, x: int, y: int, plane: int = 0):
        """Scripts can push a known position directly."""
        self._recv_position(x, y, plane)

    # ── Internal ────────────────────────────────────────────────────────

    def _recv_position(self, x: int, y: int, plane: int):
        with self._lock:
            if (x, y, plane) == self._pos:
                return
            self._pos = (x, y, plane)
        logger.debug("[Position] %d, %d, %d", x, y, plane)
        cb = self.on_position or self.on_update
        if cb:
            try: cb(x, y, plane)
            except Exception as e:
                logger.debug("[Position] callback error: %s", e)


# ── Singleton ────────────────────────────────────────────────────────────
_tracker: Optional[PositionTracker] = None

def get_tracker() -> PositionTracker:
    global _tracker
    if _tracker is None:
        _tracker = PositionTracker()
    return _tracker
