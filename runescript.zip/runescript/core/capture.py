"""
Screen Capture
Finds the RuneLite window and captures frames from it using mss.
All coordinates returned by the detection layer are relative to
the game viewport, not the full monitor.
"""

import logging
import numpy as np
from typing import Optional, Tuple

logger = logging.getLogger(__name__)

# Populated on first successful window find
_window_rect: Optional[Tuple[int,int,int,int]] = None  # (left, top, w, h)

# Cache the RuneLite HWND so we don't EnumWindows every frame
_runelite_hwnd: Optional[int] = None


# Titles to search for — RuneLite uses its own name as the window title
_GAME_TITLES = ['runelite', 'old school runescape']


def find_game_window(title: str = None) -> Optional[Tuple[int,int,int,int]]:
    """
    Find the RuneLite/OSRS window by title substring (case-insensitive).
    Tries RuneLite first, then Old School RuneScape.
    Returns (left, top, width, height) or None.
    """
    global _window_rect
    search = [title.lower()] if title else _GAME_TITLES
    try:
        import win32gui
        found = []
        def _cb(hwnd, _):
            if win32gui.IsWindowVisible(hwnd):
                t = win32gui.GetWindowText(hwnd).lower()
                if any(s in t for s in search):
                    l, top, r, b = win32gui.GetWindowRect(hwnd)
                    found.append((l, top, r - l, b - top))
        win32gui.EnumWindows(_cb, None)
        if found:
            _window_rect = found[0]
            return _window_rect
    except ImportError:
        pass
    except Exception as e:
        logger.debug(f'[Capture] Window search error: {e}')
    return None


def screenshot(rect: Optional[Tuple[int,int,int,int]] = None) -> Optional[np.ndarray]:
    """
    Capture the RuneLite window directly via its HWND, bypassing any
    windows on top. Uses PrintWindow(PW_RENDERFULLCONTENT) which works
    for hardware-accelerated Java/OpenGL windows on Windows 10/11.
    Falls back to mss if win32 is unavailable.
    Returns a BGR numpy array or None.
    """
    global _window_rect
    try:
        target_rect = rect or _window_rect
        if target_rect is None:
            target_rect = find_game_window()
        if target_rect is None:
            return None

        # ── Win32 PrintWindow path ────────────────────────────────────
        try:
            import win32gui, win32ui
            from ctypes import windll, c_int, byref, sizeof

            hwnd = _get_runelite_hwnd()
            if hwnd:
                wl, wt, wr, wb = win32gui.GetWindowRect(hwnd)
                full_w = wr - wl
                full_h = wb - wt
                if full_w <= 0 or full_h <= 0:
                    raise ValueError("Invalid window dimensions")

                # Create a memory DC and compatible bitmap
                hwnd_dc  = win32gui.GetWindowDC(hwnd)
                mfc_dc   = win32ui.CreateDCFromHandle(hwnd_dc)
                save_dc  = mfc_dc.CreateCompatibleDC()
                bmp      = win32ui.CreateBitmap()
                bmp.CreateCompatibleBitmap(mfc_dc, full_w, full_h)
                save_dc.SelectObject(bmp)

                # PW_RENDERFULLCONTENT = 0x00000002
                # This forces Windows to composite GPU/DX content into the bitmap
                pw_result = windll.user32.PrintWindow(hwnd, save_dc.GetSafeHdc(), 0x2)

                bmp_info = bmp.GetInfo()
                bmp_bits = bmp.GetBitmapBits(True)

                save_dc.DeleteDC()
                mfc_dc.DeleteDC()
                win32gui.ReleaseDC(hwnd, hwnd_dc)
                win32gui.DeleteObject(bmp.GetHandle())

                if pw_result and bmp_bits:
                    frame = np.frombuffer(bmp_bits, dtype=np.uint8)
                    frame = frame.reshape((bmp_info['bmHeight'],
                                           bmp_info['bmWidth'], 4))
                    # BGRA → BGR
                    frame = np.ascontiguousarray(frame[:, :, :3])

                    # Check the frame isn't blank (PrintWindow succeeded but returned black)
                    if frame.mean() < 1.0:
                        raise ValueError("PrintWindow returned blank frame — GPU not composited")

                    # Crop to the requested rect
                    crop_x = max(0, target_rect[0] - wl)
                    crop_y = max(0, target_rect[1] - wt)
                    cw, ch = target_rect[2], target_rect[3]
                    cropped = frame[crop_y:crop_y + ch, crop_x:crop_x + cw]
                    if cropped.size > 0:
                        return cropped.copy()

        except Exception as e:
            logger.debug(f'[Capture] PrintWindow path failed: {e}')

        # ── mss fallback ──────────────────────────────────────────────
        import mss
        l, top, w, h = target_rect
        with mss.mss() as sct:
            raw   = sct.grab({'left': l, 'top': top, 'width': w, 'height': h})
            frame = np.array(raw)[:, :, :3]
            return frame.copy()

    except Exception as e:
        logger.debug(f'[Capture] Screenshot error: {e}')
        return None


def _get_runelite_hwnd():
    """Return the HWND of the RuneLite window, caching the result."""
    global _runelite_hwnd
    try:
        import win32gui
        if _runelite_hwnd and win32gui.IsWindow(_runelite_hwnd):
            return _runelite_hwnd
        result = [None]
        def _cb(hwnd, _):
            if not result[0] and win32gui.IsWindowVisible(hwnd):
                if 'runelite' in win32gui.GetWindowText(hwnd).lower():
                    result[0] = hwnd
        win32gui.EnumWindows(_cb, None)
        _runelite_hwnd = result[0]
        return _runelite_hwnd
    except Exception:
        return None


def _check_capture_method() -> str:
    """Log which capture method will be used. Call once at startup."""
    try:
        import win32gui, win32ui
        from ctypes import windll
        hwnd = _get_runelite_hwnd()
        if hwnd:
            logger.info('[Capture] Using PrintWindow (HWND-based, occlusion-proof)')
            return 'printwindow'
        else:
            logger.info('[Capture] RuneLite not found — will retry on first capture')
            return 'printwindow_pending'
    except ImportError:
        logger.warning('[Capture] pywin32 not available — falling back to mss (occlusion NOT ignored)')
        return 'mss'


def get_window_rect() -> Optional[Tuple[int,int,int,int]]:
    return _window_rect or find_game_window()


# ── Minimap region ────────────────────────────────────────────────────────
# The minimap is detected by finding the compass rose — the red/yellow/orange
# cluster that RuneLite always renders at the top of the minimap circle.
# This is immune to sidebar state because it targets game content, not chrome.

MINIMAP_DIAMETER = 155   # pixels — consistent at 1920×1080; scaled by win_h below

# Cache the last known good minimap rect so we don't scan every frame
_minimap_rect_cache: Optional[Tuple[int,int,int,int]] = None
_minimap_cache_hits: int = 0
_MINIMAP_CACHE_REFRESH = 120   # re-scan every N frames (~2 min at 1fps)


def _sidebar_is_open(win_rect: Tuple[int,int,int,int]) -> bool:
    """
    Detect whether the RuneLite right sidebar is open by sampling a 6x6 pixel
    block inside the expected sidebar panel area.
    Sidebar background is a consistent near-black grey RGB≈(30,30,30).
    Game content at the same location averages much brighter when sidebar is closed.
    """
    win_left, win_top, win_w, win_h = win_rect
    # right-120, top+80 sits inside the sidebar panel when open
    sample_x = win_left + win_w - 120
    sample_y = win_top  + 80
    frame = screenshot((sample_x, sample_y, 6, 6))
    if frame is None:
        return False
    return float(frame.mean()) < 45


def _find_minimap_rect(win_rect: Tuple[int,int,int,int]) -> Tuple[int,int,int,int]:
    """
    Return the minimap capture rect using calibrated fixed offsets.
    The rect is sized and positioned so the player dot lands at the centre
    pixel of the 155×155 capture.
    """
    win_left, win_top, win_w, win_h = win_rect
    diameter = max(140, int(win_h * 0.147))   # ~154 at 1048h

    sidebar_open = _sidebar_is_open(win_rect)
    logger.debug(f'[Capture] Sidebar {"open" if sidebar_open else "closed"}')

    right_offset = _MINIMAP_RIGHT_OFFSET_OPEN if sidebar_open else _MINIMAP_RIGHT_OFFSET_CLOSED
    mm_left = win_left + win_w - diameter - right_offset
    mm_top  = win_top  + _MINIMAP_TOP_OFFSET
    return (mm_left, mm_top, diameter, diameter)


# ── Minimap offset constants ──────────────────────────────────────────────
# _MINIMAP_RIGHT_OFFSET_* / _MINIMAP_TOP_OFFSET:
#   Position the capture so the minimap circle border is visible.
#   Tune with: python -c "from core.capture import calibrate_minimap; calibrate_minimap()"
#
# _MINIMAP_CENTRE_ADJUST_X / _Y:
#   Fine-tune so the player dot lands at the centre pixel (77,77) of the capture.
#   Positive X  = shift capture RIGHT  (player moves left  in frame)
#   Negative X  = shift capture LEFT   (player moves right in frame)
#   Positive Y  = shift capture DOWN   (player moves up    in frame)
#   Negative Y  = shift capture UP     (player moves down  in frame)
#
#   From debug: player dot detected at frame coords (8,65), capture centre (77,77)
#   Need player at (77,77): shift capture RIGHT by 77-8=69, DOWN by 77-65=12
#   → CENTRE_ADJUST_X = +69, CENTRE_ADJUST_Y = +12
#   But this shifts the circle too — right_offset absorbs the horizontal shift.
#   Net effect: player centred, circle border may shift slightly off-centre (acceptable).
_MINIMAP_RIGHT_OFFSET_CLOSED = 44   # measured from game screenshot
_MINIMAP_RIGHT_OFFSET_OPEN   = 286  # measured from game screenshot
_MINIMAP_TOP_OFFSET          = 38   # measured from game screenshot


def capture_minimap() -> "Optional[np.ndarray]":
    """
    Capture the minimap region from the RuneLite window.
    Auto-detects the minimap position so it works with the RuneLite
    sidebar open or closed.
    Returns a BGR numpy array or None.
    """
    global _minimap_rect_cache, _minimap_cache_hits

    win_rect = get_window_rect()
    if win_rect is None:
        return None

    # Re-scan periodically or if cache is empty
    _minimap_cache_hits += 1
    if _minimap_rect_cache is None or _minimap_cache_hits >= _MINIMAP_CACHE_REFRESH:
        found = _find_minimap_rect(win_rect)
        if found:
            _minimap_rect_cache = found
            _minimap_cache_hits = 0

    if _minimap_rect_cache is None:
        return None

    return screenshot(_minimap_rect_cache)


def list_windows():
    """
    Print all visible windows with titles — run this to find the exact
    title RuneLite is using on your system.

    Usage:
        python -c "from core.capture import list_windows; list_windows()"
    """
    try:
        import win32gui
        results = []
        def _cb(hwnd, _):
            if win32gui.IsWindowVisible(hwnd):
                t = win32gui.GetWindowText(hwnd)
                if t.strip():
                    results.append(t)
        win32gui.EnumWindows(_cb, None)
        print(f"[Windows] Found {len(results)} visible windows:")
        for t in sorted(results):
            print(f"  {repr(t)}")
    except ImportError:
        print("[Windows] pywin32 not installed")
    except Exception as e:
        print(f"[Windows] Error: {e}")


def calibrate_minimap():
    """
    Detect the minimap and save a debug snapshot.
    Run this with the sidebar OPEN, then CLOSED, to verify both cases.
    The output tells you which state was detected so you can tune each offset.

    Usage:
        python -c "from core.capture import calibrate_minimap; calibrate_minimap()"

    To tune:
        Sidebar CLOSED → adjust _MINIMAP_RIGHT_OFFSET_CLOSED
        Sidebar OPEN   → adjust _MINIMAP_RIGHT_OFFSET_OPEN
        Both too high  → increase _MINIMAP_TOP_OFFSET
        Both too low   → decrease _MINIMAP_TOP_OFFSET
        Left of circle clipped  → decrease right_offset (shift capture right)
        Right of circle clipped → increase right_offset (shift capture left)
    """
    rect = get_window_rect()
    if rect is None:
        print('[Calibrate] RuneLite window not found. Is it open?')
        return
    win_left, win_top, win_w, win_h = rect
    print(f'[Calibrate] Window : left={win_left} top={win_top} w={win_w} h={win_h}')

    sidebar = _sidebar_is_open(rect)
    print(f'[Calibrate] Sidebar: {"OPEN  → using _MINIMAP_RIGHT_OFFSET_OPEN  = " + str(_MINIMAP_RIGHT_OFFSET_OPEN) if sidebar else "CLOSED → using _MINIMAP_RIGHT_OFFSET_CLOSED = " + str(_MINIMAP_RIGHT_OFFSET_CLOSED)}')
    print(f'[Calibrate] Top offset: _MINIMAP_TOP_OFFSET = {_MINIMAP_TOP_OFFSET}')

    # Force a fresh detection (bypass cache)
    global _minimap_rect_cache, _minimap_cache_hits
    _minimap_rect_cache = None
    _minimap_cache_hits = 0

    found = _find_minimap_rect(rect)
    mm_l, mm_t, mm_w, mm_h = found
    print(f'[Calibrate] Minimap: left={mm_l} top={mm_t} w={mm_w} h={mm_h}')
    print(f'[Calibrate]          right edge at x={mm_l+mm_w} '
          f'(window right={win_left+win_w}, offset={win_left+win_w - mm_l - mm_w}px)')

    frame = capture_minimap()
    if frame is not None:
        print(f'[Calibrate] Capture OK — shape: {frame.shape}')
        try:
            import cv2 as _cv2, os
            out = os.path.join(os.path.dirname(__file__), 'minimap_debug.png')
            _cv2.imwrite(out, frame)

            # Quick pixel diagnostics
            gray = _cv2.cvtColor(frame, _cv2.COLOR_BGR2GRAY)
            dead_top = sum(1 for y in range(frame.shape[0]) if float(frame[y, :frame.shape[1]//2].mean()) < 35)
            dead_right = sum(1 for x in range(frame.shape[1]-1, frame.shape[1]//2, -1) if float(frame[frame.shape[0]//2:, x].mean()) < 35)
            left_arc = next((x for x in range(frame.shape[1]) if int((gray[:, x] < 25).sum()) > 8), None)
            top_arc  = next((y for y in range(frame.shape[0]) if int((gray[y, :] < 25).sum()) > 8), None)

            print(f'[Calibrate] Dead rows at top:   {dead_top}  (want 0)')
            print(f'[Calibrate] Dead cols on right: {dead_right}  (want 0)')
            print(f'[Calibrate] Left border arc at: col {left_arc}  (want ~0)')
            print(f'[Calibrate] Top  border arc at: row {top_arc}   (want ~0)')
            print(f'[Calibrate] Snapshot → {out}')
        except Exception as e:
            print(f'[Calibrate] Could not save snapshot: {e}')
    else:
        print('[Calibrate] capture_minimap() returned None')
