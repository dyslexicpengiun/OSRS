"""
Hiscores Tracker
================
Polls the OSRS hiscores API to track skill levels and XP.
Calculates XP/hr by diffing snapshots over time.

API endpoint:
    https://secure.runescape.com/m=hiscore_oldschool/index_lite?player=USERNAME

Response format (one skill per line):
    rank,level,xp
Skills are returned in OSRS order (Attack, Defence, Strength, ...)

Usage
-----
    tracker = HiscoresTracker("XP Optional")
    tracker.load()          # restore last saved data
    tracker.start()         # begin polling every 60s
    tracker.stop()
    snapshot = tracker.snapshot()   # list of skill dicts for GUI
"""

from __future__ import annotations

import json
import logging
import os
import sys
import threading
import time
from typing import Callable, Dict, List, Optional, Tuple
from urllib.request import urlopen, Request
from urllib.error import URLError

_HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                  "AppleWebKit/537.36 (KHTML, like Gecko) "
                  "Chrome/124.0.0.0 Safari/537.36"
}

logger = logging.getLogger(__name__)

_HERE     = os.path.dirname(os.path.abspath(__file__))
_PKG_ROOT = os.path.dirname(_HERE)
_DATA_DIR = os.path.join(_PKG_ROOT, "data")
_SAVE_FILE = os.path.join(_DATA_DIR, "hiscores.json")

# ── OSRS skill order (matches hiscores API response) ─────────────────────
SKILL_ORDER: List[str] = [
    "Attack", "Defence", "Strength", "Hitpoints", "Ranged",
    "Prayer", "Magic", "Cooking", "Woodcutting", "Fletching",
    "Fishing", "Firemaking", "Crafting", "Smithing", "Mining",
    "Herblore", "Agility", "Thieving", "Slayer", "Farming",
    "Runecrafting", "Hunter", "Construction",
]

HISCORES_URL = (
    "https://secure.runescape.com/m=hiscore_oldschool/"
    "index_lite?player={}"
)

POLL_INTERVAL = 60   # seconds between hiscores polls


# ── XP table ──────────────────────────────────────────────────────────────
_XP_FOR_LEVEL: List[int] = [
    0, 0, 83, 174, 276, 388, 512, 650, 801, 969, 1154,
    1358, 1584, 1833, 2107, 2411, 2746, 3115, 3523, 3973, 4470,
    5018, 5624, 6291, 7028, 7842, 8740, 9730, 10824, 12031, 13363,
    14833, 16456, 18247, 20224, 22406, 24815, 27473, 30408, 33648, 37224,
    41171, 45529, 50339, 55649, 61512, 67983, 75127, 83014, 91721, 101333,
    111945, 123660, 136594, 150872, 166636, 184040, 203254, 224466, 247886,
    273742, 301288, 331258, 363931, 399345, 437931, 480048, 526645, 576962,
    631027, 689821, 753370, 821722, 896256, 977410, 1065744, 1166256,
    1277995, 1400733, 1536443, 1684900, 1847750, 2025787, 2218877, 2428490,
    2655534, 2902465, 3170780, 3462226, 3779380, 4124695, 4500768, 4909345,
    5353622, 5835754, 6358510, 6924344, 7535654, 8197786, 8914070, 99_999_999,
]

def xp_to_level(xp: int) -> int:
    for lvl in range(99, 0, -1):
        if xp >= _XP_FOR_LEVEL[lvl]:
            return lvl
    return 1


# ── Per-skill state ───────────────────────────────────────────────────────

class _SkillState:
    __slots__ = ("level", "xp", "rank",
                 "session_start_xp", "session_start_time",
                 "prev_xp", "prev_time", "cur_poll_time")

    def __init__(self):
        self.level             = 1
        self.xp                = 0
        self.rank              = -1
        self.session_start_xp  = 0
        self.session_start_time = 0.0
        self.prev_xp           = 0
        self.prev_time         = 0.0
        self.cur_poll_time     = 0.0

    def xp_per_hour(self) -> int:
        """XP/hr based on delta between last two polls."""
        if self.prev_time == 0 or self.prev_xp == 0 or self.cur_poll_time == 0:
            return 0
        elapsed = self.cur_poll_time - self.prev_time
        if elapsed < 10:
            return 0
        delta = self.xp - self.prev_xp
        if delta <= 0:
            return 0
        return int(delta / elapsed * 3600)

    def session_xp(self) -> int:
        return max(0, self.xp - self.session_start_xp)

    def to_dict(self) -> dict:
        return {
            "level": self.level,
            "xp":    self.xp,
            "rank":  self.rank,
        }

    @classmethod
    def from_dict(cls, d: dict) -> "_SkillState":
        s = cls()
        s.level = d.get("level", 1)
        s.xp    = d.get("xp",    0)
        s.rank  = d.get("rank",  -1)
        s.session_start_xp = s.xp   # session starts fresh on load
        return s


# ── Main tracker ──────────────────────────────────────────────────────────

class HiscoresTracker:

    def __init__(self, username: str = ""):
        self._username  = username.strip()
        self._skills:   Dict[str, _SkillState] = {
            s: _SkillState() for s in SKILL_ORDER
        }
        self._running   = False
        self._thread:   Optional[threading.Thread] = None
        self._last_poll: float = 0.0
        self._lock      = threading.Lock()
        self._error     = ""        # last fetch error for GUI display
        self._fetching  = False     # True while a request is in flight

        # Callbacks
        self.on_update:  Optional[Callable[[List[dict]], None]] = None
        self.on_levelup: Optional[Callable[[str, int], None]]   = None

    # ── Username ──────────────────────────────────────────────────────────

    @property
    def username(self) -> str:
        return self._username

    @username.setter
    def username(self, name: str):
        self._username = name.strip()
        self._last_poll = 0.0   # force immediate re-poll

    # ── Lifecycle ─────────────────────────────────────────────────────────

    def start(self):
        if self._running:
            return
        self._running = True
        self._thread  = threading.Thread(
            target=self._loop, daemon=True, name="HiscoresTracker")
        self._thread.start()
        # Fire an immediate fetch without waiting for the first 5s sleep
        if self._username:
            threading.Thread(target=self._fetch, daemon=True,
                             name="HiscoresFetchImmediate").start()
        logger.info(f"[Hiscores] Started — username='{self._username}'")

    def stop(self):
        self._running = False
        self.save()

    def force_poll(self):
        """Trigger an immediate fetch on the next loop iteration."""
        self._last_poll = 0.0

    # ── Persistence ───────────────────────────────────────────────────────

    def load(self):
        try:
            if not os.path.exists(_SAVE_FILE):
                return
            with open(_SAVE_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)
            saved_user = data.get("username", "")
            # Only restore if same username (or no username set yet)
            if saved_user and self._username and \
               saved_user.lower() != self._username.lower():
                logger.info("[Hiscores] Saved data is for a different user — skipping")
                return
            if not self._username and saved_user:
                self._username = saved_user
            with self._lock:
                for skill, sd in data.get("skills", {}).items():
                    if skill in self._skills:
                        self._skills[skill] = _SkillState.from_dict(sd)
            logger.info(f"[Hiscores] Loaded saved data for '{self._username}'")
        except Exception as e:
            logger.warning(f"[Hiscores] Load failed: {e}")

    def save(self):
        try:
            os.makedirs(_DATA_DIR, exist_ok=True)
            with self._lock:
                payload = {
                    "username":  self._username,
                    "saved_at":  time.strftime("%Y-%m-%d %H:%M:%S"),
                    "skills":    {s: st.to_dict()
                                  for s, st in self._skills.items()},
                }
            with open(_SAVE_FILE, "w", encoding="utf-8") as f:
                json.dump(payload, f, indent=2)
        except Exception as e:
            logger.warning(f"[Hiscores] Save failed: {e}")

    # ── Polling ───────────────────────────────────────────────────────────

    def _loop(self):
        while self._running:
            now = time.time()
            if self._username and (now - self._last_poll) >= POLL_INTERVAL:
                self._fetch()
            time.sleep(5)

    def _fetch(self):
        if not self._username:
            return
        self._fetching = True
        url = HISCORES_URL.format(
            self._username.replace(" ", "%20"))
        try:
            req = Request(url, headers=_HEADERS)
            with urlopen(req, timeout=10) as resp:
                raw = resp.read().decode("utf-8")
            self._parse(raw)
            self._last_poll = time.time()
            self._error     = ""
            print(f"[Hiscores] Fetched OK for '{self._username}'")
        except URLError as e:
            self._error = f"Network error: {e.reason}"
            print(f"[Hiscores] Fetch failed: {e}")
        except Exception as e:
            self._error = str(e)
            print(f"[Hiscores] Fetch error: {e}")
        finally:
            self._fetching = False

    def _parse(self, raw: str):
        lines = [l.strip() for l in raw.strip().splitlines() if l.strip()]
        # Line 0 is always "Overall" (total rank/level/xp) — always skip it
        if lines:
            lines = lines[1:]
        levelups = []
        with self._lock:
            for i, skill in enumerate(SKILL_ORDER):
                if i >= len(lines):
                    break
                parts = lines[i].split(",")
                if len(parts) < 3:
                    continue
                try:
                    rank  = int(parts[0])
                    level = int(parts[1])
                    xp    = int(parts[2])
                except ValueError:
                    continue

                st = self._skills[skill]
                old_level = st.level

                # Record previous values for XP/hr
                now = time.time()
                if st.xp > 0:
                    st.prev_xp       = st.xp
                    st.prev_time     = st.cur_poll_time if st.cur_poll_time else now - POLL_INTERVAL
                st.cur_poll_time = now

                # Init session baseline on first fetch
                if st.session_start_xp == 0 and xp > 0:
                    st.session_start_xp   = xp
                    st.session_start_time = now

                st.rank  = rank
                st.level = level
                st.xp    = xp

                if level > old_level > 1:
                    levelups.append((skill, level))

        for skill, level in levelups:
            logger.info(f"[Hiscores] LEVEL UP — {skill} is now {level}!")
            if self.on_levelup:
                try:
                    self.on_levelup(skill, level)
                except Exception:
                    pass

        snap = self.snapshot()
        print(f"[Hiscores] Parsed OK — firing on_update (callback={'set' if self.on_update else 'MISSING'})")
        if self.on_update:
            try:
                self.on_update(snap)
            except Exception as e:
                print(f"[Hiscores] on_update error: {e}")

    # ── Accessors ─────────────────────────────────────────────────────────

    def level(self, skill: str) -> int:
        with self._lock:
            return self._skills[skill].level if skill in self._skills else 1

    def xp(self, skill: str) -> int:
        with self._lock:
            return self._skills[skill].xp if skill in self._skills else 0

    def xp_per_hour(self, skill: str) -> int:
        with self._lock:
            return self._skills[skill].xp_per_hour() \
                if skill in self._skills else 0

    @property
    def last_poll(self) -> float:
        return self._last_poll

    @property
    def error(self) -> str:
        return self._error

    @property
    def fetching(self) -> bool:
        return self._fetching

    def snapshot(self) -> List[dict]:
        """Full skill list for the GUI panel."""
        with self._lock:
            out = []
            for skill in SKILL_ORDER:
                st = self._skills[skill]
                out.append({
                    "skill":       skill,
                    "level":       st.level,
                    "xp":          st.xp,
                    "xp_per_hour": st.xp_per_hour(),
                    "session_xp":  st.session_xp(),
                    "rank":        st.rank,
                    "active":      st.session_xp() > 0,
                })
            return out


# ── Username auto-detection ───────────────────────────────────────────────

def detect_username() -> str:
    """
    Try to read the player name from the RuneLite window title.
    Title format: "RuneLite - PlayerName"
    Returns empty string if not found.
    """
    try:
        import win32gui
        results = []
        def _cb(hwnd, _):
            if win32gui.IsWindowVisible(hwnd):
                t = win32gui.GetWindowText(hwnd)
                if t.lower().startswith("runelite"):
                    results.append(t)
        win32gui.EnumWindows(_cb, None)
        for title in results:
            if " - " in title:
                name = title.split(" - ", 1)[1].strip()
                if name:
                    return name
    except Exception:
        pass
    return ""


# ── Shared singleton ──────────────────────────────────────────────────────
_tracker: Optional[HiscoresTracker] = None

def get_tracker() -> HiscoresTracker:
    global _tracker
    if _tracker is None:
        username = detect_username()
        _tracker = HiscoresTracker(username)
        _tracker.load()
        # Fetch immediately so levels are populated before the GUI first renders
        if _tracker.username:
            _tracker._fetch()
    return _tracker
