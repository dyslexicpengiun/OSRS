"""
Antiban
Injects human-like randomness into the script's behaviour:
  - Variable reaction delays after events
  - Occasional camera micro-adjustments
  - Random idle pauses (checking phone, reading chat)
  - Gaussian-distributed action timings

All sleeps here are actual time.sleep() — the script loop should call
these instead of raw sleeps wherever possible.
"""

import logging
import math
import random
import time

logger = logging.getLogger(__name__)


class Antiban:

    def __init__(self, enabled: bool = True):
        self.enabled = enabled
        self._action_count = 0
        self._session_start = time.time()

    # ── Delays ────────────────────────────────────────────────────────

    def reaction_delay(self):
        """
        Simulates the time between seeing an event and reacting to it.
        Human reaction time clusters around 150–350ms with a tail.
        """
        if not self.enabled:
            time.sleep(0.05)
            return
        delay = random.gauss(0.22, 0.07)
        delay = max(0.08, min(0.65, delay))
        time.sleep(delay)

    def action_delay(self, base: float = 0.6):
        """
        Delay between repeated actions (e.g. each woodcutting click).
        Adds gaussian noise around a base value.
        """
        if not self.enabled:
            time.sleep(base)
            return
        delay = random.gauss(base, base * 0.15)
        delay = max(base * 0.5, min(base * 2.0, delay))
        time.sleep(delay)

    def short_pause(self):
        """Very short pause — e.g. between moving mouse and clicking."""
        if not self.enabled:
            return
        time.sleep(random.uniform(0.05, 0.18))

    def maybe_idle(self, chance: float = 0.02):
        """
        Occasionally take a longer pause simulating inattention.
        chance: probability per call (default 2%).
        """
        if not self.enabled:
            return
        if random.random() < chance:
            idle = random.uniform(1.5, 8.0)
            logger.debug(f'[Antiban] Idle pause {idle:.1f}s')
            time.sleep(idle)

    def wait_for_animation(self, base: float = 2.5):
        """
        Wait for a game animation to complete (chopping, mining, etc.)
        Adds jitter so the wait doesn't look robotic.
        """
        if not self.enabled:
            time.sleep(base)
            return
        wait = random.gauss(base, 0.3)
        wait = max(base * 0.7, min(base * 1.5, wait))
        time.sleep(wait)

    # ── Camera ────────────────────────────────────────────────────────

    def maybe_rotate_camera(self, chance: float = 0.08):
        """
        Occasionally nudge the camera with arrow keys or middle-mouse.
        Keeps camera angle slightly varied session-to-session.
        chance: probability per call.
        """
        if not self.enabled:
            return
        if random.random() < chance:
            self._rotate_camera()

    def _rotate_camera(self):
        """Send a small random camera rotation via keyboard."""
        try:
            import win32api, win32con
            keys = [win32con.VK_LEFT, win32con.VK_RIGHT]
            key  = random.choice(keys)
            hold = random.uniform(0.05, 0.25)
            win32api.keybd_event(key, 0, 0, 0)
            time.sleep(hold)
            win32api.keybd_event(key, 0, win32con.KEYEVENTF_KEYUP, 0)
            logger.debug(f'[Antiban] Camera nudge ({hold:.2f}s)')
        except Exception:
            pass

    # ── Misc ──────────────────────────────────────────────────────────

    def on_action(self):
        """Call once per successful action. Triggers periodic behaviours."""
        self._action_count += 1
        self.maybe_idle(chance=0.015)
        self.maybe_rotate_camera(chance=0.06)

    def elapsed_minutes(self) -> float:
        return (time.time() - self._session_start) / 60
