"""
XP Drop Detector  v2
====================
Always-on background thread that reads XP drop text from the RuneLite
game window and feeds the SkillTracker directly — no script required.

RuneLite renders XP drops on the RIGHT side of the viewport as lines like:
    +67 Woodcutting
    +40 Hitpoints
The text is yellow/white on a transparent background.

Strategy
--------
1. Every 250 ms grab the XP drop zone (right ~35% of screen, top ~40%)
2. Diff against the previous frame to detect new content
3. If new pixels found, OCR the changed region for "+NNN SkillName"
4. Parse and feed SkillTracker

The old XPDropDetector class is kept for backwards compatibility with
scripts that still call .detect(frame) directly — it now also feeds
the shared SkillTracker.
"""

from __future__ import annotations

import logging
import os
import re
import sys
import threading
import time
from typing import Callable, Optional, Tuple

import cv2
import numpy as np

logger = logging.getLogger(__name__)

_HERE     = os.path.dirname(os.path.abspath(__file__))
_PKG_ROOT = os.path.dirname(_HERE)
if _PKG_ROOT not in sys.path:
    sys.path.insert(0, _PKG_ROOT)

# ── Zone fractions (relative to game window size) ────────────────────────
XP_ZONE_X_START = 0.60
XP_ZONE_X_END   = 0.98
XP_ZONE_Y_START = 0.00
XP_ZONE_Y_END   = 0.40

WHITE_PIXEL_THRESHOLD = 15
COOLDOWN              = 0.8    # min seconds between drops
POLL_INTERVAL         = 0.25   # how often to grab a frame

# ── Skill name aliases — OCR sometimes misreads ───────────────────────────
_SKILL_ALIASES = {
    "woodcut":     "Woodcutting", "woodcutting": "Woodcutting",
    "mining":      "Mining",
    "fishing":     "Fishing",
    "firemaking":  "Firemaking",  "fire":        "Firemaking",
    "cooking":     "Cooking",
    "smithing":    "Smithing",
    "crafting":    "Crafting",
    "fletching":   "Fletching",
    "herblore":    "Herblore",
    "agility":     "Agility",
    "thieving":    "Thieving",
    "slayer":      "Slayer",
    "farming":     "Farming",
    "runecrafting":"Runecrafting", "rune":        "Runecrafting",
    "construction":"Construction","construct":   "Construction",
    "hunter":      "Hunter",
    "prayer":      "Prayer",
    "magic":       "Magic",
    "attack":      "Attack",
    "strength":    "Strength",
    "defence":     "Defence",    "defense":      "Defence",
    "ranged":      "Ranged",
    "hitpoints":   "Hitpoints",  "hp":           "Hitpoints",
}

_DROP_RE = re.compile(
    r'\+\s*(\d{1,6})\s+([A-Za-z]{3,14})',
    re.IGNORECASE
)


def _normalise_skill(raw: str) -> Optional[str]:
    return _SKILL_ALIASES.get(raw.lower().strip())


def _ensure_tesseract() -> bool:
    try:
        import pytesseract
        if sys.platform == "win32":
            for p in [
                r"C:\Program Files\Tesseract-OCR\tesseract.exe",
                r"C:\Program Files (x86)\Tesseract-OCR\tesseract.exe",
                os.path.expanduser(r"~\AppData\Local\Programs\Tesseract-OCR\tesseract.exe"),
            ]:
                if os.path.isfile(p):
                    pytesseract.pytesseract.tesseract_cmd = p
                    break
        pytesseract.get_tesseract_version()
        return True
    except Exception:
        return False


_tess_ok: Optional[bool] = None

def _tess_ready() -> bool:
    global _tess_ok
    if _tess_ok is None:
        _tess_ok = _ensure_tesseract()
    return _tess_ok


def _ocr_xp_zone(bgr: np.ndarray) -> list[Tuple[str, int]]:
    """
    OCR a BGR image of the XP drop zone.
    Returns list of (skill_name, xp) tuples found.
    """
    if not _tess_ready():
        return []
    try:
        import pytesseract
        from PIL import Image

        gray = cv2.cvtColor(bgr, cv2.COLOR_BGR2GRAY)
        h, w = gray.shape
        big  = cv2.resize(gray, (w * 3, h * 3), interpolation=cv2.INTER_CUBIC)

        # XP drop text is yellow/white — threshold to isolate bright pixels
        _, bright = cv2.threshold(big, 180, 255, cv2.THRESH_BINARY)

        cfg  = "--psm 6 --oem 3 -c tessedit_char_whitelist=+0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz "
        text = pytesseract.image_to_string(Image.fromarray(bright), config=cfg)

        results = []
        for m in _DROP_RE.finditer(text):
            xp    = int(m.group(1))
            skill = _normalise_skill(m.group(2))
            if skill and 1 <= xp <= 100_000:
                results.append((skill, xp))
        return results
    except Exception as e:
        logger.debug(f"[XPDrop] OCR error: {e}")
        return []


# ── Always-on background detector ────────────────────────────────────────

class XPDropWatcher:
    """
    Runs continuously in a background thread.
    Grabs the XP drop zone, diffs frames, OCRs on change,
    and feeds SkillTracker + fires on_drop callback.
    """

    def __init__(self):
        self._running      = False
        self._thread: Optional[threading.Thread] = None
        self._prev_roi: Optional[np.ndarray] = None
        self._last_drop_ts = 0.0
        self._sct          = None
        self.on_drop: Optional[Callable[[str, int, int], None]] = None
        # on_drop(skill, xp, new_level)

    def start(self):
        if self._running:
            return
        self._running = True
        self._thread  = threading.Thread(
            target=self._loop, daemon=True, name="XPDropWatcher")
        self._thread.start()
        logger.info("[XPDrop] Watcher started")

    def stop(self):
        self._running = False

    def _get_sct(self):
        if self._sct is None:
            import mss
            self._sct = mss.mss()
        return self._sct

    def _grab_zone(self) -> Optional[np.ndarray]:
        try:
            from core.capture import get_window_rect
            rect = get_window_rect()
            if rect is None:
                return None
            win_left, win_top, win_w, win_h = rect
            x1 = win_left + int(win_w * XP_ZONE_X_START)
            y1 = win_top  + int(win_h * XP_ZONE_Y_START)
            w  = int(win_w * (XP_ZONE_X_END - XP_ZONE_X_START))
            h  = int(win_h * (XP_ZONE_Y_END  - XP_ZONE_Y_START))
            region = {"left": x1, "top": y1, "width": w, "height": h}
            raw = self._get_sct().grab(region)
            return np.ascontiguousarray(np.array(raw)[:, :, :3])
        except Exception as e:
            logger.debug(f"[XPDrop] Grab error: {e}")
            self._sct = None
            return None

    def _loop(self):
        from core.skill_tracker import SkillTracker
        # Use the shared tracker from BaseScript if available, else own instance
        try:
            from scripts.base_script import BaseScript
            tracker = BaseScript.get_skill_tracker()
        except Exception:
            tracker = SkillTracker()
            tracker.load()

        while self._running:
            try:
                roi = self._grab_zone()
                if roi is None:
                    time.sleep(POLL_INTERVAL)
                    continue

                now = time.time()
                changed = False

                if self._prev_roi is not None and \
                   self._prev_roi.shape == roi.shape and \
                   now - self._last_drop_ts >= COOLDOWN:
                    diff = cv2.absdiff(roi, self._prev_roi)
                    gray = cv2.cvtColor(diff, cv2.COLOR_BGR2GRAY)
                    _, thresh = cv2.threshold(gray, 35, 255, cv2.THRESH_BINARY)
                    if cv2.countNonZero(thresh) >= WHITE_PIXEL_THRESHOLD:
                        changed = True

                self._prev_roi = roi

                if changed:
                    self._last_drop_ts = now
                    drops = _ocr_xp_zone(roi)
                    for skill, xp in drops:
                        levelled  = tracker.record_xp(skill, xp)
                        new_level = tracker.level(skill)
                        logger.debug(
                            f"[XPDrop] +{xp} {skill} "
                            f"(lvl {new_level}{'↑' if levelled else ''})"
                        )
                        if self.on_drop:
                            try:
                                self.on_drop(skill, xp, new_level)
                            except Exception:
                                pass

            except Exception as e:
                logger.debug(f"[XPDrop] Loop error: {e}")
                self._sct = None

            time.sleep(POLL_INTERVAL)


# ── Shared singleton ──────────────────────────────────────────────────────
_watcher: Optional[XPDropWatcher] = None

def get_watcher() -> XPDropWatcher:
    global _watcher
    if _watcher is None:
        _watcher = XPDropWatcher()
    return _watcher


# ── Backwards-compatible XPDropDetector ───────────────────────────────────

class XPDropDetector:
    """
    Legacy per-script detector. Still works as before but now also
    feeds the shared SkillTracker when a skill/xp is known.
    """

    def __init__(self):
        self._prev_roi:     Optional[np.ndarray] = None
        self._last_drop_ts: float = 0.0

    def detect(self, frame: np.ndarray) -> bool:
        if frame is None or frame.size == 0:
            return False
        now = time.time()
        if now - self._last_drop_ts < COOLDOWN:
            return False
        roi = self._get_roi(frame)
        if roi is None:
            return False
        if self._prev_roi is not None and self._prev_roi.shape == roi.shape:
            diff = cv2.absdiff(roi, self._prev_roi)
            gray = cv2.cvtColor(diff, cv2.COLOR_BGR2GRAY)
            _, thresh = cv2.threshold(gray, 40, 255, cv2.THRESH_BINARY)
            if cv2.countNonZero(thresh) >= WHITE_PIXEL_THRESHOLD:
                self._prev_roi     = roi
                self._last_drop_ts = now
                logger.debug("[XP] Drop detected")
                return True
        self._prev_roi = roi
        return False

    def reset(self):
        self._prev_roi     = None
        self._last_drop_ts = 0.0

    def _get_roi(self, frame: np.ndarray) -> Optional[np.ndarray]:
        h, w = frame.shape[:2]
        x1 = int(w * XP_ZONE_X_START)
        x2 = int(w * XP_ZONE_X_END)
        y1 = int(h * XP_ZONE_Y_START)
        y2 = int(h * XP_ZONE_Y_END)
        if x2 <= x1 or y2 <= y1:
            return None
        return frame[y1:y2, x1:x2].copy()
