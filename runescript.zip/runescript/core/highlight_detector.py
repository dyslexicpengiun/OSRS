"""
Highlight Detector
Finds RuneLite object highlight outlines in the game viewport.

RuneLite can draw a coloured outline or filled tile around any object
you configure it to highlight. That colour is user-defined in the
RuneLite Object Markers / NPC Indicators plugins.

This detector:
  1. Converts the frame to HSV
  2. Builds a mask for the target highlight colour (+/- tolerance)
  3. Finds contours in the mask
  4. Returns sorted candidates (nearest to screen centre first)

It works regardless of zoom, camera angle, or scene lighting because
it's matching a synthetic colour that RuneLite paints on top of the
scene — not the object's natural texture.

Usage:
    detector = HighlightDetector('#00FFFF')
    frame    = capture.screenshot()
    targets  = detector.find(frame)
    if targets:
        cx, cy = targets[0].centre
        input.click(cx, cy, window_rect=capture.get_window_rect())
"""

import cv2
import logging
import numpy as np
from dataclasses import dataclass, field
from typing import List, Optional, Tuple

logger = logging.getLogger(__name__)

# How much the hue can vary from the target before we stop matching.
# RuneLite draws solid-colour outlines, but JPEG/screen compression and
# sub-pixel blending slightly shifts pixels at the edges.
HUE_TOLERANCE = 12     # degrees (0–180 in OpenCV)
SAT_TOLERANCE = 50     # 0–255
VAL_MIN       = 60     # ignore very dark pixels (shadow / unlit areas)
VAL_MAX       = 255

# Contour area thresholds — ignore noise and full-screen fills
MIN_AREA = 80      # px² — smaller = probably noise
MAX_AREA = 40_000  # px² — larger = probably wrong colour match


@dataclass
class HighlightTarget:
    centre:    Tuple[int, int]     # (cx, cy) in game-window coordinates
    bbox:      Tuple[int,int,int,int]  # (x, y, w, h)
    area:      float
    contour:   np.ndarray = field(repr=False)
    distance:  float = 0.0        # distance from viewport centre


class HighlightDetector:
    """
    Detects RuneLite highlight outlines of a specific colour.
    The colour can be changed at runtime via set_colour().
    """

    def __init__(self, hex_colour: str = '#00FFFF'):
        self._hsv_ranges: List[Tuple[np.ndarray, np.ndarray]] = []
        self.set_colour(hex_colour)

    # ── Public API ────────────────────────────────────────────────────

    def set_colour(self, hex_colour: str):
        """
        Set the target highlight colour.
        hex_colour: '#RRGGBB' string (as output by the GUI colour picker).
        Can be called at runtime to hot-swap without restarting.
        """
        self._hex = hex_colour
        self._hsv_ranges = self._build_hsv_ranges(hex_colour)
        logger.info(f'[Highlight] Target colour set to {hex_colour}')

    def find(self, frame: np.ndarray,
             min_area: int = MIN_AREA,
             max_area: int = MAX_AREA) -> List[HighlightTarget]:
        """
        Find all highlight contours in the frame.
        Returns a list of HighlightTarget sorted by distance to the
        screen centre (nearest first — most likely the player's target).
        """
        if frame is None or frame.size == 0:
            return []

        mask = self._build_mask(frame)
        if mask is None:
            return []

        # Clean up mask — close small gaps in the outline
        kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3, 3))
        mask   = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel, iterations=2)

        contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        if not contours:
            return []

        fh, fw = frame.shape[:2]
        screen_cx, screen_cy = fw // 2, fh // 2

        targets = []
        for cnt in contours:
            area = cv2.contourArea(cnt)
            if area < min_area or area > max_area:
                continue

            x, y, w, h = cv2.boundingRect(cnt)
            cx = x + w // 2
            cy = y + h // 2
            dist = ((cx - screen_cx) ** 2 + (cy - screen_cy) ** 2) ** 0.5

            targets.append(HighlightTarget(
                centre   = (cx, cy),
                bbox     = (x, y, w, h),
                area     = area,
                contour  = cnt,
                distance = dist,
            ))

        targets.sort(key=lambda t: t.distance)
        return targets

    def find_nearest(self, frame: np.ndarray) -> Optional[HighlightTarget]:
        """Return the single nearest highlight, or None."""
        results = self.find(frame)
        return results[0] if results else None

    def debug_frame(self, frame: np.ndarray) -> np.ndarray:
        """
        Return a copy of the frame with highlight contours drawn in green.
        Useful during development to verify the colour is tuned correctly.
        """
        vis     = frame.copy()
        targets = self.find(frame)
        for t in targets:
            cv2.drawContours(vis, [t.contour], -1, (0, 255, 0), 2)
            cv2.circle(vis, t.centre, 5, (0, 255, 0), -1)
            cv2.rectangle(vis, (t.bbox[0], t.bbox[1]),
                          (t.bbox[0]+t.bbox[2], t.bbox[1]+t.bbox[3]),
                          (0, 200, 0), 1)
        return vis

    # ── Internal ──────────────────────────────────────────────────────

    def _build_mask(self, frame: np.ndarray) -> Optional[np.ndarray]:
        try:
            hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
        except Exception:
            return None

        combined = np.zeros(frame.shape[:2], dtype=np.uint8)
        for lo, hi in self._hsv_ranges:
            combined = cv2.bitwise_or(combined, cv2.inRange(hsv, lo, hi))
        return combined

    @staticmethod
    def _build_hsv_ranges(hex_colour: str) -> List[Tuple[np.ndarray, np.ndarray]]:
        """
        Convert a hex colour to one or two HSV ranges (two needed when
        the hue wraps around red, i.e. hue near 0/180).
        """
        hex_colour = hex_colour.lstrip('#')
        r = int(hex_colour[0:2], 16)
        g = int(hex_colour[2:4], 16)
        b = int(hex_colour[4:6], 16)

        # Convert to OpenCV HSV (H: 0–180, S: 0–255, V: 0–255)
        px  = np.uint8([[[b, g, r]]])
        hsv = cv2.cvtColor(px, cv2.COLOR_BGR2HSV)[0][0]
        h, s, v = int(hsv[0]), int(hsv[1]), int(hsv[2])

        h_lo = h - HUE_TOLERANCE
        h_hi = h + HUE_TOLERANCE
        s_lo = max(0,   s - SAT_TOLERANCE)
        s_hi = min(255, s + SAT_TOLERANCE)

        if h_lo < 0:
            # Wrap: two ranges
            return [
                (np.array([0,          s_lo, VAL_MIN]),
                 np.array([h_hi,       s_hi, VAL_MAX])),
                (np.array([180 + h_lo, s_lo, VAL_MIN]),
                 np.array([180,        s_hi, VAL_MAX])),
            ]
        elif h_hi > 180:
            return [
                (np.array([h_lo,      s_lo, VAL_MIN]),
                 np.array([180,       s_hi, VAL_MAX])),
                (np.array([0,         s_lo, VAL_MIN]),
                 np.array([h_hi - 180,s_hi, VAL_MAX])),
            ]
        else:
            return [
                (np.array([h_lo, s_lo, VAL_MIN]),
                 np.array([h_hi, s_hi, VAL_MAX])),
            ]
