"""
Mouse Input
Sends mouse movements and clicks through the Interception kernel driver
when available, falling back to win32api for development.

Interception operates at the driver level — input appears identical to
a physical mouse, which is the safest approach for external bots.

Install Interception:
    https://github.com/oblitum/Interception  (driver installer)
    pip install interception-python
"""

import logging
import math
import random
import time
from typing import Tuple, Optional

logger = logging.getLogger(__name__)

# ── Backend detection ─────────────────────────────────────────────────
try:
    import interception
    _BACKEND = 'interception'
    logger.info('[Input] Using Interception driver')
except ImportError:
    try:
        import win32api, win32con
        _BACKEND = 'win32'
        logger.warning('[Input] Interception not found — using win32api (less safe)')
    except ImportError:
        _BACKEND = 'none'
        logger.error('[Input] No input backend available. Mouse will not move.')


# ── Bezier mouse movement ─────────────────────────────────────────────

def _bezier_points(p0, p1, p2, p3, steps=40):
    """Cubic bezier curve from p0 to p3 via control points p1, p2."""
    pts = []
    for i in range(steps + 1):
        t  = i / steps
        u  = 1 - t
        x  = u**3*p0[0] + 3*u**2*t*p1[0] + 3*u*t**2*p2[0] + t**3*p3[0]
        y  = u**3*p0[1] + 3*u**2*t*p1[1] + 3*u*t**2*p2[1] + t**3*p3[1]
        pts.append((int(x), int(y)))
    return pts


def _current_pos() -> Tuple[int, int]:
    try:
        import win32api
        return win32api.GetCursorPos()
    except Exception:
        return (0, 0)


def move_to(x: int, y: int,
            duration: float = None,
            window_rect: Optional[Tuple] = None):
    """
    Move the mouse to (x, y) in screen coordinates via a human-like
    bezier curve.

    If window_rect is provided, (x, y) are treated as game-relative
    and converted to screen coordinates first.
    """
    if window_rect:
        x += window_rect[0]
        y += window_rect[1]

    if duration is None:
        # Scale duration with distance — closer = faster, feels natural
        cx, cy = _current_pos()
        dist = math.hypot(x - cx, y - cy)
        duration = max(0.08, min(0.45, dist / 2000))

    cx, cy = _current_pos()

    # Random control points offset from the straight line
    spread = max(20, math.hypot(x - cx, y - cy) * 0.15)
    cp1 = (cx + random.uniform(-spread, spread),
           cy + random.uniform(-spread, spread))
    cp2 = (x  + random.uniform(-spread, spread),
           y  + random.uniform(-spread, spread))

    steps = max(10, int(duration * 120))
    pts   = _bezier_points((cx, cy), cp1, cp2, (x, y), steps)

    interval = duration / len(pts)

    for px, py in pts:
        _raw_move(px, py)
        time.sleep(interval)


def click(x: int = None, y: int = None,
          button: str = 'left',
          window_rect: Optional[Tuple] = None):
    """
    Click at (x, y). If x/y are None, clicks at current cursor position.
    button: 'left' or 'right'
    """
    if x is not None and y is not None:
        move_to(x, y, window_rect=window_rect)

    # Small pre-click jitter — tiny random movement just before clicking
    _micro_jitter()

    _raw_click(button)


def right_click(x: int = None, y: int = None,
                window_rect: Optional[Tuple] = None):
    click(x, y, button='right', window_rect=window_rect)


# ── Raw send ──────────────────────────────────────────────────────────

def _raw_move(x: int, y: int):
    if _BACKEND == 'interception':
        try:
            interception.move_to(x, y)
        except Exception as e:
            logger.debug(f'[Input] Interception move error: {e}')
    elif _BACKEND == 'win32':
        try:
            import win32api
            win32api.SetCursorPos((x, y))
        except Exception:
            pass


def _raw_click(button: str = 'left'):
    if _BACKEND == 'interception':
        try:
            if button == 'left':
                interception.click()
            else:
                interception.right_click()
        except Exception as e:
            logger.debug(f'[Input] Interception click error: {e}')
    elif _BACKEND == 'win32':
        try:
            import win32api, win32con
            if button == 'left':
                win32api.mouse_event(win32con.MOUSEEVENTF_LEFTDOWN,  0, 0)
                time.sleep(random.uniform(0.04, 0.09))
                win32api.mouse_event(win32con.MOUSEEVENTF_LEFTUP,    0, 0)
            else:
                win32api.mouse_event(win32con.MOUSEEVENTF_RIGHTDOWN, 0, 0)
                time.sleep(random.uniform(0.04, 0.09))
                win32api.mouse_event(win32con.MOUSEEVENTF_RIGHTUP,   0, 0)
        except Exception:
            pass


def _micro_jitter():
    """Tiny random movement just before a click — breaks pixel-perfect patterns."""
    cx, cy = _current_pos()
    jx = cx + random.randint(-2, 2)
    jy = cy + random.randint(-2, 2)
    _raw_move(jx, jy)
    time.sleep(random.uniform(0.01, 0.03))
    _raw_move(cx, cy)
