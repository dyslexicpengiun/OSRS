"""
Location Detector  v3
=====================
Reads tile coords from RuneLite "World Location" plugin.
The plugin renders "3089, 3236, 0" as text just below the cursor.

Strategy
--------
1. GetCursorPos()  — absolute screen position
2. mss grab a 260x40 strip just below+right of the cursor tip
3. Two preprocessing passes (adaptive + Otsu) → Tesseract PSM-7
4. Regex match → (x, y, z) → named location

DEBUG MODE (default ON)
-----------------------
Every tick saves three files to  core/detection/debug/ :
   NNNN_raw.png        — the raw screen grab
   NNNN_adaptive.png   — adaptive-threshold version fed to Tesseract
   NNNN_otsu.png       — Otsu version fed to Tesseract
   NNNN_text.txt       — what Tesseract read from each

Open these after a tick (hover over a tile first) to check whether:
  - The crop is landing on the text at all
  - The preprocessing is making the text legible
Tune CROP_Y_OFFSET / CROP_X_OFFSET / CROP_W / CROP_H if needed.
Set DEBUG_SAVE = False once it's working.
"""

from __future__ import annotations

import logging
import os
import re
import threading
import time
from typing import Callable, Optional, Tuple

import cv2
import numpy as np

logger = logging.getLogger(__name__)

# ── Debug ──────────────────────────────────────────────────────────────────
DEBUG_SAVE   = False         # set True temporarily to debug OCR crop/preprocessing
_HERE        = os.path.dirname(os.path.abspath(__file__))
_DEBUG_DIR   = os.path.join(_HERE, "debug")
_debug_n     = 0

# ── Crop geometry (pixels) ─────────────────────────────────────────────────
# The text appears just below and slightly right of the cursor hotspot.
# Tune these if the debug images don't contain the coord text.
CROP_X_OFFSET = 0     # shift crop left/right from cursor x
CROP_Y_OFFSET = 20    # pixels below cursor to start the crop
CROP_W        = 200   # wide enough for "3088, 3235, 0"
CROP_H        = 22    # tight crop — just the text row


# ═══════════════════════════════════════════════════════════════════════════
#  LOCATION TABLE  (x_min, x_max, y_min, y_max, plane, name)  plane=-1=any
# ═══════════════════════════════════════════════════════════════════════════

_LOCATIONS = [
    (3216, 3230, 3210, 3224, -1, "Lumbridge Castle"),
    (3200, 3250, 3190, 3240, -1, "Lumbridge"),
    (3079, 3100, 3265, 3280, -1, "Draynor Willows"),
    (3096, 3107, 3244, 3258, -1, "Draynor Oak Trees"),
    (3071, 3110, 3240, 3270, -1, "Draynor Village"),
    (3010, 3055, 3155, 3210, -1, "Port Sarim"),
    (2960, 3000, 3335, 3365, -1, "Falador East Bank"),
    (3005, 3020, 3370, 3385, -1, "Falador Park"),
    (2926, 2960, 3338, 3360, -1, "Falador West Bank"),
    (2950, 3050, 3310, 3400, -1, "Falador"),
    (3073, 3095, 3415, 3430, -1, "Barbarian Village"),
    (3091, 3098, 3488, 3496, -1, "Edgeville Bank"),
    (3085, 3105, 3483, 3510, -1, "Edgeville"),
    (3200, 3230, 3460, 3490, -1, "Varrock East Bank"),
    (3180, 3200, 3433, 3448, -1, "Varrock West Bank"),
    (3206, 3218, 3416, 3426, -1, "Varrock Square"),
    (3150, 3265, 3380, 3510, -1, "Varrock"),
    (3155, 3175, 3480, 3496, -1, "Grand Exchange"),
    (3000, 3400, 3520, 3960,  0, "Wilderness"),

    # ── South of Draynor / between Draynor & Lumbridge ──
    (3060, 3120, 3220, 3265, -1, "Draynor Village South"),
    (3060, 3130, 3190, 3225, -1, "Draynor Manor"),
    (3110, 3160, 3220, 3260, -1, "Draynor / Lumbridge Road"),
    (3120, 3200, 3230, 3270, -1, "Lumbridge Swamp"),
    (3130, 3210, 3195, 3240, -1, "Lumbridge Swamp"),
    (3070, 3120, 3155, 3200, -1, "Wizards Tower Area"),

    # ── Lumbridge extended ──
    (3200, 3270, 3170, 3230, -1, "Lumbridge"),
    (3215, 3240, 3200, 3230, -1, "Lumbridge Castle"),

    # ── Woodcutting Guild ──
    (1563, 1581, 3480, 3498, -1, "Woodcutting Guild"),

    # ── Prifddinas ──
    (3250, 3290, 6080, 6120, -1, "Prifddinas"),

    # ── Fossil Island ──
    (3760, 3820, 3840, 3900, -1, "Fossil Island"),

    # ── Zeah / Great Kourend ──
    (1620, 1680, 3665, 3710, -1, "Shayzien"),
    (1780, 1820, 3840, 3880, -1, "Arceuus"),
    (1700, 1760, 3790, 3840, -1, "Lovakengj"),
    (1760, 1820, 3690, 3740, -1, "Hosidius"),
    (1720, 1760, 3630, 3665, -1, "Piscarillius"),
    (1628, 1670, 3738, 3760, -1, "Kourend Castle"),

    # ── Slayer dungeons ──
    (2700, 2760, 9990, 10040, -1, "Slayer Tower Basement"),
    (3420, 3460, 3530, 3570, -1, "Slayer Tower"),

    # ── Popular training spots ──
    (2840, 2870, 3540, 3560, -1, "Crabs - Rellekka"),
    (1735, 1760, 3455, 3475, -1, "Sand Crabs"),
    (1750, 1810, 3460, 3490, -1, "Sand Crabs Area"),
    (2602, 2630, 3070, 3085, -1, "Nightmare Zone"),
    (3390, 3440, 3890, 3930,  0, "Deep Wilderness"),

    # ── Banks ──
    (3092, 3099, 3240, 3247, -1, "Draynor Bank"),
    (3269, 3272, 3166, 3172, -1, "Al Kharid Bank"),
    (2609, 2616, 3330, 3336, -1, "East Ardougne Bank"),
    (2520, 2527, 3330, 3336, -1, "West Ardougne Bank"),
    (2443, 2448, 3082, 3088, -1, "Ape Atoll Bank"),
    (3290, 3310, 3170, 3200, -1, "Al Kharid Mine"),
    (3265, 3315, 3140, 3210, -1, "Al Kharid"),
    (2945, 2985, 3200, 3240, -1, "Rimmington"),
    (2836, 2847, 3427, 3438, -1, "Catherby Fishing Spot"),
    (2800, 2860, 3425, 3450, -1, "Catherby"),
    (2724, 2730, 3489, 3495, -1, "Seers Bank"),
    (2695, 2740, 3460, 3500, -1, "Seers Village"),
    (2646, 2686, 3277, 3310, -1, "East Ardougne"),
    (2574, 2620, 3277, 3310, -1, "West Ardougne"),
    (2745, 2768, 3476, 3500, -1, "Camelot"),
    (2577, 2617, 3085, 3110, -1, "Yanille"),
    (2657, 2673, 2638, 2655, -1, "Pest Control"),
    (2598, 2622, 3412, 3430, -1, "Fishing Guild"),
    (3016, 3060, 9716, 9750, -1, "Mining Guild"),
    (2920, 2970, 3140, 3180, -1, "Musa Point"),
    (2746, 2806, 3138, 3175, -1, "Brimhaven"),
    (2793, 2930, 3085, 3150, -1, "Karamja"),
    (3481, 3515, 3220, 3245, -1, "Canifis"),
    (3400, 3600, 3150, 3400, -1, "Morytania"),
    (3311, 3395, 3215, 3275, -1, "Duel Arena"),
    (2418, 2475, 3475, 3520, -1, "Tree Gnome Stronghold"),
    (2723, 2730, 3488, 3498, -1, "Seers Rooftop Course"),
    (3237, 3246, 3410, 3420, -1, "Varrock Rooftop Course"),
    (3086, 3097, 3492, 3502, -1, "Edgeville Rooftop Course"),
    (3551, 3580, 3280, 3310, -1, "Barrows"),
    (2875, 2940, 5295, 5375, -1, "God Wars Dungeon"),
    (2265, 2278, 3072, 3082, -1, "Zulrah's Shrine"),
    (2605, 2620, 3111, 3126, -1, "Nightmare Zone"),
    (1620, 1645, 3985, 4010, -1, "Wintertodt"),

    # ── Fine-grained Draynor ──────────────────────────────────────────────
    (3076, 3102, 3262, 3282, -1, "Draynor Willows"),
    (3088, 3101, 3238, 3250, -1, "Draynor Bank"),
    (3076, 3115, 3238, 3268, -1, "Draynor Village"),
    (3060, 3135, 3195, 3245, -1, "Draynor Manor Area"),

    # ── Fine-grained Varrock / GE ─────────────────────────────────────────
    (3160, 3168, 3476, 3490, -1, "Grand Exchange"),
    (3180, 3205, 3432, 3448, -1, "Varrock West Bank"),
    (3250, 3258, 3419, 3427, -1, "Varrock East Bank"),

    # ── Wilderness tiers ──────────────────────────────────────────────────
    (2940, 3400, 3520, 3555,  0, "Wilderness Level 1-5"),
    (2940, 3400, 3555, 3630,  0, "Wilderness Level 6-20"),
    (2940, 3400, 3630, 3760,  0, "Wilderness Level 21-40"),
    (2940, 3400, 3760, 3960,  0, "Deep Wilderness"),

    # ── Broad catch-alls (large area = last resort) ───────────────────────
    (3060, 3200, 3130, 3240, -1, "South Misthalin"),
    (3130, 3330, 3130, 3230, -1, "Lumbridge Area"),
    (2800, 3060, 3130, 3400, -1, "West of Draynor"),
    (3060, 3200, 3380, 3530, -1, "North of Varrock"),
    (2500, 2800, 3050, 3500, -1, "Kandarin"),
    (2800, 3060, 3400, 3520, -1, "North West Misthalin"),
    (3200, 3550, 3130, 3520, -1, "Eastern Misthalin"),
    (1500, 1900, 3500, 4100, -1, "Great Kourend"),
    (2370, 2560, 3410, 3580, -1, "North Kandarin"),
    (3400, 3600, 3130, 3520, -1, "Morytania"),
    (2800, 3400, 2900, 3130, -1, "Karamja / South"),
    (2200, 2500, 3050, 3450, -1, "Far West"),
    (3550, 3800, 3130, 3600, -1, "Far East"),
]


# ── Dynamic location table ────────────────────────────────────────────────
# Loaded from data/locations.json if present (generated by fetch_areas.py).
# Falls back to the built-in _LOCATIONS table above.

_ACTIVE_LOCATIONS = None

def _find_locations_json() -> str:
    """Search several candidate paths to find data/locations.json."""
    # Try __file__-relative paths first
    here = os.path.dirname(os.path.abspath(__file__))
    candidates = [
        os.path.join(here, "..", "..", "data", "locations.json"),
        os.path.join(here, "..", "data", "locations.json"),
        os.path.join(here, "..", "..", "..", "data", "locations.json"),
    ]
    # Always also try relative to cwd — this is the most reliable on Windows
    # when main.py is launched from the project root
    candidates.append(os.path.join(os.getcwd(), "data", "locations.json"))
    for c in candidates:
        p = os.path.normpath(c)
        logger.debug("[Location] checking %s -> %s", p, os.path.exists(p))
        if os.path.exists(p):
            return p
    logger.warning("[Location] locations.json not found in any candidate path")
    return None

def _load_locations() -> list:
    global _ACTIVE_LOCATIONS
    if _ACTIVE_LOCATIONS is not None:
        return _ACTIVE_LOCATIONS
    try:
        import json as _json
        path = _find_locations_json()
        if path:
            with open(path, encoding="utf-8") as f:
                data = _json.load(f)
            _ACTIVE_LOCATIONS = [tuple(e) for e in data]
            msg = f"[Location] Loaded {len(_ACTIVE_LOCATIONS)} areas from {path}"
            logger.info(msg)
            print(msg)
            return _ACTIVE_LOCATIONS
        else:
            msg = f"[Location] locations.json not found — using built-in table ({len(_LOCATIONS)} entries). cwd={os.getcwd()}"
            logger.warning(msg)
            print(msg)
    except Exception as e:
        logger.warning("[Location] Could not load locations.json: %s", e)
    _ACTIVE_LOCATIONS = _LOCATIONS
    return _ACTIVE_LOCATIONS


def lookup_location(x: int, y: int, z: int = 0) -> str:
    """Returns the most specific (smallest area) matching location."""
    best_name = ""
    best_area = float("inf")
    for xmin, xmax, ymin, ymax, plane, name in _load_locations():
        if xmin <= x <= xmax and ymin <= y <= ymax and (plane == -1 or plane == z):
            area = (xmax - xmin) * (ymax - ymin)
            if area < best_area:
                best_area = area
                best_name = name
    return best_name


def format_coords(x: int, y: int, z: int) -> str:
    return f"{x} · {y} · Plane {z}"


# ═══════════════════════════════════════════════════════════════════════════
#  TESSERACT
# ═══════════════════════════════════════════════════════════════════════════

_tess_ok: Optional[bool] = None


def _ensure_tesseract() -> bool:
    global _tess_ok
    if _tess_ok is not None:
        return _tess_ok
    try:
        import pytesseract, sys
        if sys.platform == "win32":
            for _p in [
                r"C:\Program Files\Tesseract-OCR\tesseract.exe",
                r"C:\Program Files (x86)\Tesseract-OCR\tesseract.exe",
                os.path.expanduser(r"~\AppData\Local\Programs\Tesseract-OCR\tesseract.exe"),
            ]:
                if os.path.isfile(_p):
                    pytesseract.pytesseract.tesseract_cmd = _p
                    logger.info(f"[Location] Tesseract binary: {_p}")
                    break
        pytesseract.get_tesseract_version()
        _tess_ok = True
        logger.info("[Location] Tesseract ready")
    except Exception as e:
        _tess_ok = False
        logger.warning(f"[Location] Tesseract unavailable: {e}")
    return _tess_ok


# ═══════════════════════════════════════════════════════════════════════════
#  SCREEN CAPTURE
# ═══════════════════════════════════════════════════════════════════════════

def _cursor_pos() -> Optional[Tuple[int, int]]:
    try:
        import win32api
        return win32api.GetCursorPos()
    except Exception:
        pass
    try:
        import ctypes
        class _PT(ctypes.Structure):
            _fields_ = [("x", ctypes.c_long), ("y", ctypes.c_long)]
        pt = _PT()
        ctypes.windll.user32.GetCursorPos(ctypes.byref(pt))
        return pt.x, pt.y
    except Exception:
        return None


# Reuse a single mss instance across ticks for speed
_sct = None

def _get_sct():
    global _sct
    if _sct is None:
        import mss
        _sct = mss.mss()
    return _sct


def _grab(cx: int, cy: int) -> Optional[np.ndarray]:
    """
    Grab a tall strip below the cursor and scan it for the coord tooltip.
    The tooltip appears at a variable Y offset depending on what the cursor
    is over, so we grab a taller region and slide a window to find it.
    """
    try:
        sct = _get_sct()
        # Grab a taller strip so we catch the tooltip wherever it appears
        region = {
            "left":   cx + CROP_X_OFFSET,
            "top":    cy,
            "width":  CROP_W,
            "height": 60,   # scan 60px below cursor
        }
        raw   = sct.grab(region)
        frame = np.ascontiguousarray(np.array(raw)[:, :, :3])

        # Slide a CROP_H window down the strip looking for dark background
        # (the tooltip background is near-black ~#282828)
        best_row = CROP_Y_OFFSET   # default fallback
        gray = np.mean(frame, axis=2)
        for row in range(0, 60 - CROP_H, 2):
            strip_mean = np.mean(gray[row:row+CROP_H, :CROP_W//3])
            if strip_mean < 45:   # dark background found
                best_row = row
                break

        return frame[best_row:best_row + CROP_H, :]
    except Exception as e:
        logger.debug(f"[Location] Grab error: {e}")
        # Reset sct on error so it gets recreated next tick
        global _sct
        _sct = None
        return None


# ═══════════════════════════════════════════════════════════════════════════
#  OCR PIPELINE
# ═══════════════════════════════════════════════════════════════════════════

_COORD_RE  = re.compile(r'(\d{3,5})[,\s]+(\d{3,5})[,\s]+([0-3])')
_TESS_CFG  = "--psm 7 --oem 3 -c tessedit_char_whitelist=0123456789, "


def _preprocess(bgr: np.ndarray):
    """Return (adaptive_thresh, otsu_thresh) — two attempts at clean B&W."""
    gray = cv2.cvtColor(bgr, cv2.COLOR_BGR2GRAY)
    # Scale up 4× — Tesseract needs text ≥20px tall; game renders ~11px
    h, w = gray.shape
    big  = cv2.resize(gray, (w * 4, h * 4), interpolation=cv2.INTER_CUBIC)
    big  = cv2.GaussianBlur(big, (3, 3), 0)

    adaptive = cv2.adaptiveThreshold(
        big, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
        cv2.THRESH_BINARY, blockSize=15, C=8)

    _, otsu = cv2.threshold(
        big, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)

    return adaptive, otsu


def _run_ocr(bgr: np.ndarray) -> Optional[Tuple[int, int, int]]:
    global _debug_n
    if not _ensure_tesseract():
        return None
    try:
        import pytesseract
        from PIL import Image

        adaptive, otsu = _preprocess(bgr)
        text_a = pytesseract.image_to_string(Image.fromarray(adaptive), config=_TESS_CFG).strip()
        text_o = pytesseract.image_to_string(Image.fromarray(otsu),     config=_TESS_CFG).strip()

        if DEBUG_SAVE:
            _debug_n += 1
            try:
                os.makedirs(_DEBUG_DIR, exist_ok=True)
                cv2.imwrite(os.path.join(_DEBUG_DIR, f"{_debug_n:04d}_raw.png"),      bgr)
                cv2.imwrite(os.path.join(_DEBUG_DIR, f"{_debug_n:04d}_adaptive.png"), adaptive)
                cv2.imwrite(os.path.join(_DEBUG_DIR, f"{_debug_n:04d}_otsu.png"),     otsu)
                with open(os.path.join(_DEBUG_DIR, f"{_debug_n:04d}_text.txt"), "w") as f:
                    f.write(f"adaptive: {repr(text_a)}\notsu:     {repr(text_o)}\n")
            except Exception:
                pass

        logger.debug(f"[Location] OCR  adaptive={repr(text_a)}  otsu={repr(text_o)}")

        for text in (text_a, text_o):
            m = _COORD_RE.search(text)
            if m:
                x, y, z = int(m.group(1)), int(m.group(2)), int(m.group(3))
                if 1500 <= x <= 4200 and 2500 <= y <= 11000 and 0 <= z <= 3:
                    return x, y, z

    except Exception as e:
        logger.debug(f"[Location] OCR error: {e}")
    return None


# ═══════════════════════════════════════════════════════════════════════════
#  DETECTOR
# ═══════════════════════════════════════════════════════════════════════════

class LocationDetector:
    def __init__(self, interval: float = 0.5):
        self.interval  = interval
        self.on_update: Optional[Callable] = None
        self._coords:   Optional[Tuple[int,int,int]] = None
        self._name:     str = ""
        self._raw:      str = "\u2014 \u00b7 \u2014 \u00b7 \u2014"
        self._running   = False
        self._thread:   Optional[threading.Thread] = None
        self._lock      = threading.Lock()

    @property
    def coords(self):
        with self._lock: return self._coords

    @property
    def location_name(self):
        with self._lock: return self._name

    @property
    def raw_text(self):
        with self._lock: return self._raw

    def start(self):
        if self._running:
            return
        self._running = True
        self._thread  = threading.Thread(
            target=self._loop, daemon=True, name="LocationDetector")
        self._thread.start()
        logger.info(f"[Location] Started  interval={self.interval}s  debug={DEBUG_SAVE}"
                    f"\n           debug images -> {_DEBUG_DIR}")

    def stop(self):
        self._running = False

    def _loop(self):
        while self._running:
            try:
                self._tick()
            except Exception as e:
                logger.debug(f"[Location] tick error: {e}")
            time.sleep(self.interval)

    def _tick(self):
        # Skip OCR if coords were recently pushed via update_from_coords()
        # (i.e. RSEye is live) — avoids bad OCR reads overwriting good data.
        with self._lock:
            last_push = getattr(self, "_last_push", 0)
        import time as _t
        if _t.time() - last_push < 3.0:
            return

        result = None

        pos = _cursor_pos()
        if pos is not None:
            frame = _grab(*pos)
            if frame is not None:
                result = _run_ocr(frame)

        if result is None:
            return

        x, y, z = result

        # Only push update when coords actually changed
        with self._lock:
            if (x, y, z) == self._coords:
                return
            name = lookup_location(x, y, z)
            raw  = format_coords(x, y, z)
            self._coords = (x, y, z)
            self._name   = name
            self._raw    = raw

        logger.debug(f"[Location] {raw}  ->  '{name or 'unknown'}'")
        if self.on_update:
            try:
                self.on_update((x, y, z), name, raw)
            except Exception as e:
                logger.debug(f"[Location] on_update error: {e}")

    def update_from_coords(self, x: int, y: int, z: int = 0):
        """Push a known tile coordinate directly, bypassing OCR."""
        import time as _t
        name = lookup_location(x, y, z)
        raw  = format_coords(x, y, z)
        with self._lock:
            if (x, y, z) == self._coords:
                self._last_push = _t.time()
                return
            self._coords    = (x, y, z)
            self._name      = name
            self._raw       = raw
            self._last_push = _t.time()
        if self.on_update:
            try:
                self.on_update((x, y, z), name, raw)
            except Exception:
                pass

    # ── Script-facing spatial helpers ─────────────────────────────────────

    def is_near(self, x: int, y: int, radius: int = 5,
                plane: Optional[int] = None) -> bool:
        """
        Returns True if the current tile is within `radius` squares of (x, y).
        If `plane` is given, also checks the plane matches.
        Scripts should use tile coords directly rather than location names.

        Example:
            if detector.is_near(3088, 3245, radius=3):
                # close to Draynor Bank deposit box
        """
        with self._lock:
            coords = self._coords
        if coords is None:
            return False
        cx, cy, cz = coords
        if plane is not None and cz != plane:
            return False
        return abs(cx - x) <= radius and abs(cy - y) <= radius

    def is_in_region(self, x_min: int, x_max: int,
                     y_min: int, y_max: int,
                     plane: Optional[int] = None) -> bool:
        """
        Returns True if the current tile is inside the given bounding box.
        All bounds are inclusive.  If `plane` is given, also checks plane.

        Example:
            if detector.is_in_region(3085, 3095, 3240, 3250):
                # inside Draynor bank area
        """
        with self._lock:
            coords = self._coords
        if coords is None:
            return False
        cx, cy, cz = coords
        if plane is not None and cz != plane:
            return False
        return x_min <= cx <= x_max and y_min <= cy <= y_max

    def distance_to(self, x: int, y: int) -> Optional[float]:
        """
        Chebyshev distance (tiles) to (x, y), or None if position unknown.
        Chebyshev matches OSRS pathfinding — diagonal counts as 1 step.
        """
        with self._lock:
            coords = self._coords
        if coords is None:
            return None
        cx, cy, _ = coords
        return max(abs(cx - x), abs(cy - y))

    def distance_euclidean(self, x: int, y: int) -> Optional[float]:
        """Euclidean (straight-line) distance in tiles to (x, y)."""
        with self._lock:
            coords = self._coords
        if coords is None:
            return None
        cx, cy, _ = coords
        return ((cx - x) ** 2 + (cy - y) ** 2) ** 0.5
