# core/detection
