"""
MinimapTracker — visual dot detector for nearby NPCs/players/items.

Position is now sourced from PositionTracker (rseye-connector) rather than
OCR. This module focuses solely on what it's actually good at: detecting
coloured dots around the player on the minimap image.

Usage:
    from core.minimap import MinimapTracker
    tracker = MinimapTracker()
    frame = tracker.get_frame()          # clean masked BGR frame
    dots  = tracker.get_dots(frame)      # nearby entities as MinimapDot list
    # Player world position — exact, from rseye-connector:
    pos   = tracker.world_position       # (x, y, plane) or None
"""

import cv2
import logging
import numpy as np
from dataclasses import dataclass
from typing import List, Optional, Tuple

from core.capture import capture_minimap

logger = logging.getLogger(__name__)

# ── Constants ──────────────────────────────────────────────────────────────
CAPTURE_SIZE  = 154    # px — calibrated capture rect diameter
MINIMAP_SCALE = 4      # game tiles per minimap pixel (approximate, varies with zoom)

# Dot colour profiles (HSV)
_DOT_PROFILES = [
    (np.array([  0,   0, 200]), np.array([180,  30, 255]), 'player'),
    (np.array([ 20, 100, 180]), np.array([ 35, 255, 255]), 'npc'),
    (np.array([  0, 150, 150]), np.array([ 10, 255, 255]), 'hostile'),
    (np.array([ 85, 100, 150]), np.array([100, 255, 255]), 'highlighted'),
]


@dataclass
class MinimapDot:
    label:       str
    position:    Tuple[int, int]        # (dx, dy) pixels relative to player centre
    world_pos:   Optional[Tuple[int, int]] = None  # (wx, wy) if world position known
    colour:      Tuple[int, int, int] = (200, 200, 200)


class MinimapTracker:
    """
    Captures the minimap, masks it to the circle, detects nearby entity dots.
    World position comes from PositionTracker — no OCR needed.
    """

    def __init__(self):
        self._circle_centre: Optional[Tuple[int, int]] = None
        self._circle_radius: Optional[int]             = None
        self._mask:          Optional[np.ndarray]      = None
        self._pos_tracker                              = None
        self._init_pos_tracker()

    def _init_pos_tracker(self):
        try:
            from core.position_tracker import get_tracker
            self._pos_tracker = get_tracker()
        except Exception as e:
            logger.debug(f"[Minimap] PositionTracker unavailable: {e}")

    # ── Public API ──────────────────────────────────────────────────────────

    @property
    def world_position(self) -> Optional[Tuple[int, int, int]]:
        """Current player world position (x, y, plane) from rseye-connector."""
        if self._pos_tracker is None:
            return None
        try:
            return self._pos_tracker.position
        except Exception:
            return None

    @property
    def world_xy(self) -> Optional[Tuple[int, int]]:
        """(x, y) world tile coords or None."""
        pos = self.world_position
        return (pos[0], pos[1]) if pos else None

    def get_frame(self) -> Optional[np.ndarray]:
        """Capture and return a clean circular-masked BGR minimap frame."""
        raw = capture_minimap()
        if raw is None:
            return None
        self._ensure_circle(raw)
        return self._apply_mask(raw)

    def get_dots(self, frame: np.ndarray) -> List[MinimapDot]:
        """
        Detect coloured entity dots in a masked minimap frame.
        Returns MinimapDot list with pixel offsets from player centre.
        If world position is known, also provides world tile coords.
        """
        if self._circle_centre is None:
            self._ensure_circle(frame)

        dots  = []
        hsv   = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
        cx, cy = self._circle_centre
        wxy   = self.world_xy

        for lo, hi, label in _DOT_PROFILES:
            mask    = cv2.inRange(hsv, lo, hi)
            kernel  = np.ones((2, 2), np.uint8)
            cleaned = cv2.erode(mask, kernel, iterations=1)
            contours, _ = cv2.findContours(cleaned, cv2.RETR_EXTERNAL,
                                           cv2.CHAIN_APPROX_SIMPLE)
            for cnt in contours:
                area = cv2.contourArea(cnt)
                if area < 3 or area > 80:
                    continue
                mx, my, mw, mh = cv2.boundingRect(cnt)
                dot_x = mx + mw // 2
                dot_y = my + mh // 2
                dx, dy = dot_x - cx, dot_y - cy
                bgr    = tuple(int(v) for v in frame[dot_y, dot_x])

                # Convert pixel offset → world tile offset if position known
                world_pos = None
                if wxy is not None:
                    # Minimap: 1px ≈ MINIMAP_SCALE tiles; Y axis inverted
                    world_pos = (wxy[0] + dx, wxy[1] - dy)

                dots.append(MinimapDot(
                    label     = label,
                    position  = (dx, dy),
                    world_pos = world_pos,
                    colour    = bgr,
                ))
        return dots

    def get_nearby_entities(self) -> List[MinimapDot]:
        """Convenience: capture frame and return dots in one call."""
        frame = self.get_frame()
        if frame is None:
            return []
        return self.get_dots(frame)

    def save_debug(self, path: str = 'minimap_tracker_debug.png'):
        """Save annotated debug frame."""
        frame = self.get_frame()
        if frame is None:
            logger.warning('[Minimap] Could not capture for debug')
            return

        vis    = frame.copy()
        cx, cy = self._circle_centre or (CAPTURE_SIZE // 2, CAPTURE_SIZE // 2)
        r      = self._circle_radius  or (CAPTURE_SIZE // 2 - 1)
        dots   = self.get_dots(frame)
        pos    = self.world_position

        cv2.circle(vis, (cx, cy), r, (0, 255, 0), 1)
        cv2.drawMarker(vis, (cx, cy), (0, 255, 255), cv2.MARKER_CROSS, 12, 1)

        colour_map = {
            'player':      (255, 255, 255),
            'npc':         (0,   255, 255),
            'hostile':     (0,   0,   255),
            'highlighted': (255, 255,   0),
        }
        for dot in dots:
            dx = cx + dot.position[0]
            dy = cy + dot.position[1]
            cv2.circle(vis, (dx, dy), 3,
                       colour_map.get(dot.label, (200, 200, 200)), -1)
            if dot.world_pos:
                cv2.putText(vis, f'{dot.world_pos}', (dx + 4, dy),
                            cv2.FONT_HERSHEY_PLAIN, 0.6, (200, 200, 200), 1)

        cv2.imwrite(path, vis)
        pos_str = f'({pos[0]},{pos[1]},z{pos[2]})' if pos else 'unknown'
        logger.info(f'[Minimap] Debug saved — player world pos: {pos_str}  '
                    f'{len(dots)} dots')

    # ── Internal ────────────────────────────────────────────────────────────

    def _ensure_circle(self, raw: np.ndarray):
        if self._circle_centre is not None:
            return
        import math
        gray   = cv2.cvtColor(raw, cv2.COLOR_BGR2GRAY)
        h, w   = gray.shape
        cx, cy = w // 2, h // 2
        border_r = None
        prev_avg  = None
        for r in range(50, w // 2):
            vals = [
                int(gray[int(cy + r * math.sin(math.radians(a))),
                          int(cx + r * math.cos(math.radians(a)))])
                for a in range(0, 360, 10)
                if (0 <= int(cy + r * math.sin(math.radians(a))) < h and
                    0 <= int(cx + r * math.cos(math.radians(a))) < w)
            ]
            if not vals:
                continue
            avg = sum(vals) / len(vals)
            if prev_avg is not None and prev_avg > 50 and avg < 30:
                border_r = r
                break
            prev_avg = avg

        if border_r and 60 < border_r < 82:
            self._circle_centre = (cx, cy)
            self._circle_radius = border_r - 1
            logger.info(f'[Minimap] Circle detected: centre=({cx},{cy}) r={border_r-1}')
        else:
            self._circle_centre = (CAPTURE_SIZE // 2, CAPTURE_SIZE // 2)
            self._circle_radius = 74
            logger.info('[Minimap] Circle: using calibrated constants centre=(77,77) r=74')

        self._mask = self._build_mask(self._circle_centre, self._circle_radius)

    def _build_mask(self, centre, radius) -> np.ndarray:
        mask = np.zeros((CAPTURE_SIZE, CAPTURE_SIZE), dtype=np.uint8)
        cv2.circle(mask, centre, radius, 255, -1)
        return mask

    def _apply_mask(self, frame: np.ndarray) -> np.ndarray:
        if frame.shape[:2] != (CAPTURE_SIZE, CAPTURE_SIZE):
            frame = cv2.resize(frame, (CAPTURE_SIZE, CAPTURE_SIZE))
        if self._mask is None:
            return frame
        out = frame.copy()
        out[self._mask == 0] = 0
        return out
