"""
Settings Store
==============
Thin JSON persistence layer for GUI settings.
Stored at  <pkg_root>/data/settings.json

Usage
-----
    from core.settings_store import SettingsStore
    store = SettingsStore()
    store.load()

    val = store.get("rl_port", 8080)
    store.set("rl_port", 9090)   # auto-saves
    store.save()                 # explicit save
"""

from __future__ import annotations

import json
import logging
import os
from typing import Any

logger = logging.getLogger(__name__)

_HERE      = os.path.dirname(os.path.abspath(__file__))
_PKG_ROOT  = os.path.dirname(_HERE)
_DATA_DIR  = os.path.join(_PKG_ROOT, "data")
_SAVE_FILE = os.path.join(_DATA_DIR, "settings.json")

DEFAULTS: dict = {
    # RuneLite HTTP
    "rl_host":       "http://localhost",
    "rl_port":       8080,

    # Polling intervals
    "rl_poll_interval":  2.0,
    "loc_poll_interval": 0.5,

    # Hiscores
    "username": "",

    # Tesseract
    "tesseract_path": r"C:\Program Files\Tesseract-OCR\tesseract.exe",

    # Logging
    "log_level": "INFO",

    # Antiban
    "antiban_intensity": 1.0,

    # Appearance
    "opacity":     1.0,
    "font_scale":  1.0,
}


class SettingsStore:
    def __init__(self, path: str = _SAVE_FILE):
        self._path = path
        self._data: dict = DEFAULTS.copy()

    def load(self) -> "SettingsStore":
        try:
            if os.path.isfile(self._path):
                with open(self._path, encoding="utf-8") as f:
                    saved = json.load(f)
                self._data = {**DEFAULTS, **saved}
                logger.debug(f"[Settings] Loaded from {self._path}")
        except Exception as e:
            logger.warning(f"[Settings] Load failed: {e}")
        return self

    def save(self):
        try:
            os.makedirs(os.path.dirname(self._path), exist_ok=True)
            with open(self._path, "w", encoding="utf-8") as f:
                json.dump(self._data, f, indent=2)
            logger.debug(f"[Settings] Saved to {self._path}")
        except Exception as e:
            logger.warning(f"[Settings] Save failed: {e}")

    def get(self, key: str, default: Any = None) -> Any:
        return self._data.get(key, DEFAULTS.get(key, default))

    def set(self, key: str, value: Any, autosave: bool = True):
        self._data[key] = value
        if autosave:
            self.save()

    def all(self) -> dict:
        return dict(self._data)


# Module-level singleton
_store: SettingsStore | None = None


def get_store() -> SettingsStore:
    global _store
    if _store is None:
        _store = SettingsStore()
        _store.load()
    return _store
