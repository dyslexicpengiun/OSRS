"""
Skill Tracker
=============
Tracks XP, levels, and XP/hr for all OSRS skills across sessions.
Persists to  <pkg_root>/data/skill_tracker.json  on every update.

Usage
-----
    tracker = SkillTracker()
    tracker.load()                          # restore last session
    tracker.record_xp("Woodcutting", 67)    # call on every XP gain
    level   = tracker.level("Woodcutting")
    xphr    = tracker.xp_per_hour("Woodcutting")
    tracker.save()
"""

from __future__ import annotations

import json
import logging
import os
import time
from collections import deque
from typing import Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)

_HERE      = os.path.dirname(os.path.abspath(__file__))
_PKG_ROOT  = os.path.dirname(_HERE)
_DATA_DIR  = os.path.join(_PKG_ROOT, "data")
_SAVE_FILE = os.path.join(_DATA_DIR, "skill_tracker.json")

# ── OSRS XP table ─────────────────────────────────────────────────────────
# Index = level, value = XP required to reach that level
_XP_FOR_LEVEL: List[int] = [
    0, 0, 83, 174, 276, 388, 512, 650, 801, 969, 1154,
    1358, 1584, 1833, 2107, 2411, 2746, 3115, 3523, 3973, 4470,
    5018, 5624, 6291, 7028, 7842, 8740, 9730, 10824, 12031, 13363,
    14833, 16456, 18247, 20224, 22406, 24815, 27473, 30408, 33648, 37224,
    41171, 45529, 50339, 55649, 61512, 67983, 75127, 83014, 91721, 101333,
    111945, 123660, 136594, 150872, 166636, 184040, 203254, 224466, 247886,
    273742, 301288, 331258, 363931, 399345, 437931, 480048, 526645, 576962,
    631027, 689821, 753370, 821722, 896256, 977410, 1065744, 1166256,
    1277995, 1400733, 1536443, 1684900, 1847750, 2025787, 2218877, 2428490,
    2655534, 2902465, 3170780, 3462226, 3779380, 4124695, 4500768, 4909345,
    5353622, 5835754, 6358510, 6924344, 7535654, 8197786, 8914070, 99_999_999,
]

ALL_SKILLS: List[str] = [
    "Attack", "Hitpoints", "Mining",
    "Strength", "Agility", "Smithing",
    "Defence", "Herblore", "Fishing",
    "Ranged", "Thieving", "Cooking",
    "Prayer", "Crafting", "Firemaking",
    "Magic", "Fletching", "Woodcutting",
    "Runecrafting", "Slayer", "Farming",
    "Construction", "Hunter",
]


def xp_to_level(xp: int) -> int:
    """Convert total XP → OSRS level (1–99)."""
    for lvl in range(99, 0, -1):
        if xp >= _XP_FOR_LEVEL[lvl]:
            return lvl
    return 1


def level_to_xp(level: int) -> int:
    """XP required to reach a given level."""
    return _XP_FOR_LEVEL[max(1, min(99, level))]


def xp_to_next_level(total_xp: int) -> Tuple[int, int]:
    """Returns (xp_into_level, xp_needed_for_next) for progress bar use."""
    current_lvl = xp_to_level(total_xp)
    if current_lvl >= 99:
        return 0, 0
    xp_current = _XP_FOR_LEVEL[current_lvl]
    xp_next    = _XP_FOR_LEVEL[current_lvl + 1]
    return total_xp - xp_current, xp_next - xp_current


# ── XP/hr rolling window ──────────────────────────────────────────────────
_XP_HR_WINDOW = 300   # seconds of history to use for XP/hr calc


class _SkillData:
    """Per-skill state."""
    __slots__ = ("total_xp", "session_xp", "level", "xp_events")

    def __init__(self, total_xp: int = 0, session_xp: int = 0):
        self.total_xp   = total_xp
        self.session_xp = session_xp
        self.level      = xp_to_level(total_xp)
        # Rolling deque of (timestamp, xp_gained) for XP/hr
        self.xp_events: deque = deque()

    def add_xp(self, xp: int) -> bool:
        """Returns True if this gain caused a level-up."""
        old_level        = self.level
        self.total_xp   += xp
        self.session_xp += xp
        self.level       = xp_to_level(self.total_xp)
        now = time.time()
        self.xp_events.append((now, xp))
        # Prune old events
        cutoff = now - _XP_HR_WINDOW
        while self.xp_events and self.xp_events[0][0] < cutoff:
            self.xp_events.popleft()
        return self.level > old_level

    def xp_per_hour(self) -> int:
        now    = time.time()
        cutoff = now - _XP_HR_WINDOW
        # Prune
        while self.xp_events and self.xp_events[0][0] < cutoff:
            self.xp_events.popleft()
        if len(self.xp_events) < 2:
            return 0
        elapsed = now - self.xp_events[0][0]
        if elapsed < 5:
            return 0
        total = sum(x for _, x in self.xp_events)
        return int(total / elapsed * 3600)

    def to_dict(self) -> dict:
        return {
            "total_xp":   self.total_xp,
            "session_xp": self.session_xp,
            "level":      self.level,
        }

    @classmethod
    def from_dict(cls, d: dict) -> "_SkillData":
        obj = cls(total_xp=d.get("total_xp", 0),
                  session_xp=d.get("session_xp", 0))
        return obj


class SkillTracker:
    """
    Thread-safe skill XP tracker with JSON persistence.
    """

    def __init__(self, save_path: str = _SAVE_FILE):
        self._save_path = save_path
        self._skills: Dict[str, _SkillData] = {
            s: _SkillData() for s in ALL_SKILLS
        }
        # Ordered list of last 8 skills trained this session (most recent first)
        self._recent: deque = deque(maxlen=8)
        self.on_levelup = None   # optional callback(skill, new_level)

    # ── Persistence ───────────────────────────────────────────────────────

    def load(self):
        """Load saved XP data. Safe to call even if file doesn't exist."""
        try:
            if not os.path.exists(self._save_path):
                return
            with open(self._save_path, "r", encoding="utf-8") as f:
                data = json.load(f)
            for skill, sd in data.get("skills", {}).items():
                if skill in self._skills:
                    self._skills[skill] = _SkillData.from_dict(sd)
            logger.info(f"[SkillTracker] Loaded from {self._save_path}")
        except Exception as e:
            logger.warning(f"[SkillTracker] Load failed: {e}")

    def save(self):
        """Persist current XP data to JSON."""
        try:
            os.makedirs(os.path.dirname(self._save_path), exist_ok=True)
            payload = {
                "saved_at": time.strftime("%Y-%m-%d %H:%M:%S"),
                "skills":   {s: d.to_dict() for s, d in self._skills.items()},
            }
            with open(self._save_path, "w", encoding="utf-8") as f:
                json.dump(payload, f, indent=2)
        except Exception as e:
            logger.warning(f"[SkillTracker] Save failed: {e}")

    def reset_session(self):
        """Zero out session XP (keeps total XP intact)."""
        for sd in self._skills.values():
            sd.session_xp = 0
            sd.xp_events.clear()
        self._recent.clear()

    # ── XP recording ─────────────────────────────────────────────────────

    def record_xp(self, skill: str, xp: int) -> bool:
        """
        Record an XP gain. Returns True if a level-up occurred.
        Auto-saves every 10 gains.
        """
        if skill not in self._skills:
            return False
        levelled = self._skills[skill].add_xp(xp)
        # Keep recent list with this skill at front
        if skill in self._recent:
            self._recent.remove(skill)
        self._recent.appendleft(skill)

        if levelled and self.on_levelup:
            try:
                self.on_levelup(skill, self._skills[skill].level)
            except Exception:
                pass

        # Auto-save periodically
        total_gains = sum(len(d.xp_events) for d in self._skills.values())
        if total_gains % 10 == 0:
            self.save()

        return levelled

    # ── Accessors ─────────────────────────────────────────────────────────

    def level(self, skill: str) -> int:
        return self._skills[skill].level if skill in self._skills else 1

    def total_xp(self, skill: str) -> int:
        return self._skills[skill].total_xp if skill in self._skills else 0

    def session_xp(self, skill: str) -> int:
        return self._skills[skill].session_xp if skill in self._skills else 0

    def xp_per_hour(self, skill: str) -> int:
        return self._skills[skill].xp_per_hour() if skill in self._skills else 0

    def xp_to_next(self, skill: str) -> Tuple[int, int]:
        """(xp_into_current_level, xp_needed_for_next_level)"""
        return xp_to_next_level(self.total_xp(skill))

    def recent_skills(self) -> List[str]:
        """Last 8 skills trained this session, most recent first."""
        return list(self._recent)

    def snapshot(self) -> List[dict]:
        """
        Full snapshot for the GUI — all skills with level, xp/hr, session xp.
        """
        out = []
        for skill in ALL_SKILLS:
            sd = self._skills[skill]
            xphr = sd.xp_per_hour()
            out.append({
                "skill":       skill,
                "level":       sd.level,
                "total_xp":    sd.total_xp,
                "session_xp":  sd.session_xp,
                "xp_per_hour": xphr,
                "active":      sd.session_xp > 0,
            })
        return out
