"""
RSEye Skill Tracker
===================
Receives skill data from the rseye-connector RuneLite plugin via
PositionTracker's on_stats callback.

RSEye POSTs to /stat_update/ with shape:
    {
        "username": "PlayerName",
        "statChanges": [
            {"skill": "Attack", "level": 75, "boostedLevel": 75, "xp": 1234567},
            ...
        ]
    }

statChanges contains only skills that changed, but on login/world-hop RSEye
sends all skills at once giving us a full snapshot on connect.

Wire up in main.py:
    pos_tracker.on_stats = rl_tracker.on_stats_update
"""
from __future__ import annotations

import logging
import threading
import time
from collections import deque
from typing import Callable, Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)

XP_HR_WINDOW = 300   # seconds

SKILL_NAMES: List[str] = [
    "Attack", "Defence", "Strength", "Hitpoints", "Ranged",
    "Prayer", "Magic", "Cooking", "Woodcutting", "Fletching",
    "Fishing", "Firemaking", "Crafting", "Smithing", "Mining",
    "Herblore", "Agility", "Thieving", "Slayer", "Farming",
    "Runecrafting", "Hunter", "Construction",
]

_NORM: Dict[str, str] = {s.upper(): s for s in SKILL_NAMES}
_NORM["RUNECRAFT"] = "Runecrafting"

def _normalise(name: str) -> Optional[str]:
    return _NORM.get(str(name).upper())


# ── XP table ──────────────────────────────────────────────────────────────
_XP_FOR_LEVEL: List[int] = [
    0, 0, 83, 174, 276, 388, 512, 650, 801, 969, 1154,
    1358, 1584, 1833, 2107, 2411, 2746, 3115, 3523, 3973, 4470,
    5018, 5624, 6291, 7028, 7842, 8740, 9730, 10824, 12031, 13363,
    14833, 16456, 18247, 20224, 22406, 24815, 27473, 30408, 33648, 37224,
    41171, 45529, 50339, 55649, 61512, 67983, 75127, 83014, 91721, 101333,
    111945, 123660, 136594, 150872, 166636, 184040, 203254, 224466, 247886,
    273742, 301288, 331258, 363931, 399345, 437931, 480048, 526645, 576962,
    631027, 689821, 753370, 821722, 896256, 977410, 1065744, 1166256,
    1277995, 1400733, 1536443, 1684900, 1847750, 2025787, 2218877, 2428490,
    2655534, 2902465, 3170780, 3462226, 3779380, 4124695, 4500768, 4909345,
    5353622, 5835754, 6358510, 6924344, 7535654, 8197786, 8914070, 99_999_999,
]

def _xp_to_level(xp: int) -> int:
    for lvl in range(99, 0, -1):
        if xp >= _XP_FOR_LEVEL[lvl]:
            return lvl
    return 1

def xp_to_next_level(total_xp: int) -> Tuple[int, int]:
    """(xp_into_current_level, xp_needed_for_next_level)"""
    lvl = _xp_to_level(total_xp)
    if lvl >= 99:
        return 0, 0
    return total_xp - _XP_FOR_LEVEL[lvl], _XP_FOR_LEVEL[lvl + 1] - _XP_FOR_LEVEL[lvl]


# ── Per-skill state ────────────────────────────────────────────────────────

class _SkillState:
    __slots__ = ("level", "xp", "session_start_xp", "xp_events")

    def __init__(self):
        self.level:            int   = 1
        self.xp:               int   = 0
        self.session_start_xp: int   = -1   # -1 = not yet seen
        self.xp_events:        deque = deque()

    def apply(self, level: int, xp: int) -> bool:
        """
        Apply an update from RSEye.  Returns True if level went up.
        Records an XP event for the rolling XP/hr window.
        """
        if self.session_start_xp < 0:
            self.session_start_xp = xp   # baseline on first packet

        gained    = xp - self.xp if self.xp > 0 else 0
        old_level = self.level

        self.level = level
        self.xp    = xp

        if gained > 0:
            now = time.time()
            self.xp_events.append((now, gained))
            self._prune(now)

        return level > old_level > 1   # suppress false level-up on first packet

    def xp_per_hour(self) -> int:
        now = time.time()
        self._prune(now)
        if len(self.xp_events) < 2:
            return 0
        elapsed = now - self.xp_events[0][0]
        if elapsed < 5:
            return 0
        return int(sum(x for _, x in self.xp_events) / elapsed * 3600)

    def session_xp(self) -> int:
        if self.session_start_xp < 0:
            return 0
        return max(0, self.xp - self.session_start_xp)

    def _prune(self, now: float):
        cutoff = now - XP_HR_WINDOW
        while self.xp_events and self.xp_events[0][0] < cutoff:
            self.xp_events.popleft()


# ── Main tracker ──────────────────────────────────────────────────────────

class RuneLiteTracker:
    """
    Receives RSEye stat_update packets via on_stats_update() and maintains
    full skill state for the GUI.  Thread-safe.

    Wire up in main.py:
        pos_tracker.on_stats = rl_tracker.on_stats_update
    """

    def __init__(self, host: str = "", port: int = 0):
        # host/port args kept for backwards compat with main.py constructor call
        self._skills:   Dict[str, _SkillState] = {s: _SkillState() for s in SKILL_NAMES}
        self._lock      = threading.Lock()
        self._connected = False
        self._last_seen = 0.0
        self._running   = False

        self.on_xp_gain: Optional[Callable[[str, int, int], None]] = None
        self.on_levelup: Optional[Callable[[str, int], None]]       = None
        self.on_update:  Optional[Callable[[List[dict]], None]]      = None

    # ── Lifecycle ──────────────────────────────────────────────────────

    def start(self):
        """Start background ticker to keep XP/hr decaying between RSEye events."""
        if self._running:
            return
        self._running = True
        threading.Thread(target=self._decay_loop, daemon=True,
                         name="RSEyeDecay").start()
        logger.info("[RSEye Tracker] Ready — waiting for stat_update packets")

    def stop(self):
        self._running = False
        logger.info("[RSEye Tracker] Stopped.")

    def _decay_loop(self):
        """Fires on_update every 5s so XP/hr decays live between gains."""
        while self._running:
            time.sleep(5)
            if self.on_update and self._connected:
                try:
                    self.on_update(self.snapshot())
                except Exception as e:
                    logger.debug("[RSEye] decay tick error: %s", e)

    # ── RSEye callback ─────────────────────────────────────────────────

    def on_stats_update(self, skills: dict):
        """
        Called by PositionTracker when a stat_update POST arrives.

        skills dict shape (after position_tracker.py parses statChanges):
            {
                "Attack":     {"level": 75, "boostedLevel": 75, "xp": 1234567},
                "Woodcutting": {...},
                ...
            }
        Only changed skills are present per packet; all skills on login.
        """
        if not skills:
            return

        self._connected = True
        self._last_seen = time.time()

        levelups  = []
        xp_gained = []

        with self._lock:
            for raw_name, data in skills.items():
                skill = _normalise(raw_name)
                if skill is None:
                    continue
                level = int(data.get("level", 1))
                xp    = int(data.get("xp", 0))

                st       = self._skills[skill]
                levelled = st.apply(level, xp)
                gained   = st.xp_events[-1][1] if st.xp_events else 0

                if gained > 0:
                    xp_gained.append((skill, gained, xp))
                if levelled:
                    levelups.append((skill, level))

        for skill, gained, total in xp_gained:
            logger.debug("[RSEye] +%d %s (total %d)", gained, skill, total)
            if self.on_xp_gain:
                try:
                    self.on_xp_gain(skill, gained, total)
                except Exception:
                    pass

        for skill, level in levelups:
            logger.info("[RSEye] LEVEL UP — %s → %d", skill, level)
            if self.on_levelup:
                try:
                    self.on_levelup(skill, level)
                except Exception:
                    pass

        if self.on_update:
            try:
                self.on_update(self.snapshot())
            except Exception as e:
                logger.debug("[RSEye] on_update error: %s", e)

    # ── Compatibility shim — GUI calls _fetch_stats() on refresh ───────

    def _fetch_stats(self):
        """
        No-op: RSEye is push-based.  Just fires on_update with current state
        so the GUI populates immediately on open / refresh button press.
        """
        if self.on_update:
            try:
                self.on_update(self.snapshot())
            except Exception:
                pass

    # ── Accessors ──────────────────────────────────────────────────────

    @property
    def connected(self) -> bool:
        return self._connected and (time.time() - self._last_seen < 30)

    @property
    def error(self) -> str:
        if not self._connected:
            return "Waiting for RSEye stat_update…"
        if time.time() - self._last_seen > 30:
            return "No stat packet in last 30s"
        return ""

    def level(self, skill: str) -> int:
        with self._lock:
            return self._skills[skill].level if skill in self._skills else 1

    def xp(self, skill: str) -> int:
        with self._lock:
            return self._skills[skill].xp if skill in self._skills else 0

    def xp_per_hour(self, skill: str) -> int:
        with self._lock:
            return self._skills[skill].xp_per_hour() if skill in self._skills else 0

    def session_xp(self, skill: str) -> int:
        with self._lock:
            return self._skills[skill].session_xp() if skill in self._skills else 0

    def reset_session(self):
        with self._lock:
            for sd in self._skills.values():
                sd.session_start_xp = sd.xp
                sd.xp_events.clear()

    def snapshot(self) -> List[dict]:
        """Full skill list for the GUI — same shape as before."""
        with self._lock:
            out = []
            for skill in SKILL_NAMES:
                sd  = self._skills[skill]
                xpi, xpn = xp_to_next_level(sd.xp)
                out.append({
                    "skill":        skill,
                    "level":        sd.level,
                    "xp":           sd.xp,
                    "xp_per_hour":  sd.xp_per_hour(),
                    "session_xp":   sd.session_xp(),
                    "xp_to_level":  xpi,
                    "xp_for_level": xpn,
                    "active":       sd.session_xp() > 0,
                })
            return out

    def ping(self) -> bool:
        return self.connected


# ── Singleton ──────────────────────────────────────────────────────────────

_tracker: Optional[RuneLiteTracker] = None

def get_tracker(host: str = "", port: int = 0) -> RuneLiteTracker:
    global _tracker
    if _tracker is None:
        _tracker = RuneLiteTracker()
    return _tracker
