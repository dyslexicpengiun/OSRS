import os
here = r"C:\Users\Dysle\Documents\Interception\AHK v1\runescript\core\detection"
for c in ["../../data/locations.json", "../data/locations.json", "data/locations.json"]:
    p = os.path.normpath(os.path.join(here, c))
    print(p, "->", os.path.exists(p))