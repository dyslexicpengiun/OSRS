"""
scrape_map_data.py  —  RuneScript map data bootstrapper
Usage:  python scrape_map_data.py
Needs:  pip install requests Pillow
"""

import json, sys, time, io
from pathlib import Path

try:
    import requests
except ImportError:
    sys.exit("pip install requests")
try:
    from PIL import Image
except ImportError:
    sys.exit("pip install Pillow")

SCRIPT_DIR    = Path(__file__).parent
# The app reads from runescript/data/ relative to the gui folder's parent.
# tile_map.py is at runescript/gui/tile_map.py → data is at runescript/data/
# scrape_map_data.py is at runescript/ → data is at runescript/data/
DATA_DIR      = SCRIPT_DIR / "data"
ICONS_DIR     = DATA_DIR / "map_icons"
LOCATIONS_OUT = DATA_DIR / "map_locations.json"
MANIFEST_OUT  = DATA_DIR / "icon_manifest.json"

DATA_DIR.mkdir(parents=True, exist_ok=True)
ICONS_DIR.mkdir(parents=True, exist_ok=True)

S = requests.Session()
S.headers.update({
    "User-Agent": "RuneScript/1.0 map data fetch",
    "Referer":    "https://maps.runescape.wiki/",
})

def get_json(url):
    r = S.get(url, timeout=20)
    r.raise_for_status()
    return r.json()

BASE      = "https://maps.runescape.wiki/osrs/"
ICONS_URL = BASE + "data/iconLists/MainIcons.json"
LOCS_URL  = BASE + "data/overlayMaps/MainMapIconLoc.json"

# ── Step 1: Icon definitions ──────────────────────────────────────────────────
# {"folder": "...", "icons": {"bank": {...}, "dungeon": {...}, ...}}
print("Fetching icon definitions ...")
raw_icons = get_json(ICONS_URL)
icon_list = raw_icons.get("icons", {})
print(f"  Type of 'icons' value: {type(icon_list).__name__}")

# Handle both dict and list
if isinstance(icon_list, dict):
    items = list(icon_list.items())
    print(f"  {len(items)} icon definitions (dict)")
    if items:
        first_key, first_val = items[0]
        print(f"  First entry key: {repr(first_key)}")
        print(f"  First entry value: {json.dumps(first_val, indent=2)}")
    icons_meta = {}
    for key, val in icon_list.items():
        if isinstance(val, dict):
            label   = val.get("label", val.get("name", val.get("tooltip", key)))
            icon_url = val.get("filename", val.get("iconUrl", val.get("sprite", val.get("icon", ""))))
        else:
            label, icon_url = str(val), ""
        icons_meta[str(key)] = {"label": str(label), "iconUrl": str(icon_url)}
elif isinstance(icon_list, list):
    print(f"  {len(icon_list)} icon definitions (list)")
    if icon_list:
        print(f"  First entry: {json.dumps(icon_list[0], indent=2)}")
    icons_meta = {}
    for item in icon_list:
        if not isinstance(item, dict):
            continue
        key      = str(item.get("id", item.get("name", item.get("className", ""))))
        label    = item.get("label", item.get("name", item.get("tooltip", key)))
        icon_url = item.get("iconUrl", item.get("sprite", item.get("icon", item.get("url", ""))))
        if key:
            icons_meta[key] = {"label": str(label), "iconUrl": str(icon_url)}

print(f"  Parsed {len(icons_meta)} icon entries")
print(f"  Sample: {dict(list(icons_meta.items())[:5])}")

# ── Step 2: Locations ─────────────────────────────────────────────────────────
print("\nFetching locations ...")
raw_locs  = get_json(LOCS_URL)
features  = raw_locs.get("features", [])
print(f"  {len(features)} features")

locations      = []
icon_keys_used = set()

for feat in features:
    try:
        props  = feat.get("properties", {})
        coords = feat["geometry"]["coordinates"]
        x      = int(coords[0])
        y      = int(coords[1])
        plane  = int(coords[2]) if len(coords) > 2 else 0
        icon   = str(props.get("icon", ""))
        map_id = int(props.get("mapID", 0))
        meta   = icons_meta.get(icon, {})
        label  = meta.get("label", icon)
        locations.append({
            "x": x, "y": y, "plane": plane, "map_id": map_id,
            "icon": icon, "name": label, "category": icon.lower(),
        })
        icon_keys_used.add(icon)
    except Exception:
        continue

print(f"  Parsed {len(locations)} locations")
print(f"  Icon types found: {sorted(icon_keys_used)}")

# ── Step 3: Download icon images ──────────────────────────────────────────────
downloaded = 0
skipped    = 0
failed     = 0

def dl_icon(url, dest):
    global downloaded, skipped, failed
    if dest.exists():
        skipped += 1
        return True
    try:
        r = S.get(url, timeout=8)
        if r.status_code == 404:
            failed += 1
            return False
        r.raise_for_status()
        img = Image.open(io.BytesIO(r.content)).convert("RGBA")
        img.save(dest, "PNG")
        downloaded += 1
        return True
    except Exception:
        failed += 1
        return False

print(f"\nDownloading icons for {len(icon_keys_used)} types ...")
for key in sorted(icon_keys_used):
    meta     = icons_meta.get(key, {})
    icon_url = meta.get("iconUrl", "")
    if icon_url:
        full_url = icon_url if icon_url.startswith("http") else BASE + "images/icons/" + icon_url.lstrip("/")
        filename = icon_url.split("/")[-1] or f"{key}.png"
        if dl_icon(full_url, ICONS_DIR / filename):
            print(f"  ✓ {key} → {filename}")
            continue
    # Fallback patterns
    for suffix in (f"{key}.png", f"{key}-0.png"):
        if dl_icon(BASE + f"images/icons/{suffix}", ICONS_DIR / suffix):
            print(f"  ✓ {key} → {suffix} (fallback)")
            break
    else:
        print(f"  ✗ {key} — no icon found")

print(f"\nDownloading numbered sprites 0-2000 ...")
for i in range(0, 2001):
    dl_icon(BASE + f"images/icons/{i}-0.png", ICONS_DIR / f"{i}-0.png")
    if i % 200 == 0:
        print(f"  [{i}/2000] new={downloaded} skipped={skipped}")
    if i % 50 == 0:
        time.sleep(0.05)

print(f"Icons: {downloaded} new, {skipped} already existed, {failed} not found")

# ── Step 4: Save outputs ──────────────────────────────────────────────────────
manifest = {p.stem: p.name for p in ICONS_DIR.glob("*.png")}
with open(MANIFEST_OUT, "w") as f:
    json.dump(manifest, f, indent=2)

with open(LOCATIONS_OUT, "w", encoding="utf-8") as f:
    json.dump(locations, f, indent=2, ensure_ascii=False)

with open(DATA_DIR / "icon_meta.json", "w") as f:
    json.dump(icons_meta, f, indent=2)

print(f"\n✓ Done!")
print(f"  {len(locations)} locations → {LOCATIONS_OUT}")
print(f"  {len(manifest)} icons → {ICONS_DIR}")

# ── Step 5: Fetch city/town/area names from wiki ──────────────────────────────
# The wiki has a "locations" category with coords for every named area.
# We fetch these via the MediaWiki API and merge them in as label-only entries.
print("\nFetching city/town names from wiki ...")

CITY_PAGES = [
    "Lumbridge", "Varrock", "Falador", "Edgeville", "Draynor Village",
    "Al Kharid", "Barbarian Village", "Rimmington", "Port Sarim",
    "Entrana", "Taverley", "Burthorpe", "Catherby", "Seers' Village",
    "Camelot", "Ardougne", "Yanille", "Witchaven", "Fishing Guild",
    "Gnome Stronghold", "Tree Gnome Village", "Ranging Guild",
    "Crafting Guild", "Mining Guild", "Champions' Guild",
    "Warrior's Guild", "Monastery", "Goblin Village",
    "Dwarven Mine", "Ice Mountain", "Wilderness", "Edgeville Dungeon",
    "Mort'ton", "Canifis", "Burgh de Rott", "Meiyerditch",
    "Port Phasmatys", "Slepe", "Darkmeyer",
    "Shilo Village", "Tai Bwo Wannai", "Brimhaven", "Musa Point",
    "Cairn Isle", "Mossy Rock", "Oo'glog",
    "Nardah", "Pollnivneach", "Sophanem", "Menaphos",
    "Agility Pyramid", "Pyramid Plunder",
    "Lletya", "Prifddinas", "Arandar",
    "Keldagrim", "Dorgesh-Kaan",
    "Lumbridge Swamp", "Draynor Manor", "Wizard's Tower",
    "Digsite", "Exam Centre",
    "Morytania", "Canifis", "Harmony Island",
    "Pest Control", "Void Knight Outpost",
    "Waterbirth Island", "Neitiznot", "Jatizso", "Rellekka",
    "Sinclair Mansion", "Fremennik Province",
    "Witchaven", "Hemenster", "McGrubor's Wood",
    "Hosidius", "Shayzien", "Lovakengj", "Arceuus", "Piscarilius",
    "Kourend", "Xeric's Lookout", "Wintertodt Camp",
    "Fossil Island", "Mushroom Meadow",
    "Zeah", "Great Kourend",
]

MW_API = "https://oldschool.runescape.wiki/api.php"
city_locations = []

for page in CITY_PAGES:
    try:
        r = S.get(MW_API, params={
            "action": "query",
            "prop": "coordinates",
            "titles": page,
            "format": "json",
            "formatversion": "2",
        }, timeout=10)
        r.raise_for_status()
        data = r.json()
        pages = data.get("query", {}).get("pages", [])
        for p in pages:
            coords_list = p.get("coordinates", [])
            for coord in coords_list:
                # Wiki coords use lat=y, lon=x in game space
                x = int(coord.get("lon", coord.get("x", 0)))
                y = int(coord.get("lat", coord.get("y", 0)))
                if x > 0 and y > 0:
                    city_locations.append({
                        "x": x, "y": y, "plane": 0,
                        "icon": "city",
                        "name": page,
                        "category": "city",
                    })
                    print(f"  {page}: ({x}, {y})")
                    break
        time.sleep(0.1)
    except Exception as e:
        print(f"  {page}: failed ({e})")

print(f"  Got {len(city_locations)} city coords")
locations.extend(city_locations)

# Re-save with cities included
with open(LOCATIONS_OUT, "w", encoding="utf-8") as f:
    json.dump(locations, f, indent=2, ensure_ascii=False)
print(f"Locations (with cities): {len(locations)} → {LOCATIONS_OUT}")
