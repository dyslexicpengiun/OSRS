"""
fetch_locations.py — fetches map icon locations + comprehensive place name labels
Place inside runescript/ and run: python fetch_locations.py
"""
import json, sys, time
from pathlib import Path

try:
    import requests
except ImportError:
    sys.exit("pip install requests")

SCRIPT_DIR = Path(__file__).resolve().parent
search = SCRIPT_DIR
for _ in range(4):
    if (search / "gui").is_dir() and (search / "data").is_dir():
        break
    search = search.parent
DATA_DIR = search / "data"
OUT = DATA_DIR / "map_locations.json"
print(f"Saving to: {OUT}")

ICON_LABELS = {
    "agility_short-cut":"Agility shortcut","agility_training":"Agility training",
    "altar":"Altar","amulet_shop":"Amulet shop","anvil":"Anvil",
    "apothecary":"Apothecary","archery_shop":"Archery shop","axe_shop":"Axe shop",
    "bank":"Bank","bank_tutor":"Bank tutor","bar":"Bar","bond_tutor":"Bond tutor",
    "bounty_hunter_store":"Bounty Hunter store","brewery":"Brewery",
    "candle_shop":"Candle shop","chainmail_shop":"Chainmail shop",
    "clothes_shop":"Clothes shop","combat_tutor":"Combat tutor",
    "cookery_shop":"Cookery shop","cooking_range":"Cooking range",
    "cooking_tutor":"Cooking tutor","crafting_shop":"Crafting shop",
    "crafting_tutor":"Crafting tutor","dairy_churn":"Dairy churn",
    "dairy_cow":"Dairy cow","danger_tutor":"Danger tutor",
    "deadman_tutor":"Deadman tutor","dummy":"Dummy","dungeon":"Dungeon",
    "dungeon_link":"Dungeon link","dye_trader":"Dye trader",
    "estate_agent":"Estate agent","farming_patch":"Farming patch",
    "farming_shop":"Farming shop","fishing_shop":"Fishing shop",
    "fishing_spot":"Fishing spot","fishing_tutor":"Fishing tutor",
    "food_shop":"Food shop","fur_trader":"Fur trader","furnace":"Furnace",
    "garden_supplier":"Garden supplier","gem_shop":"Gem shop",
    "general_store":"General store","grand_exchange":"Grand Exchange",
    "hairdresser":"Hairdresser","helmet_shop":"Helmet shop","herbalist":"Herbalist",
    "holiday_event":"Holiday event","holiday_item_trader":"Holiday item trader",
    "house_portal":"Player-owned house","hunter_shop":"Hunter shop",
    "hunter_training":"Hunter training","hunting_tutor":"Hunting tutor",
    "ironman_tutor":"Ironman tutor","jewellery":"Jewellery","junk_checker":"Junk checker",
    "kebab_seller":"Kebab seller","kourend_task":"Kourend task","loom":"Loom",
    "lumbridge_guide":"Lumbridge guide","mace_shop":"Mace shop","magic_shop":"Magic shop",
    "makeover_mage":"Makeover mage","minigame":"Minigame","mining_shop":"Mining shop",
    "mining_site":"Mining site","mining_tutor":"Mining tutor",
    "newspaper_trader":"Newspaper","pet_insurance_shop":"Pet insurance",
    "platebody_shop":"Platebody shop","platelegs_shop":"Platelegs shop",
    "plateskirt_shop":"Plateskirt shop","poll_booth":"Poll booth",
    "potters_wheel":"Potter's wheel","prayer_tutor":"Prayer tutor",
    "pricing_expert_herbs":"Herb prices","pricing_expert_logs":"Log prices",
    "pricing_expert_ores":"Ore prices","pricing_expert_runes":"Rune prices",
    "pricing_expert_weapons_and_armours":"Weapon prices",
    "quest_start":"Quest start","raids_lobby":"Raids lobby","rare_trees":"Rare trees",
    "rope_trader":"Rope trader","sandpit":"Sandpit","sawmill":"Sawmill",
    "scimitar_shop":"Scimitar shop","security_tutor":"Security tutor",
    "shield_shop":"Shield shop","silk_trader":"Silk trader","silver_shop":"Silver shop",
    "slayer_master":"Slayer master","smithing_tutor":"Smithing tutor",
    "spice_shop":"Spice shop","spinning_wheel":"Spinning wheel","staff_shop":"Staff shop",
    "sword_shop":"Sword shop","tannery":"Tannery","task_master":"Task master",
    "taxidermist":"Taxidermist","tea_trader":"Tea trader","transportation":"Transportation",
    "vegetable_store":"Vegetable store","water_source":"Water source","windmill":"Windmill",
    "wine_trader":"Wine trader","woodcutting_stump":"Woodcutting stump",
    "woodcutting_tutor":"Woodcutting tutor",
}

S = requests.Session()
S.headers.update({"User-Agent": "RuneScript/1.0", "Referer": "https://maps.runescape.wiki/"})
BASE = "https://maps.runescape.wiki/osrs/"

# ── Step 1: Service icons ─────────────────────────────────────────────────────
print("Fetching service icon locations...")
features = []
try:
    r = S.get(BASE + "data/overlayMaps/MainMapIconLoc.json", timeout=20)
    r.raise_for_status()
    features = r.json().get("features", [])
    # Cache raw data for offline use
    with open(DATA_DIR / "_raw_locs.json", "w", encoding="utf-8") as f:
        json.dump(r.json(), f)
    print(f"  Fetched {len(features)} features from wiki")
except Exception as e:
    print(f"  Network fetch failed ({e}), falling back to cached _raw_locs.json...")
    raw_path = DATA_DIR / "_raw_locs.json"
    if raw_path.exists():
        with open(raw_path, encoding="utf-8") as f:
            features = json.load(f).get("features", [])
        print(f"  Loaded {len(features)} features from cache")
    else:
        print("  No cache found — service icons will be empty")
locations = []
for feat in features:
    try:
        props  = feat["properties"]
        coords = feat["geometry"]["coordinates"]
        icon   = str(props.get("icon", ""))
        locations.append({
            "x": int(coords[0]), "y": int(coords[1]),
            "plane": int(coords[2]) if len(coords) > 2 else 0,
            "map_id": int(props.get("mapID", 0)),
            "icon": icon,
            "name": ICON_LABELS.get(icon, icon.replace("_"," ").title()),
            "category": icon,
        })
    except Exception:
        continue
print(f"  {len(locations)} service locations")

# ── Step 2: Comprehensive place name labels ───────────────────────────────────
# Sourced from in-game world map labels, covering cities, towns, dungeons,
# landmarks, mountains, forests, bodies of water, and regions.
PLACE_LABELS = {
    # ── Major cities & towns ─────────────────────────────────────────────────
    "Lumbridge":              (3222, 3218),
    "Varrock":                (3210, 3424),
    "Falador":                (2964, 3378),
    "Edgeville":              (3087, 3497),
    "Draynor Village":        (3105, 3251),
    "Al Kharid":              (3293, 3174),
    "Barbarian Village":      (3081, 3421),
    "Rimmington":             (2954, 3212),
    "Port Sarim":             (3015, 3222),
    "Taverley":               (2894, 3444),
    "Burthorpe":              (2899, 3544),
    "Catherby":               (2796, 3440),
    "Seers' Village":         (2726, 3484),
    "Ardougne":               (2662, 3305),
    "Yanille":                (2608, 3096),
    "Gnome Stronghold":       (2461, 3444),
    "Shilo Village":          (2852, 2954),
    "Brimhaven":              (2757, 3178),
    "Nardah":                 (3425, 2897),
    "Pollnivneach":           (3351, 2994),
    "Sophanem":               (3316, 2752),
    "Mos Le'Harmless":        (3710, 2963),
    "Canifis":                (3492, 3488),
    "Burgh de Rott":          (3494, 3208),
    "Port Phasmatys":       (3665, 3487),
    "Rellekka":               (2660, 3659),
    "Neitiznot":              (2336, 3801),
    "Jatizso":                (2415, 3813),
    "Prifddinas":             (2208, 3333),
    "Lletya":                 (2350, 3163),
    "Slepe":                  (3732, 3354),
    "Darkmeyer":              (3592, 3395),
    "Civitas illa Fortis":    (1675, 3119),
    # ── Zeah (Kourend) ───────────────────────────────────────────────────────
    "Hosidius":               (1749, 3599),
    "Shayzien":               (1490, 3631),
    "Lovakengj":              (1482, 3815),
    "Arceuus":                (1697, 3812),
    "Piscarilius":            (1804, 3783),
    "Land's End":             (1513, 3421),
    "Wintertodt Camp":        (1630, 3956),
    "Farming Guild":          (1248, 3718),
    "Woodcutting Guild":      (1659, 3504),
    "Forthos Dungeon":        (1762, 3830),
    # ── Underground cities ───────────────────────────────────────────────────
    "Keldagrim":              (2845, 10210),
    "Dorgesh-Kaan":           (2719, 5338),
    "Cam Torum":              (1450, 9420),
    # ── Landmarks & notable areas ────────────────────────────────────────────
    "Grand Exchange":         (3164, 3480),
    "Stronghold of Security": (3081, 3406),
    "Draynor Manor":          (3109, 3349),
    "Wizard's Tower":         (3104, 3162),
    "Lumbridge Swamp":        (3151, 3149),
    "Dwarven Mine":           (3029, 3340),
    "Ice Mountain":       (3007, 3481),
    "Black Knight Fortress":       (3018, 3521),
    "White Wolf Mountain":    (2851, 3486),
    "Camelot":                (2757, 3494),
    "McGrubor's Wood":       (2644, 3483),
    "Ranging Guild":          (2658, 3438),
    "Fishing Guild":          (2611, 3391),
    "Mining Guild":           (3013, 3329),
    "Crafting Guild":         (2934, 3289),
    "Champions' Guild":       (3190, 3357),
    "Cooks' Guild":           (3143, 3444),
    "Warriors' Guild":        (2844, 3544),
    "Legends' Guild":         (2728, 3348),
    "Myths' Guild":           (2457, 2847),
    "Nature Grotto":          (3435, 3320),
    "Exam Centre":            (3362, 3339),
    "Digsite":                (3360, 3378),
    "Lumber Yard":            (3302, 3490),
    "Varrock Sewers":         (3239, 9897),
    "Edgeville Dungeon":      (3095, 9867),
    "Karamja":                (2940, 3144),
    "Musa Point":             (2914, 3178),
    "Agility Pyramid":        (3340, 2830),
    "Pyramid Plunder":        (3288, 2783),
    "Smoke Dungeon":          (3309, 3061),
    "Bandit Camp":            (3165, 2985),
    "Bedabin Camp":           (3174, 3049),
    "Al Kharid Palace":       (3300, 3163),
    "Duel Arena":             (3316, 3226),
    "Clan Wars":              (3139, 3628),
    "Mage Arena":             (3094, 3956),
    "Chaos Temple":           (2935, 3514),
    "God Wars Dungeon":       (2920, 3755),
    "Trollheim":              (2891, 3676),
    "Troll Stronghold":       (2837, 3693),
    "Death Plateau":       (2863, 3590),
    "Waterbirth Island":      (2521, 3740),
    "Fremennick Province":       (2703, 3628),
    "Fossil Island":          (3740, 3805),
    "Mos Le'Harmless Cave":   (3757, 2973),
    "Mort Myre Swamp":        (3480, 3390),
    "Barrows":                (3566, 3298),
    "Meiyerditch":            (3598, 3283),
    "Theatre of Blood":       (3665, 3218),
    "Verzik's Lair":          (3665, 3218),
    "Chambers of Xeric":      (1232, 3574),
    "Lizardman Canyon":       (1509, 3688),
    "Lizardman Settlement":   (1540, 3731),
    "Xeric's Glade":          (1744, 3562),
    "Ruins of Camdozaal":     (3018, 9800),
    "Feldip Hills":           (2570, 2957),
    "Jiggig":                 (2477, 3046),
    "Gu'Tanoth":              (2516, 3072),
    "Ogre City":       (2532, 3036),
    "Castle Wars":            (2436, 3091),
    "Void Knights' Outpost":  (2640, 2656),
    "Pest Control":           (2657, 2649),
    "Corsair Cove":           (2564, 2854),
    "Corsair Cove Dungeon":   (2514, 9920),
    "Tree Gnome Village":     (2528, 3165),
    "Gnome Maze":             (2515, 3158),
    "Swamp":                  (3184, 3178),
    "Entrana":                (2826, 3344),
    "Crandor":                (2831, 3266),
    "Karamja Dungeon":        (2875, 9638),
    "Brimhaven Dungeon":      (2697, 9564),
    "TzHaar City":            (2479, 5175),
    "Inferno":                (2413, 5177),
    "Mount Karuulm":          (1318, 3780),
    "Farming Guild area":     (1248, 3718),
    "Sulphur Springs":        (1310, 3809),
    "Wyvern Cave":       (3075, 3652),
    "Asgarnian Ice Dungeon":  (3011, 9564),
    "Taverley Dungeon":       (2929, 9818),
    "Falador Farm":           (3038, 3307),
    "Rimmington Mine":        (2974, 3238),
    "Corsair Cove Resource Area": (2569, 2915),
    "Harmony Island":         (3802, 2821),
    "Ape Atoll":              (2718, 2756),
    "Kraken Cove":            (2280, 10023),
    "Kalphite Lair":          (3510, 9494),
    "Kalphite Cave":          (3225, 3108),
    "Smoke Devil Dungeon":    (2404, 9424),
    "Cerberus' Lair":         (1240, 1254),
    "Grotesque Guardians":    (3510, 3524),
    "Abyssal Nexus":          (3038, 4842),
    "Hallowed Sepulchre":     (2432, 5997),
    "Darkmeyer Dungeon":      (3592, 3395),
    "Meiyerditch Dungeon":    (3586, 9806),
    "Lassar Undercity":       (3027, 9820),
    "Godwars Dungeon":        (2920, 3755),
    "Ourania Cave":           (2460, 3234),
    "Zeah Dungeon":           (1313, 10045),
    "The Gauntlet":           (3012, 6117),
    "Prifddinas Waterfall":   (2259, 3474),
    "Lletya Dungeon":         (2336, 3209),
    "Iowerth Dungeon":        (2188, 9796),
    "Tormented Demons":       (2769, 5457),
    "Port Khazard":           (2660, 3161),
    "Necropolis":             (3424, 2844),
    "Wushanko Isles":         (1640, 5362),
    # ── F2P famous areas ─────────────────────────────────────────────────────
    "Wilderness":             (3100, 3650),
    "Deep Wilderness":        (3060, 3880),
    "Wilderness Volcano":       (3367, 3932),
    "Chaos Altar":       (2951, 3821),
    "Lava Maze":              (3070, 3847),
    "Mage of Zamorak":       (3091, 3953),
    "Edgeville Monastery":    (3050, 3491),
    "East Varrock Mine":      (3281, 3366),
    "West Varrock Mine":      (3181, 3367),
    "Draynor Bank":           (3093, 3244),
    "Dark Wizards' Tower":       (2907, 3334),
    "Makeover Mage":          (2998, 3189),
    "Crafting Guild":         (2934, 3289),
    "Goblin Village":         (2955, 3499),
    "Gunnarsgrunn":           (3081, 3421),
    "Corsair Cove":           (2564, 2854),
    "Mudskipper Point":       (2989, 3109),
    "Karamja Volcano":        (2859, 3167),
    "Melzar's Maze":          (2934, 3246),
    "Hemenster":              (2635, 3451),
}

# ── Step 3: Build location list ───────────────────────────────────────────────
existing_names = set()
added = 0
for name, (x, y) in PLACE_LABELS.items():
    if name not in existing_names:
        locations.append({
            "x": x, "y": y, "plane": 0, "map_id": 0,
            "icon": "city", "name": name, "category": "city",
        })
        existing_names.add(name)
        added += 1

print(f"Added {added} place labels")
print(f"Total locations: {len(locations)}")

with open(OUT, "w", encoding="utf-8") as f:
    json.dump(locations, f, indent=2, ensure_ascii=False)
print(f"✓ Saved to {OUT}")
