"""
Woodcutting Script
Chops trees using RuneLite object highlight detection as the primary
targeting signal, with hover text as a confirmation layer.

─────────────────────────────────────────────────────────────────────
Setup in RuneLite before running:
  1. Install the "Object Markers" plugin
  2. Shift+right-click the tree you want to chop → "Mark object"
  3. Right-click the coloured diamond next to it → choose your colour
  4. Set that same colour in the RuneScript GUI colour picker
  5. Press Start

─────────────────────────────────────────────────────────────────────
State machine:
  FIND_TREE      → scan for highlight contour → HOVER_CONFIRM
  HOVER_CONFIRM  → move mouse, check hover text → CHOPPING or next candidate
  CHOPPING       → wait for XP drop or depletion → FIND_TREE
  FULL_INVENTORY → drop/bank logs → FIND_TREE
─────────────────────────────────────────────────────────────────────
"""

import logging
import time
import random
from enum import Enum, auto
from typing import Optional, List

from scripts.base_script     import BaseScript
from core.capture            import screenshot, get_window_rect, find_game_window
from core.highlight_detector import HighlightDetector, HighlightTarget
from core.hover_text         import HoverTextReader
from core.xp_drop            import XPDropDetector
from core.antiban            import Antiban
from core                    import input as mouse

logger = logging.getLogger(__name__)


class State(Enum):
    FIND_TREE      = auto()
    HOVER_CONFIRM  = auto()
    CHOPPING       = auto()
    FULL_INVENTORY = auto()


# Frames with no highlight before declaring tree depleted
DEPLETION_MISS_THRESHOLD = 4

# Max seconds to wait for an XP drop before giving up and resetting
CHOP_TIMEOUT = 35.0

# Hover text fragments that confirm we're over the right object
TREE_HOVER_NAMES = {
    'normal':   ['chop down', 'tree'],
    'oak':      ['chop down', 'oak'],
    'willow':   ['chop down', 'willow'],
    'maple':    ['chop down', 'maple'],
    'yew':      ['chop down', 'yew'],
    'magic':    ['chop down', 'magic'],
    'teak':     ['chop down', 'teak'],
    'mahogany': ['chop down', 'mahogany'],
}

# Base XP per successful chop
XP_TABLE = {
    'normal': 25, 'oak': 37, 'willow': 67, 'teak': 85,
    'maple': 100, 'mahogany': 125, 'yew': 175, 'magic': 250,
}




class WoodcuttingScript(BaseScript):

    def __init__(self, config: dict = None):
        super().__init__(config)

        self.tree_type       = config.get('tree_type', 'oak')
        self.mode            = config.get('mode', 'power_chop')
        highlight_colour     = config.get('highlight_colour', '#00FFFF')

        self.detector   = HighlightDetector(highlight_colour)
        self.hover      = HoverTextReader()
        self.xp_tracker = XPDropDetector()
        self.antiban    = Antiban(enabled=config.get('antiban', True))

        self._state          = State.FIND_TREE
        self._candidates:  List[HighlightTarget] = []
        self._candidate_idx  = 0
        self._chop_start     = 0.0
        self._miss_count     = 0
        self._trees_chopped  = 0
        self._xp_gained      = 0

    # ── Called live by GUI bridge when colour picker changes ──────────

    def set_highlight_colour(self, hex_colour: str):
        self.detector.set_colour(hex_colour)
        self.logger.info(f'Highlight colour → {hex_colour}')

    # ── BaseScript ────────────────────────────────────────────────────

    def setup(self) -> bool:
        self.logger.info(
            f'Woodcutting | tree: {self.tree_type} | '
            f'mode: {self.mode} | colour: {self.detector._hex}'
        )
        if find_game_window() is None:
            self.logger.error('RuneLite window not found.')
            return False
        return True

    def loop(self) -> bool:
        if self._state == State.FIND_TREE:
            return self._find_tree()
        if self._state == State.HOVER_CONFIRM:
            return self._hover_confirm()
        if self._state == State.CHOPPING:
            return self._chopping()
        if self._state == State.FULL_INVENTORY:
            return self._full_inventory()
        return True

    def teardown(self):
        self.logger.info(
            f'Session ended | {self._trees_chopped} trees | '
            f'{self._xp_gained:,} xp | {self.stats.elapsed_str()}'
        )

    def get_paint_data(self):
        return {
            'Runtime':         self.stats.elapsed_str(),
            'Trees Chopped':   self._trees_chopped,
            'XP / hr':         f'{self.stats.per_hour(self._xp_gained):,}',
            'Logs / hr':       f'{self.stats.per_hour(self._trees_chopped):,}',
            'Errors':          self.stats.errors,
            'session_elapsed': int(self.stats.elapsed()),
            'skills':          self.stats.skill_gains,
        }

    # ── FIND_TREE ─────────────────────────────────────────────────────

    def _find_tree(self) -> bool:
        frame = screenshot()
        if frame is None:
            self.logger.warning('No screenshot — retrying...')
            find_game_window()
            self.sleep(1.5)
            return True

        targets = self.detector.find(frame)
        if not targets:
            self._miss_count += 1
            if self._miss_count % 15 == 0:
                self.logger.info('Scanning for highlighted tree...')
            self.sleep(0.3)
            return True

        self._miss_count     = 0
        self._candidates     = targets
        self._candidate_idx  = 0
        self._go(State.HOVER_CONFIRM)
        return True

    # ── HOVER_CONFIRM ────────────────────────────────────────────────

    def _hover_confirm(self) -> bool:
        if self._candidate_idx >= len(self._candidates):
            self.logger.debug('All candidates failed — rescanning.')
            self._go(State.FIND_TREE)
            return True

        target = self._candidates[self._candidate_idx]
        rect   = get_window_rect()
        cx, cy = target.centre
        cx    += random.randint(-4, 4)
        cy    += random.randint(-4, 4)

        mouse.move_to(cx, cy, window_rect=rect)
        self.antiban.short_pause()

        frame = screenshot()
        if frame is None:
            self._candidate_idx += 1
            return True

        hover_names = TREE_HOVER_NAMES.get(self.tree_type, ['chop down'])

        if self.hover.matches_profile(frame, hover_names):
            self.logger.info(f'Confirmed — clicking ({cx}, {cy})')
            mouse.click(window_rect=rect)
            self.antiban.reaction_delay()
            self._chop_start = time.time()
            self._miss_count = 0
            self._go(State.CHOPPING)
        else:
            self.logger.debug(f'Candidate {self._candidate_idx} mismatch — next')
            self._candidate_idx += 1

        return True

    # ── CHOPPING ─────────────────────────────────────────────────────

    def _chopping(self) -> bool:
        frame = screenshot()
        if frame is None:
            return True

        # XP drop = successful chop
        if self.xp_tracker.detect(frame):
            xp = XP_TABLE.get(self.tree_type, 37)
            self._trees_chopped += 1
            self._xp_gained     += xp
            self.stats.xp_gained += xp

            levelled = self.skill_tracker.record_xp('Woodcutting', xp)
            new_level = self.skill_tracker.level('Woodcutting')
            if levelled:
                self.logger.info(f'LEVEL UP! Woodcutting is now {new_level}!')
            self.stats.record_skill_xp(
                skill='Woodcutting', xp=xp,
                level=new_level, levelled=levelled
            )
            self.logger.info(
                f'Chop! Trees: {self._trees_chopped} | '
                f'+{xp} xp ({self._xp_gained:,} total)'
            )
            self.antiban.on_action()

            if self._inventory_full():
                self._go(State.FULL_INVENTORY)
                return True

        # Highlight gone = tree depleted
        if not self.detector.find(frame):
            self._miss_count += 1
            if self._miss_count >= DEPLETION_MISS_THRESHOLD:
                self.logger.info('Tree depleted — finding next.')
                self._miss_count = 0
                self.antiban.reaction_delay()
                self._go(State.FIND_TREE)
        else:
            self._miss_count = 0

        # Timeout safety
        if time.time() - self._chop_start > CHOP_TIMEOUT:
            self.logger.warning('Chop timeout — resetting state.')
            self._go(State.FIND_TREE)
            return True

        self.sleep(0.25)
        return True

    # ── FULL_INVENTORY ────────────────────────────────────────────────

    def _full_inventory(self) -> bool:
        if self.mode == 'power_chop':
            self._drop_all_logs()
        else:
            self.logger.info('Bank mode not yet implemented — dropping instead.')
            self._drop_all_logs()
        self._go(State.FIND_TREE)
        return True

    def _drop_all_logs(self):
        """Placeholder — inventory drop logic to be implemented."""
        self.logger.info('Dropping logs... (inventory module pending)')
        self.sleep(0.5)

    # ── Helpers ──────────────────────────────────────────────────────

    def _go(self, state: State):
        self.logger.debug(f'→ {state.name}')
        self._state = state

    def _inventory_full(self) -> bool:
        """Placeholder until inventory detection is built."""
        return False
