"""
Base Script
Abstract base class every automation script inherits from.
Provides:
  - Threaded start/stop lifecycle
  - Per-script logging with a queue (so GUI can consume log lines)
  - Stats tracking
  - Access to shared core modules (capture, input, antiban)
"""

import logging
import logging.handlers
import os
import queue
import sys
import threading
import time
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any, Dict, Optional

# Ensure pkg root on path so core is importable
_HERE = os.path.dirname(os.path.abspath(__file__))
_PKG_ROOT = os.path.dirname(_HERE)
if _PKG_ROOT not in sys.path:
    sys.path.insert(0, _PKG_ROOT)

from core.skill_tracker import SkillTracker
from core.runelite_tracker import RuneLiteTracker, get_tracker as get_runelite_tracker
from core.position_tracker import PositionTracker, get_tracker as get_position_tracker


@dataclass
class SkillGain:
    """A single skill XP gain event."""
    skill:     str
    xp:        int
    level:     int        # current level after the gain
    levelled:  bool       # True if this gain caused a level-up
    timestamp: float = field(default_factory=time.time)


@dataclass
class ScriptStats:
    start_time:   float = field(default_factory=time.time)
    actions:      int   = 0
    xp_gained:    int   = 0
    items_gained: int   = 0
    errors:       int   = 0
    custom:       Dict[str, Any] = field(default_factory=dict)
    # Skill tracking — last 8 unique skills trained, most recent first
    skill_gains:  list  = field(default_factory=list)   # list of SkillGain

    def record_skill_xp(self, skill: str, xp: int,
                        level: int = 0, levelled: bool = False):
        """Call this whenever the script gains XP in a skill."""
        gain = SkillGain(skill=skill, xp=xp, level=level, levelled=levelled)
        # Move this skill to the front; keep only last 8 unique skills
        self.skill_gains = [g for g in self.skill_gains if g.skill != skill]
        self.skill_gains.insert(0, gain)
        self.skill_gains = self.skill_gains[:8]

    def elapsed(self) -> float:
        return time.time() - self.start_time

    def elapsed_str(self) -> str:
        e = int(self.elapsed())
        return f'{e//3600}:{(e%3600)//60:02d}:{e%60:02d}'

    def per_hour(self, value: int) -> float:
        h = self.elapsed() / 3600
        return round(value / h) if h > 0.001 else 0


class BaseScript(ABC):
    """
    Inherit from this and implement setup(), loop(), and teardown().

    The script runs in its own daemon thread. The GUI bridge calls
    start() / stop() / pause() on it directly.
    """

    # Shared tracker — persists across script runs
    _skill_tracker: Optional["SkillTracker"] = None
    _runelite_tracker: Optional["RuneLiteTracker"] = None
    _position_tracker: Optional["PositionTracker"]  = None

    @classmethod
    def get_skill_tracker(cls) -> "SkillTracker":
        if cls._skill_tracker is None:
            cls._skill_tracker = SkillTracker()
            cls._skill_tracker.load()
        return cls._skill_tracker

    @classmethod
    def get_runelite_tracker(cls) -> "RuneLiteTracker":
        if cls._runelite_tracker is None:
            cls._runelite_tracker = get_runelite_tracker()
        return cls._runelite_tracker

    @classmethod
    def get_position_tracker(cls) -> "PositionTracker":
        if cls._position_tracker is None:
            cls._position_tracker = get_position_tracker()
        return cls._position_tracker

    def __init__(self, config: dict = None):
        self.config  = config or {}
        self.stats   = ScriptStats()
        self.skill_tracker    = BaseScript.get_skill_tracker()
        self.runelite_tracker  = BaseScript.get_runelite_tracker()
        self.position_tracker  = BaseScript.get_position_tracker()

        # Queue so the GUI bridge can drain log lines live
        self._log_queue: queue.Queue = queue.Queue(maxsize=500)
        self.logger = logging.getLogger(self.__class__.__name__)
        self._attach_queue_handler()

        self._running     = False
        self._paused      = False
        self._stop_event  = threading.Event()
        self._pause_event = threading.Event()
        self._thread: Optional[threading.Thread] = None

    # ── Abstract interface ────────────────────────────────────────────

    @abstractmethod
    def setup(self) -> bool:
        """One-time init. Return False to abort before loop starts."""
        ...

    @abstractmethod
    def loop(self) -> bool:
        """One iteration. Return False to stop the script."""
        ...

    def teardown(self):
        """Called after the loop ends. Override for cleanup."""
        pass

    def _base_teardown(self):
        """Internal teardown — saves skill tracker. Called automatically."""
        try:
            self.skill_tracker.save()
        except Exception:
            pass

    def get_paint_data(self) -> Dict[str, Any]:
        """Override to push custom stats to the GUI stats grid."""
        # Prefer live RuneLite data when connected; fall back to local tracker
        if self.runelite_tracker.connected:
            skill_snapshot = self.runelite_tracker.snapshot()
        else:
            skill_snapshot = self.skill_tracker.snapshot()

        return {
            'Runtime':        self.stats.elapsed_str(),
            'Actions':        self.stats.actions,
            'Errors':         self.stats.errors,
            'skills':         self.stats.skill_gains,      # recent SkillGain list
            'skill_snapshot': skill_snapshot,              # all skills
            'runelite_connected': self.runelite_tracker.connected,
            'runelite_error':     self.runelite_tracker.error,
        }

    # ── Lifecycle ─────────────────────────────────────────────────────

    def start(self):
        """Start the script in a background daemon thread."""
        self._stop_event.clear()
        self._pause_event.clear()
        self._running = True
        self._thread  = threading.Thread(
            target=self._run, daemon=True, name=self.__class__.__name__
        )
        self._thread.start()

    def stop(self):
        """Signal the script to stop on its next iteration."""
        self._running = False
        self._stop_event.set()
        self._pause_event.set()   # unblock if paused

    def pause(self):
        self._paused = True
        self._pause_event.clear()
        self.logger.info('Paused.')

    def resume(self):
        self._paused = False
        self._pause_event.set()
        self.logger.info('Resumed.')

    @property
    def is_running(self) -> bool:
        return self._running

    def join(self, timeout: float = None):
        if self._thread:
            self._thread.join(timeout)

    # ── Internal run loop ─────────────────────────────────────────────

    def _run(self):
        self.logger.info(f'{self.__class__.__name__} starting...')
        try:
            if not self.setup():
                self.logger.warning('Setup returned False — aborting.')
                return
            self.logger.info('Setup complete. Entering loop.')

            while self._running and not self._stop_event.is_set():
                # Handle pause
                if self._paused:
                    self._pause_event.wait(timeout=0.5)
                    continue

                try:
                    should_continue = self.loop()
                    self.stats.actions += 1
                except Exception as e:
                    self.stats.errors += 1
                    self.logger.error(f'Loop error: {e}', exc_info=True)
                    if self.stats.errors > 15:
                        self.logger.error('Too many errors — stopping.')
                        break
                    time.sleep(2.0)
                    continue

                if not should_continue:
                    break

        finally:
            self._running = False
            try:
                self.teardown()
            except Exception as e:
                self.logger.error(f'Teardown error: {e}')
            self._base_teardown()
            self.logger.info(
                f'Stopped. Runtime: {self.stats.elapsed_str()} | '
                f'Actions: {self.stats.actions} | Errors: {self.stats.errors}'
            )

    # ── Logging ──────────────────────────────────────────────────────

    def _attach_queue_handler(self):
        """Attach a QueueHandler so the bridge can drain live log lines."""
        handler = logging.handlers.QueueHandler(self._log_queue)
        handler.setLevel(logging.DEBUG)
        self.logger.addHandler(handler)
        self.logger.propagate = True

    # ── Convenience ──────────────────────────────────────────────────

    def sleep(self, seconds: float):
        """Interruptible sleep — wakes immediately if stop() is called."""
        self._stop_event.wait(timeout=seconds)
