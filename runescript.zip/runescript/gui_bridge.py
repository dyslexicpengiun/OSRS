"""
GUI Bridge
Exposes Python methods to the webview JavaScript layer, and provides
a channel for Python to push live data back into the GUI.

How it works:
  - pywebview calls methods on this class when JS calls window.pywebview.api.*
  - Python pushes data by calling window.evaluate_js() on the webview window
  - All public methods here become callable from JS as:
      window.pywebview.api.start_script('woodcutting', {...})

Thread safety:
  All script operations run in daemon threads. The bridge itself is
  called from the webview's JS thread — keep methods fast and non-blocking.
  Heavy work is dispatched to threads or the existing script thread.
"""

import json
import logging
import threading
import time
from typing import Optional

logger = logging.getLogger(__name__)


class GUIBridge:
    """
    The single object that pywebview exposes to JavaScript as
    window.pywebview.api
    """

    def __init__(self, script_registry: dict):
        """
        Args:
            script_registry:   dict mapping script name → (module_path, ClassName)
        """
        self._script_registry = script_registry
        self._active_script   = None
        self._active_name     = None
        self._window          = None
        self._push_thread     = None
        self._push_running    = False
        self._highlight_colours: dict = {}
        self._session_start = time.time()

    def set_window(self, window):
        """Called by main.py once the webview window exists."""
        self._window = window

    # ──────────────────────────────────────────────────────────────────
    # Script control  (called from JS)
    # ──────────────────────────────────────────────────────────────────

    def start_script(self, script_name: str, config: dict = None) -> dict:
        """
        Start a script by name.
        Returns {'ok': True} or {'ok': False, 'error': '...'}
        """
        if self._active_script and self._active_script.is_running:
            return {'ok': False, 'error': 'A script is already running. Stop it first.'}

        key = script_name.lower()
        if key not in self._script_registry:
            return {'ok': False, 'error': f'Unknown script: {script_name}'}

        try:
            # Inject stored highlight colour into config
            cfg = dict(config or {})
            if key in self._highlight_colours:
                cfg['highlight_colour'] = self._highlight_colours[key]

            mod_path, class_name = self._script_registry[key]
            import importlib
            mod = importlib.import_module(mod_path)
            cls = getattr(mod, class_name)

            # Scripts take only a config dict — no Engine wrapper needed
            self._active_script = cls(cfg)
            self._active_name   = key
            self._active_script.start()

            self._start_push_loop()
            self._push_log('info', f'{class_name} started.')
            logger.info(f'[Bridge] Started {class_name}')
            return {'ok': True}

        except Exception as e:
            logger.exception(f'[Bridge] Failed to start {script_name}: {e}')
            return {'ok': False, 'error': str(e)}

    def stop_script(self) -> dict:
        """Stop the currently running script."""
        if self._active_script:
            self._active_script.stop()
            self._push_log('warn', 'Script stopped by user.')
        return {'ok': True}

    def pause_script(self) -> dict:
        """Pause / resume the active script."""
        if self._active_script and self._engine:
            if self._engine.is_paused:
                self._engine.resume()
                self._push_log('info', 'Script resumed.')
            else:
                self._engine.pause()
                self._push_log('warn', 'Script paused.')
        return {'ok': True}

    def get_script_status(self) -> dict:
        """Return current script state for the GUI status badge."""
        if self._active_script and self._active_script.is_running:
            state = 'running'
            if self._engine and self._engine.is_paused:
                state = 'paused'
        elif self._active_script:
            state = 'stopped'
        else:
            state = 'idle'
        return {
            'state':  state,
            'script': self._active_name or '',
        }

    # ──────────────────────────────────────────────────────────────────
    # Highlight colour  (called from JS colour picker)
    # ──────────────────────────────────────────────────────────────────

    def set_highlight_colour(self, script_name: str, hex_colour: str) -> dict:
        """
        Store the RuneLite highlight colour for a script.
        hex_colour: '#RRGGBB' string from the colour picker.
        """
        key = script_name.lower()
        hex_colour = hex_colour.upper()
        if not hex_colour.startswith('#'):
            hex_colour = '#' + hex_colour

        self._highlight_colours[key] = hex_colour
        logger.info(f'[Bridge] Highlight colour for {key}: {hex_colour}')

        # If the script is running, hot-reload the colour into the detector
        if (self._active_script and
                self._active_name == key and
                self._active_script.is_running):
            try:
                self._active_script.set_highlight_colour(hex_colour)
                self._push_log('info', f'Highlight colour updated to {hex_colour}')
            except AttributeError:
                pass   # script doesn't support hot-reload yet

        return {'ok': True, 'colour': hex_colour}

    def get_highlight_colour(self, script_name: str) -> dict:
        """Return the stored highlight colour for a script."""
        key   = script_name.lower()
        colour = self._highlight_colours.get(key, '#00FFFF')
        return {'colour': colour}

    # ──────────────────────────────────────────────────────────────────
    # Stats  (called from JS on a polling interval)
    # ──────────────────────────────────────────────────────────────────

    def get_stats(self) -> dict:
        """Return live session statistics for the stats grid."""
        if not self._active_script:
            return {}
        try:
            paint = self._active_script.get_paint_data()
            elapsed = int(time.time() - self._session_start)
            paint['session_elapsed'] = elapsed
            return paint
        except Exception:
            return {}

    # ──────────────────────────────────────────────────────────────────
    # Python → JS push helpers
    # ──────────────────────────────────────────────────────────────────

    def _push_log(self, level: str, message: str):
        """Push a log line into the GUI console."""
        if not self._window:
            return
        payload = json.dumps({'level': level, 'message': message})
        try:
            self._window.evaluate_js(f'window.bridge.receiveLog({payload})')
        except Exception:
            pass

    def _push_stats(self, stats: dict):
        """Push stats dict into the GUI stats grid."""
        if not self._window:
            return
        payload = json.dumps(stats)
        try:
            self._window.evaluate_js(f'window.bridge.receiveStats({payload})')
        except Exception:
            pass

    def _push_status(self, status: dict):
        """Push script status (running/paused/stopped) to the GUI."""
        if not self._window:
            return
        payload = json.dumps(status)
        try:
            self._window.evaluate_js(f'window.bridge.receiveStatus({payload})')
        except Exception:
            pass

    def _start_push_loop(self):
        """Start the background thread that pushes live data to the GUI."""
        if self._push_running:
            return
        self._push_running = True
        self._push_thread  = threading.Thread(
            target=self._push_loop, daemon=True, name='GUIPushLoop'
        )
        self._push_thread.start()

    def _push_loop(self):
        """
        Runs in background — pushes stats + status to GUI every second.
        Stops automatically when no script is running.
        """
        while self._push_running:
            try:
                status = self.get_script_status()
                self._push_status(status)

                if self._active_script:
                    stats = self.get_stats()
                    if stats:
                        self._push_stats(stats)

                    # Also forward any new log lines from the script
                    self._drain_script_logs()

                # Stop pushing when script has ended
                if status['state'] == 'stopped':
                    self._push_running = False
                    break

            except Exception as e:
                logger.debug(f'[Bridge] Push loop error: {e}')

            time.sleep(1.0)

    def _drain_script_logs(self):
        """
        Pull pending log records from the script's log queue (if it has one)
        and push them to the GUI. Scripts that want live log output should
        attach a QueueHandler to their logger.
        """
        if not self._active_script:
            return
        queue = getattr(self._active_script, '_log_queue', None)
        if not queue:
            return
        try:
            while not queue.empty():
                record = queue.get_nowait()
                level = record.levelname.lower()
                if level not in ('info', 'warning', 'error', 'debug'):
                    level = 'info'
                if level == 'warning':
                    level = 'warn'
                self._push_log(level, record.getMessage())
        except Exception:
            pass
